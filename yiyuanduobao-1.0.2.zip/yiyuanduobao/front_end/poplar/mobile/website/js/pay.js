(function($,win,doc){
    var t = request("t");
    if ($(".c-pay").size()) {
        var purchase = win.getCookie("purchase");
        if (purchase != null && t == "pay") {
            var c_user = win.getUser();
            if (c_user != "") {
                var r = {
                    heads: {
                        'Content-Type': 'application/json',
                        'User-Token': c_user.token
                    },
                    _double: function (money) {
                        return parseFloat(money).toFixed(2);
                    },
                    _int: function (money) {
                        return parseInt(money);
                    }
                }
                $.rigorAjax({
                    url: 'api/settlement',
                    data: JSON.parse(purchase),
                    heads: r.heads
                }, function (data) {
                    if (data.code != 0) {
                        _tip(data.msg,3000,function(){
                            location.href = "index.html";
                        });
                        return;
                    }
                    r.order = data.data.order_info;
                    r.count = 0;
                    r.gold = r.order.gold;
                    r.g_html = "";
                    for (var i = 0; i < r.order.list.length; i++) {
                        var v = r.order.list[i];
                        r.g_html += '<p><span class="ellipsis fl-l">' + v.gname + '</span><span class="txt-black fl-r"><span class="pale-red">' + v.buy_total + '</span>人次</span></p>';
                        r.count++;
                    }
                    setText("count", r.count);
                    setText("sup_amount", r._double(r.order.amount));
                    setText("sup_total", r._double(r.order.amount_total) + "元");
                    var flag = true;
                    if (r.gold) {
                        $(".sup_buy_coin").removeClass("txt-gray");
                        $(".sup_buy_coin").html('可用<span class="txt-red">' + r._double(r.order.remain_gold) + '</span>个酷币');
                        setText("sup_deduct", r._double(r.gold));
                        if (r._int(r.gold) >= r._int(r.order.amount_total) && r._int(r.order.amount) == 0) {
                            flag = false;
                            $(".pay_alipay").html('<b class="c-radio"></b>支付宝').css("color", "#aaaaaa").removeClass("hidden");
                        }
                    }
                    if (flag) {
                        // pay radio
                        $(".p-way").bind(touchStart, function () {
                            $(".c-radio").removeClass("r-on");
                            $(this).find(".c-radio").addClass("r-on");
                        });
                    }
                    $(".g-item").html(r.g_html);
                    if (global._iswx()) {
                        block("pay_wx");
                    } else {
                        block("pay_alipay");
                        $(".c-radio").eq(1).trigger(touchStart);
                    }
                    var pay = function () {
                        var o = {
                            charge: {},
                            params: {
                                signature: 'confirm.pay',
                                amount_total: r.order.amount_total,
                                gold: r.gold,
                                amount: r.order.amount,
                                open_id: "",
                                charge_channel: "alipay_wap",
                                list: r.order.list
                            }
                        }
                        if (flag) {
                            o.params.charge_channel = $(".r-on").attr("data-pro");
                        }
                        if (global._iswx()) {
                            o.params.open_id = c_user.openid;
                        }
                        var sign = win.generateSign(c_user.token + "-" + o.params.amount_total + "-" + o.params.charge_channel);
                        o.params.signature = sign;
                        var $this = $(this);
                        $this.unbind(touchStart).text('正在支付..');
                        if (typeof _addLoading != "undefined") window._addLoading();
                        $.rigorAjax({url: "api/order", data: o.params, heads: r.heads}, function (json) {
                            if (typeof _removeLoading != "undefined") window._removeLoading();
                            if (json.code == 0) {
                                var _needpay = json.data.is_need_pay;
                                if (_needpay == 0) {  // 如果需要支付金额为0
                                    win.setCookie("orderNo", json.data.order_no, 60 * 10);
                                    location.href = $.setupVersion("order.details.html?t=order");
                                    win.delCookie("purchase");
                                    return;
                                }
                                o.charge = json.data.charge_obj;
                                win.setCookie("orderNo", o.charge.order_no, 60 * 10);
                                //pingpp.setAPURL(global._url+'alipay_in_weixin');
                                pingpp.createPayment(o.charge, function (result, err) {
                                    // 处理错误信息
                                    if (result == "success") {
                                        location.href = "order.details.html?t=order";
                                        win.delCookie("purchase");
                                    } else if (result == "cancel") {
                                        $this.bind(touchStart, pay).text('支付确认');
                                    } else {
                                        _tip(result + "，支付遇到错误，请稍后重试！", 3000);
                                        $this.bind(touchStart, pay).text('支付确认');
                                    }
                                });
                            } else {
                                _tip(json.msg,3000,function(){
                                    window.back();
                                });
                            }
                        });
                    }
                    $("#p-submit").bind(touchStart, pay);
                });
            } else {
                location.href = 'login.html';
            }
        } else {
            _tip("支付信息已失效，请重新夺宝或者结算",3000,function(){
                window.back();
            });
        }
    }
    var orderNo = win.getCookie("orderNo");
    if (orderNo != null && t == "order") {
        var next_time = 0;
        function _notify() {
            block("order-info");
            $.postAjax({url: "api/notify_payment", data: {order_no:parseInt(orderNo),next_time:next_time,signature:"pay.notify"}}, function (json) {
                if (json.code == 0) {
                    // 更新购物车数量
                    $.postAjax({url: "api/cart_list"},function(res) {
                        if(res.code == 0) {
                            var c_user = win.getUser();
                            var num = res.data.total_num;
                            c_user.num = num;
                            win.setCookie("c_user",JSON.stringify(c_user));
                        }
                    });
                    var data = json.data;
                    next_time = data.next_time;
                    if (next_time != 0) {
                        win.setTimeout(function () {
                            _notify();
                        }, next_time);
                    }
                    var ob = {
                        _html : "",
                        items : data.sub_list
                    }
                    $.each(ob.items,function(index){
                        var v = ob.items[index],codes = '';
                        $.each(v.code_list,function(i){
                            codes += '<span>'+ v.code_list[i]+'</span>'
                        });
                        ob._html += '<dl><dt class="mt15 dt-title"><span class="ellipsis">'+ v.gname+'</span><em class="l-time"><span class="txt-red">'+ v.buy_total+'</span>人次</em></dt>' +
                        '<dd class="mt10">商品期号：'+ v.period+'</dd><dd class="mt5 dd-number">夺宝号码：'+ codes+'</dd></dl>';
                    });
                    $(".sup_total_num").text(data.goods_num);
                    $(".sup_total_time").text(data.sum_total);
                    $("#btn-records").attr("href","user.records.html?uid="+data.user_id);
                    $(".o-detail-list").append(ob._html);
                } else if(json.code == 122) {
                    var pay_num = json.data.amount;
                    block("buy_show_fail");
                    none("buy_success");
                    setText("pay_num",pay_num);
                } else {
                    _tip("订单查询出现错误，即将回到首页",3000,function(){
                        location.href = "index.html";
                    });
                }
            });
        }
        _notify();
    } else {
        if (t == "order") {
            none("order-info");
            _tip("订单号码已失效，你可以查看夺宝记录",3000,function(){
                if (win.getUser() != "") location.href = "user.html"; else location.href = "login.html";
            });
        }
    }
})($,window,document)