(function($){
    // check login
    if (typeof c != "undefined") {
        if (typeof c.verify != "undefined") {
            login_jump();
        }
    }
    var c_user = window.getUser();
    var arg = request("arg"),addr = getCookie("addr_info");
    if (addr != null && addr != "null" && arg == "edit") {  // 编辑地址
        addr = JSON.parse(addr);
        setText("title","编辑地址");
        $("input[name=name]").val(addr.name);
        $("input[name=mobile]").val(addr.mobile);
        none("city");
        $("textarea[name=address]").val(addr.address);
        if (addr.is_default == 1) {
            $("input[name=default]").attr("checked","checked");
        } else {
            $("input[name=default]").removeAttr("checked");
        }
    }
    if ($(".m-savebtn").size()) {
        $(".m-savebtn").bind(touchStart,function(){   // 添加地址
            var user = getUser();
            if (user != "") {
                var is_default = $("input[name=default]").is(":checked") ? 1 : 0;
                var name = $("input[name=name]").val();
                var mobile = $("input[name=mobile]").val();
                var province = $("select[name=province]").find("option:selected").text();
                var city = $("select[name=city]").find("option:selected").text();
                var district = $("select[name=district]").find("option:selected").text();
                var address = $("textarea[name=address]").val();
                var addrValidate = function() {
                    if (!$.trim(name)) {
                        _tip("收货人姓名不能为空",3000);
                        return false;
                    }
                    if (!mobile.match(/^1[3|4|5|7|8]\d{9}$/)) {
                        _tip("请输入有效的手机号码",3000);
                        return false;
                    }
                    if (arg != "edit") {
                        var _province = $("select[name=province]").find("option:selected").val();
                        var _city = $("select[name=city]").find("option:selected").val();
                        var _district = $("select[name=district]").find("option:selected").val();
                        if (_province == 0 || _city == 0 || _district == 0) {
                            _tip("请选择省份、城市、区/县",3000);
                            return false;
                        }
                    }
                    var address = $("textarea[name=address]").val();
                    if (!$.trim(address)) {
                        _tip("详细地址不能为空",3000);
                        return false;
                    }
                    return true;
                }
                if (addrValidate()) {
                    var pcd = province + city + district;
                    var addressDetail = ((arg != "edit") ? (pcd + address) : "") + address;
                    var signature = generateSign(user.token);
                    var params = {
                        addr_info : {
                            code : 0,
                            nick_name : name,
                            mobile: mobile,
                            address: addressDetail,
                            is_default : is_default,
                            signature : signature
                        },
                        heads : {
                            'Content-Type': 'application/json',
                            'User-Token' : user.token
                        },
                        url : "api/add_address"
                    }
                    if (arg == "edit") {
                        params.url = "api/modify_address";
                        params.addr_info.code = parseInt(addr.code);
                    }
                    $.rigorAjax({url:params.url,data:params,heads:params.heads},function(data){
                        if (data.code == 0) {
                            if (arg == "edit") {
                                delCookie("addr_info");
                            }
                            location.href = "address.man.html";
                        } else if (data.code == 105) {
                            location.href = "login.html";
                        } else {
                            alert(data.msg);
                        }
                    });
                }
            }
        });
    }
    if ($(".u-gold-coin").size()) {  // 我的酷币
        window.configWX({
            ShareTitle : "动动小手，日进万斗",
            ShareDesc : "能赚钱的酷购吧夺宝，不剁手也能任性买买买！",
            imgUrl: global._url+'images/share_use_img.png',
            url : global._url+"index.html"
        });  // wx config
        $(".gc-tab button").bind(touchStart,function(){
            var _dataSign = $(this).attr("data-sign"),_gain = $(".gain-list"),_reduce = $(".reduce-list");
            if (_dataSign == "0") {
                if ($(".gain-list .gc-part-btm").size() == 0) {
                    $("[data-pro=none_more]").addClass("hidden");
                    $("#gc-nothing").removeClass("hidden");
                } else {
                    $("#gc-nothing").addClass("hidden");
                }
                _gain.removeClass("hidden");
                _reduce.addClass("hidden");
            } else {
                $("#gc-nothing").addClass("hidden");
                if ($(".reduce-list .gc-part-btm").size() == 0) {
                    var reduceProcess = function(data) {
                        window.pageToken = data.next_page_token;
                        if (data.list == null) return;
                        var g_html = "";
                        $.each(data.list,function(index){
                            var v = data.list[index],p_html = "";
                            $.each(v.period_list,function(x){
                                var p = v.period_list[x],length = v.period_list.length;
                                if (length <= 1) {
                                    p_html += '<p class="mt5">您使用了酷币参与了：'+ p.period+'期'+ p.gname+'的夺宝活动</p>';
                                } else {
                                    if (x == 0) {
                                        p_html += '<p class="mt5">您使用了酷币参与了：'+ p.period+'期'+ p.gname+'的夺宝活动<span class="txt-blue ml20 px14 more_btn">展开</span></p>'+
                                        '<div class="more_goods hidden">';
                                    } else {
                                        p_html += '<p class="mt5">您使用了酷币参与了：'+ p.period+'期'+ p.gname+'的夺宝活动</p>';
                                    }
                                    if (x == length - 1) {
                                        p_html += '</div>';
                                    }
                                }
                            });
                            g_html+='<div class="gc-part-btm">'+p_html+'<div class="explain"><span>'+v.time+'</span>'+
                                    '<div class="fl-r mr5"><span class="r-color">用掉<span class="txt-red">'+v.used_gold+'</span>酷币</span>'+
                                    '<span class="r-color ml5">剩余<span class="txt-red">'+v.rest_gold+'</span>酷币</span></div></div></div>';
                        });
                        $(".reduce-list").append(g_html);
                    }
                    $.postAjax({url : "api/used_gold_detail"},function(json){
                        if (json.code == 0) {
                            if (json.data.list != null) {
                                reduceProcess(json.data);
                                pageModal('api/used_gold_detail',function(res){
                                    if (res.code == 0) reduceProcess(res.data);
                                    $(".more_btn").bind(touchStart,function(){
                                        var _goods = $(".more_goods"),_this = $(this);
                                        if (_goods.hasClass("hidden")) {
                                            _goods.removeClass("hidden");
                                            _this.text("收起");
                                        } else {
                                            _goods.addClass("hidden");
                                            _this.text("展开");
                                        }
                                    });
                                });
                            } else {
                                $("[data-pro=none_more]").addClass("hidden");
                                $("#gc-nothing").removeClass("hidden");
                            }
                        }
                    });
                }
                _gain.addClass("hidden");
                _reduce.removeClass("hidden");
            }
            $(this).addClass("btn_yellow").siblings().removeClass("btn_yellow");
        })
        $("[data-role=widget-dialog]").find('.widget_mask,.share-box').bind(touchStart,function() {
            $("[data-role=widget-dialog]").addClass("hidden");
        });
        $(".gc-part-top .gain").bind(touchStart,function(){
            if (!global._iswx()) {
                setText("share-link",global._url+"index.html?re_uid="+c_user.uid);
                block("share_dialog_2");
            } else {
                block("share_dialog_1");
            }
        });
        $.postAjax({url : "api/my_gold_detail"},function(json){
            var data = json.data;
            $(".sup_coin_num").text(data.gold_num);
            if (data.get_detail != null) {
                var gainProcess = function(data) {
                    window.pageToken = data.next_page_token;
                    var g_html = "";
                    $.each(data.get_detail,function(index){
                        var v = data.get_detail[index];
                        g_html += '<div class="gc-part-btm"><p class="mt5">'+ v.message+'</p><p class="explain">'+ v.time+'</p></div>';
                    });
                    $(".gain-list").append(g_html);
                }
                gainProcess(data);
                pageModal('api/get_next_gold_detail',function(res){
                    if (res.code == 0) gainProcess(res.data);
                });
            } else {
                $("[data-pro=none_more]").addClass("hidden");
                $("#gc-nothing").removeClass("hidden");
            }
        });
    }
    if ($(".m-inform").size()) {
        $.postAjax({url:"api/user_message_notify"},function(res){
            if (res.code == 0) {
                if (res.data.list != null) {
                    var process = function (data) {
                        window.pageToken = data.next_page_token;
                        var i_html = "";
                        $.each(data.list, function (index) {
                            var v = res.data.list[index];
                            i_html += '<div class="gc-part-btm"><p class="mt5">' + v.message + '</p>' +
                            '<p class="explain">' + v.time + '</p></div>';
                        });
                        $(".m-inform").append(i_html);
                    }
                    process(res.data);
                    pageModal('api/user_message_notify', function (res) {
                        if (res.code == 0) process(res.data);
                    });
                } else {
                    block("nothing");
                    $("[data-pro=none_more]").addClass("hidden");
                }
            } else {
                _tip(res.msg,3000);
                block("nothing");
                $("[data-pro=none_more]").addClass("hidden");
            }
        });
    }
    if ($(".chat-form").size()) {
        var count = 0;  // 用于记录是否有新的消息产生
        function backBtm() {
            var scrollHeight = $(document).height();
            $(window).scrollTop(scrollHeight);
        }
        var chat = {
            session_id : "",
            last_msg_id : 0,
            getSession : function() {
                $.postAjax({url: "api/im/get_sessions"}, function (res) {
                    if (res.code == 0) {
                        var data = res.data;
                        if (data.list != null && data.list.length > 0) {
                            //var from_html = '';
                            $.each(data.list,function(index){
                                var v = data.list[index],lastMsg = v.last_message;
                                chat.session_id = v.session.sid;
                                chat.last_msg_id = v.last_message.msg_id;
                                //from_html += '<ul class="ul_talk reply"><li><span class="head"><img src="'+lastMsg.from_user.avatar_url+'"></span>'+
                                //'<span class="arrow"></span><span class="content">'+lastMsg.msg_content+'</span></li></ul>';
                            });
                            //$(".chat-details").append(from_html);
                            chat.getMessage();
                            var next_time = res.data.next_interval;
                            window.setTimeout(chat.getSession,next_time);
                        } else {
                            $(".time").text(data.now_time);
                        }
                    }
                });
            },
            getMessage : function() {
                $.postAjax({url: "api/im/receive_message",data:{
                    session_id : chat.session_id,
                    last_id : (chat.last_msg_id + 1),
                    page_size : 100,
                    direction : "forward"
                }}, function (res) {
                    if (res.code == 0) {
                        var r_list = res.data.list;
                        if (r_list != null) {
                            var _html = "";
                            $.each(r_list,function(index){
                                var v = r_list[index],from_id = v.from_user.user_id;
                                if (index == 0) {
                                    $(".time").text(v.msg_ts);
                                }
                                _html += '<ul class="ul_talk'+((c_user.uid == from_id) ? ' reply' : '')+'"><li><span class="head"><img src="'+v.from_user.avatar_url+'"></span>'+
                                '<span class="arrow"></span><span class="content">'+v.msg_content+'</span></li></ul>';
                            });
                            $(".chat-list").html(_html);
                            if (r_list.length > count) {
                                backBtm();
                            }
                            count = r_list.length;
                        }
                    }
                });
            }
        }
        chat.getSession(); backBtm();
        $(".chat-sender").bind(touchStart,function(){
            var to_uid = 10234568;
            var val = $("[name=content]").val();
            if (!val.trim()) {
                alert('亲，请输入您的问题！');
                return;
            }
            var signature = window.hex_md5(c_user.token + "-" + val);
            var params = {
                session_id : chat.session_id,
                to_uid : to_uid,
                msg_type : "text",
                msg_content : val,
                signature : signature
            }
            $.postAjax({url:"api/im/send_message",data:params},function(res){
                if (res.code == 0) {
                    chat.getSession();
                    $("[name=content]").val('');
                }
            });
        });
    }
    if ($("div[data-role=service]").size()) {
        var faqQuestion = ["什么是酷购吧夺宝","如何参加酷购吧夺宝","什么是酷币，怎么用","一元夺宝的幸运号码是怎么计算出来的","如果一件商品很久都没达到总需人次怎么办","中奖商品什么时候发货","没有填写收货地址和手机号码，中奖了怎么办","怎样查看是否成为幸运用户","酷购吧夺宝提醒您：保护自身利益避免损失"];
        if($(".r-services").size()){
            $.each(faqQuestion,function(index){
                $(".r-services ul").append('<li><a href="service.request.html?index='+index+'">'+faqQuestion[index]+'<span class="i_next fl-r"></span></a></li>');
            });
        } else {
            var index = request("index");
            var faqAnswer = ["一种新型的网购模式即互联网的新概念众筹的形式，每个用户最低只需1元就有可能买到一件商品。具体玩法是：用户在一元夺宝挑选商品，每参与1人次可获得1个号码，当该商品达到总参与人次，系统通过公式计算出幸运号码，拥有该号码的用户即可获得该件商品。","使用手机号码注册或其他第三方账号（微信、QQ）登录后，就可以参加夺宝了。先选择感兴趣的商品，并输入要参与的人次，想要增加中奖率可以增加参与次数，这样中奖几率会更大，确定参与次数，直接支付来参与夺宝，如果您有酷币的话，夺宝时可直接抵扣现金，1酷币等于1元，酷购吧夺宝，就是这么简单。","您可以把酷购吧的任何页面分享至微信好友/朋友圈/微博/QQ好友/QQ空间等平台或个人中心“我的酷币”入口进去点击“赚酷币”按钮也可把酷购吧平台分享出去哦！若有小伙伴通过您的分享链接成功参与夺宝活动您即可获得8%的该用户消费提成，他今后在酷购吧平台上所产生的任何消费都会给您计算提成哦！提成直接放至“我的酷币”里，您参与夺宝时可直接抵扣，1酷币等于1元，不兑换不找零哦好任性，简直酷毙了！真是不剁手也可以任性买买买！达到一定金额还可以提现哦！","计算公式是：幸运号码=10000001+变化值     变化值=（数值A+数值B）%数值C<br>数值A：商品的最后一个号码分配完毕后，将该时间点前本站全部商品的最后50个参与时间的数值（每个时间按时、分、秒、毫秒的顺序组合，如20:15:10.362则为201525362）进行求和得出数值A；<br>数值B：最近下一期中国福利彩票“老时时彩”的开奖号码（一个五位数值）<br>数值C：该商品所需人次<br>1）商品的最后一个号码分配完毕后，将公示该分配时间点前本站全部商品的最后50个参与时间；<br>2）将这50个时间的数值进行求和（得出数值A）（每个时间按时、分、秒、毫秒的顺序组合，如20:15:10.362则为201525362）；<br>3）为保证公平公正公开，系统还会等待一小段时间，取最近下一期中国福利彩票“老时时彩”的开奖号码（一个五位数值B）；<br>4）（数值A+数值B）除以该商品总需人次得到的余数 + 原始数 10000001，得到最终幸运号码，拥有该幸运号码者，直接获得该商品。<br>注：如遇福彩中心通讯故障，无法获取上述期数的中国福利彩票“老时时彩”开奖结果，且24小时内该期“老时时彩”开奖结果仍未公布，则默认“老时时彩”开奖结果为00000。","若某件商品的夺宝号码从开始分配之日起90天未分配完毕，则酷购吧官方有权取消该件商品的夺宝活动，并向用户退还酷币，所退还酷币将在3个工作日内退还至用户账户中。","收到中奖消息后，请确认您的收货地址，绑定手机号码，以便奖品及时送给您。发货周期为72小时，由于个人原因导致快递无法正常派发，二次寄送则由您自行承担物流运费。","好运砸向您，您却毫不知情，建议及时补全收货地址和手机号码，以避免与好运只相遇未相见！不过酷购吧官方很贴心的为您保留30天的中奖信息，同时也会想尽一切办法联系到您，只希望把这份喜悦及时送给您！","为能及时获取通知<br>1、建议您立即绑定手机号码，以便于第一时间获取短信通知。<br>2、请在手机的设置中开启“揭晓通知”功能，可以及时获得揭晓通知。<br>您也可以登录酷购吧夺宝后进入“获奖记录”，即可查看您的获奖信息","1、酷购吧官方工作人员在任何时候都不会向用户索取账号密码等信息，大家切勿保护自己的信息和隐私安全<br>2、凡以“高中奖率、系统漏洞”等信息进行代购的，均属于欺诈行为<br>3、当您幸运获奖时，酷购吧官方不会以任何理由要求您缴纳任何费用，也不会在QQ私聊通知您获奖，一切以官方平台提示的获奖为证<br>4、如果有任何疑问请第一时间联系酷购吧夺宝在线客服，客服工作时间早9：00至晚18:30<br>感谢大家的信任和支持，希望大家在酷购吧夺宝，好运连连，惊喜不断！"];
            if (index != ""){
                setText("question_content",faqQuestion[index]);
                $(".answer_content").html(faqAnswer[index]);
            } else {
                global._incorrect();
            }
        }
    }
    if ($(".sup_login_out").size()) {  // 登出
        $(".sup_login_out").bind(touchStart,function(){
            window.delCookie("c_user");
            location.href = "index.html";
        });
    }
})($)