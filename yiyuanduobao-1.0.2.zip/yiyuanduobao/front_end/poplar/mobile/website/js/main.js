/**
 *  @Author Poplar.Young
 * main.js common
 */
// jquery extend method
$.extend($.fn,{
    countTimer : function() {
        var sec = $(this).attr("data-end"),sets = $(this);
        if (sec == "" || typeof sec == "undefined") return;
        setInterval(function(){
            if (sec < 0)
                $.postAjax({url:'api/publish_duobao'},function(){
                    setTimeout(function(){window.refresh();},1000);
                })
            else
                countTimer();
        },1000);
        var countTimer = function() {
            function zero(n) {
                var _n = parseInt(n, 10);
                if(_n > 0){
                    if(_n <= 9){
                        _n = "0" + _n
                    }
                    return String(_n);
                }else{
                    return "00";
                }
            }
            var _sec = zero(sec % 60), _mini = zero(sec / 60 % 60);
            sets.find(".mini").text(_mini);
            sets.find(".sec").text(_sec);
            sec = sec - 1;
            if (sec >= 0) {
                var _num = 0;
                var milli_timer = setInterval(function () {
                    _num = _num + 1;
                    if (_num >= 100) {
                        _num = 0;
                    }
                    sets.find(".hm").text(zero(_num));
                }, 10);
                setTimeout(function () { clearInterval(milli_timer); }, 1000);
            } else {
                sets.find(".hm").text("00");
            }
        }
    }
});
$.extend($,{
    setupVersion : function(url) {    // 设置版本号
        var tempUrl = url,timestamp=new Date().getTime();
        try {
            if (tempUrl.indexOf("?") > 0) {
                tempUrl = tempUrl+"&v="+timestamp;
            } else {
                tempUrl = tempUrl+"?v="+timestamp;
            }
            return tempUrl;
        } catch (e) {
            console.log(e);
            return url;
        }
    },
    clearVersion : function(url,name) {   // 清除指定参数
        try {
            var str = "";
            if (url.indexOf('?') != -1) {
                str = url.substr(url.indexOf('?') + 1);
            } else {
                return url;
            }
            var arr = "";
            var returnurl = "";
            if (str.indexOf('&') != -1) {
                arr = str.split('&');
                for (i in arr) {
                    if (arr[i].split('=')[0] != name) {
                        returnurl = returnurl + arr[i].split('=')[0] + "=" + arr[i].split('=')[1] + "&";
                    }
                }
                return url.substr(0, url.indexOf('?')) + "?" + returnurl.substr(0, returnurl.length - 1);
            } else {
                arr = str.split('=');
                if (arr[0] == name) {
                    return url.substr(0, url.indexOf('?'));
                }
                else {
                    return url;
                }
            }
        } catch (e) {
            console.log(e);
            return url;
        }
    },
    swiperIndex : function() {
        var swiper = new Swiper('.swiper-container', {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            autoplay: 3000,
            autoplayDisableOnInteraction:false,
            spaceBetween: 0,// 图片间距
            height: 280,
            loop: true
        });
        window.addEventListener('orientationchange', function(event){
            if (window.orientation == 180 || window.orientation==0 || window.orientation == 90 || window.orientation==-90 ) {
                swiper.reInit();
            }
        });
    },
    swiperDetails : function() {
        var swiper = new Swiper('.swiper-container', {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            autoplay: 3000,
            autoplayDisableOnInteraction:false,
            spaceBetween: 0,// 图片间距
            height: 280,
            loop: true,
            bulletClass: "swiper-pagination-switch", //自定义
            bulletActiveClass: "swiper-pagination-active"
        });
        window.addEventListener('orientationchange', function(event){
            if (window.orientation == 180 || window.orientation==0 || window.orientation == 90 || window.orientation==-90 ) {
                swiper.reInit();
            }
        });
    },
    noticeTopic : function(obj) {
        var textUl = document.getElementById(obj);
        var textList = textUl.getElementsByTagName("li");
        if(textList.length > 2){
            var textDat = textUl.innerHTML;
            /*var br = textDat.toLowerCase().indexOf("<br",textDat.toLowerCase().indexOf("<br")+3);
             //var textUp2 = textDat.substr(0,br);
             textDiv.innerHTML = textDat+textDat+textDat.substr(0,br);*/
            textUl.style.cssText = "position:relative; top:0";
            var textDatH = textUl.offsetHeight;MaxRoll();
        }
        var minTime,maxTime,divTop,newTop=0;
        function MinRoll(){
            newTop++;
            if(newTop<=divTop+40){
                textUl.style.top = "-" + newTop + "px";
            }else{
                clearInterval(minTime);
                maxTime = setTimeout(MaxRoll,3000);
            }
        }
        function MaxRoll(){
            divTop = Math.abs(parseInt(textUl.style.top));
            if(divTop>=0 && divTop<textDatH-40){
                if (divTop == 0) {
                    setTimeout(function(){
                        minTime = setInterval(MinRoll,1);
                    },3000);
                } else {
                    minTime = setInterval(MinRoll,1);
                }
            }else{
                textUl.style.top = 0;divTop = 0;newTop=0;MaxRoll();
            }
        }
    },
    backTop : function(acceleration, time) {
        acceleration = acceleration || 0.1;
        time = time || 16;
        var x1 = 0,y1 = 0,x2 = 0,y2 = 0,x3 = 0,y3 = 0;
        if (document.documentElement) {
            x1 = document.documentElement.scrollLeft || 0;
            y1 = document.documentElement.scrollTop || 0;
        }
        if (document.body) {
            x2 = document.body.scrollLeft || 0;
            y2 = document.body.scrollTop || 0;
        }
        var x3 = window.scrollX || 0;
        var y3 = window.scrollY || 0;
        // 滚动条到页面顶部的水平距离
        var x = Math.max(x1, Math.max(x2, x3));
        // 滚动条到页面顶部的垂直距离
        var y = Math.max(y1, Math.max(y2, y3));
        // 滚动距离 = 目前距离 / 速度, 因为距离原来越小, 速度是大于 1 的数, 所以滚动距离会越来越小
        var speed = 1 + acceleration;
        window.scrollTo(Math.floor(x / speed), Math.floor(y / speed));
        // 如果距离不为零, 继续调用迭代本函数
        if (x > 0 || y > 0) {
            var invokeFunction = "$.backTop(" + acceleration + ", " + time + ")";
            window.setTimeout(invokeFunction, time);
        }
    },
    postAjax : function(opts,callback,headers){
        var defaults = {
            url : "",
            data : {}
        }
        // add user token
        if (typeof headers == "undefined") {
            var c_user = window.getUser();
            if (c_user != "") {
                headers = { 'User-Token': c_user.token }
            } else {
                headers = {}
            }
        }
        var settings = $.extend(defaults,opts);
        $.ajax({
            url: global._url + settings.url,
            cache: false,
            dataType: 'json',
            data: settings.data,
            type: "post",
            headers : headers,
            success: function (msgObj) {
                if ("object" != typeof msgObj) {
                    msgObj = JSON.parse(msgObj);
                }
                callback(msgObj);
            },
            error: function (requestObj, error_msg, exception) {
                console.error('post request An unknown error has occurred');
            }
        });
    },
    rigorAjax : function(opts,callback){
        var defaults = {
            url : "",
            data : {},
            heads : {}
        }
        var settings = $.extend(defaults,opts);
        $.ajax({
            url: global._url + settings.url,
            cache: false,
            dataType: 'json',
            type: 'post',
            data :  JSON.stringify(settings.data),
            headers : settings.heads,
            success: function (msgObj) {
                if ("object" != typeof msgObj) {
                    msgObj = JSON.parse(msgObj);
                }
                callback(msgObj);
            },
            error: function (requestObj, error_msg, exception) {
                alert("post请求出现未知错误。");
            }
        });
    }
});

var global = {
    _url : "http://"+location.host+"/",
    _title : "酷购一元夺宝",
    _iswx : function() {
        var ua = navigator.userAgent.toLowerCase();
        if(ua.match(/MicroMessenger/i)) {
            return true;
        } else {
            return false;
        }
    },
    _invalid : (((60 * 60) * 24) * 15),
    _maxInv : 5,
    _incorrect : function() {
        location.href = "incorrect.html";
    }
}
var hasTouch = document.hasOwnProperty("ontouchstart"),
    touchStart = hasTouch ? 'touchstart' : 'mousedown',
    touchMove = hasTouch ? 'touchmove' : 'mousemove',
    touchEnd = hasTouch ? 'touchend' : 'mouseup';
(function($,win,doc){
    var validate = function(phone,pass) {
        if (!phone.match(/^1[3|4|5|7|8]\d{9}$/)) {
            return false;
        }
        if (pass.length < 6 || pass.length > 16) {
            return false;
        }
        return true;
    }
    if ($(".m-login-form").size()) {    // 登录
        var login = function(){
            var phoneVal = $("input[name=phone]").val();
            var passVal = $("input[name=password]").val();
            if (validate(phoneVal,passVal)) {
                var u = {
                    phone : phoneVal,
                    pass : passVal,
                    encryPass : ""
                }
                u.encryPass = win.hex_md5(u.pass);
                $.postAjax({
                    url : "api/accounts/login",
                    data : {
                        mobile : u.phone,
                        passwd : u.encryPass
                    }
                },function(res){
                    if (res.code == 0) {
                        var info = { openid : "",token : res.data.token,num: res.data.cart_goods_num,uid:res.data.user_id };
                        win.setCookie("c_user",JSON.stringify(info),global._invalid);
                        var skip_url = getCookie("skip_url");
                        if (skip_url != null)
                            location.href = skip_url;
                        else
                            location.href = "index.html";
                        delCookie("skip_url");
                    } else if (res.code == 108) {
                        _tip("手机号或密码错误",3000);
                    } else {
                        _tip(res.msg,3000);
                    }
                });
            } else {
                _tip("手机号码或密码格式不对",3000,function(){

                });
            }
        }
        $("#login_in").bind(touchStart,login);
        $("#login-wx").bind(touchStart,function(){
            var code = request("code");
            if (code == "" || !global._iswx()) {
                alert("请在微信浏览器里面操作");
            }
        });
        $("#login-qq").bind(touchStart,function(){
            location.href = "login.transfer.html?part=qq";
        });
    }
    if ($(".m-reg-form").size()) {      // 注册、找回密码
        var verifyCode = function(phone,ob){
            $.postAjax({ url : "api/accounts/get_sms_code?mobile="+phone },function(res){
                if (res.code == 0) {
                    ob.unbind(touchStart).css('background-color','#cbd5e1');
                    var t_count = 60,t_zero;
                    var timer = win.setInterval(function() {
                        if (t_count == 0) {
                            win.clearInterval(timer);
                            ob.css('background-color','#556e98').text('短信验证').bind(touchStart,handle);
                        } else {
                            ob.text(function() {
                                --t_count;
                                t_zero = t_count < 10 ? '0' : '';
                                return '重新发送('+ (t_zero + t_count) + 's)';
                            });
                        }
                    }, 1000);
                } else {
                    _tip(res.msg,3000);
                }
            });
        },handle = function(){
            var phone = $("input[name=phone]").val(),ob = $(".sms-btn");
            verifyCode(phone,ob);
        }
        /** verify code */
        $("input[name=phone]").bind("keyup",function(){
            if ($(this).val().match(/^1[3|4|5|7|8]\d{9}$/)) {
                $(".sms-btn").removeClass("btn-off").unbind(touchStart).bind(touchStart,handle);
            } else {
                $(".sms-btn").addClass("btn-off");
            }
        });
        var regValidate = function(phone,pass,code) {
            if (!validate(phone,pass)) return false;
            if (code.length < 4) return false;
            return true;
        }
        var button = $(".reg-btn");  // 获取注册和找回按钮
        $("input").bind("keyup",function(){
            var phone = $("input[name=phone]").val();
            var pass = $("input[name=password]").val();
            var code = $("input[name=code]").val();
            if(regValidate(phone,pass,code)) {
                button.removeClass("btn-off");
                button.unbind(touchStart);
                if (button.attr("data-role") == "reg") {
                    button.bind(touchStart,register);  // 注册
                } else {
                    button.bind(touchStart,retrieve);  // 找回
                }
            } else {
                button.addClass("btn-off");
            }
        });
        function register(){
            var phone = $("input[name=phone]").val();
            var pass = $("input[name=password]").val();
            var code = $("input[name=code]").val();
            if (regValidate(phone,pass,code)) {
                if (!$(".checkbox").is(":checked")) {
                    _tip("未同意服务协议",3000);
                    return;
                }
                var u = {
                    phone: phone,
                    pass: pass,
                    verifyCode: code,
                    encryPass: ""
                }
                u.encryPass = win.hex_md5(u.pass);
                var pr = win.getCookie("channel"), partCode = "", reUid = "";
                if (pr != null) {
                    pr = JSON.parse(pr);
                    partCode = pr.part_code;
                    reUid = pr.re_uid;
                }
                $.postAjax({
                    url: "api/accounts/register",
                    data: {
                        mobile: u.phone,
                        passwd: u.encryPass,
                        verify_code: u.verifyCode,
                        part_code: partCode,
                        re_uid: reUid
                    }
                }, function (res) {
                    if (res.code == 0) {
                        location.href = "login.html";
                    } else {
                        _tip(res.msg,3000);
                    }
                });
            }
        }
        function retrieve(){
            var phone = $("input[name=phone]").val();
            var pass = $("input[name=password]").val();
            var code = $("input[name=code]").val();
            if (regValidate(phone,pass,code)) {
                var u = {
                    phone: $("input[name=phone]").val(),
                    pass: $("input[name=password]").val(),
                    verifyCode: $("input[name=code]").val(),
                    encryPass: ""
                }
                u.encryPass = win.hex_md5(u.pass);
                $.postAjax({
                    url: "api/accounts/reset_passwd",
                    data: {
                        mobile: u.phone,
                        new_passwd: u.encryPass,
                        verify_code: u.verifyCode
                    }
                }, function (res) {
                    if (res.code == 0) {
                        location.href = "login.html";
                    } else {
                        alert(res.msg);
                    }
                });
            }
        }
    }
    /**
     * get user info
     * */
    win.getUser = function() {
        var c_user = getCookie("c_user");
        if (c_user != "" && c_user != "null" && c_user != null && typeof c_user != "undefined")
            return JSON.parse(c_user);
         else
            return "";
    }
    /**
     * login 跳转
     * */
    win.login_jump = function(url) {
        if (win.getUser()=="") {
            function toLogin() {
                if (url != null) {
                    win.setCookie("skip_url", url);
                } else {
                    win.setCookie("skip_url", location.href);
                }
                if (global._iswx()) {
                    location.href = "login.transfer.html?part=wx";
                    return;
                } else {
                    location.href = "login.html";
                    return;
                }
            }
            if (typeof _tip != "undefined") {
                _tip("即将跳转至登录...",2000,toLogin);
            } else {
                toLogin();
            }
        }
    }
    /**
     * get url params
     * strName - key
     * */
    win.request = function (strName) {
        var strHref = window.location.href;
        var intPos = strHref.indexOf("?");
        var strRight = strHref.substr(intPos + 1);
        var arrTmp = strRight.split("&");
        for(var i = 0; i < arrTmp.length; i++) {
            var arrTemp = arrTmp[i].split("=");
            if(arrTemp[0].toUpperCase() == strName.toUpperCase()) return arrTemp[1];
        }
        return "";
    }
    /**
     * 生成签名
     * */
    win.generateSign = function(str) {
        var sign = "82528ed9bd69905545acf180758c2063";
        return win.hex_md5(str+"-"+sign);
    }
    /**
     * 微信config
     * */
    win.configWX = function(wechat) {
        if (global._iswx()) {
            loadScript("http://res.wx.qq.com/open/js/jweixin-1.0.0.js","js");
            try {
                var current_url = location.href.split('#')[0];
                var signature = generateSign(current_url);
                $.postAjax({
                    url: "api/accounts/get_wx_api_config",
                    data: {signature: signature, url: current_url}
                }, function (res) {
                    if (res.code == 0) {
                        var _wx = res.data.wx_config;
                        wx.config({
                            debug: false, appId: _wx.app_id, timestamp: _wx.time_stamp,
                            nonceStr: _wx.noncestr, signature: _wx.signature,
                            jsApiList: ['checkJsApi', 'onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo', 'onMenuShareQZone']
                        });
                        wx.ready(function () {
                            var share_url = "";
                            if (wechat.url != null && typeof wechat.url != "undefined") {
                                share_url = wechat.url;
                            } else {
                                share_url = current_url;
                            }
                            var generateUrl = function () {
                                var c_user = getUser(), tempUrl = $.clearVersion(share_url,"re_uid");
                                if (c_user != "") {
                                    if (tempUrl.indexOf('?') > 0) {
                                        tempUrl = tempUrl + "&re_uid=" + c_user.uid;
                                    } else {
                                        tempUrl = tempUrl + "?re_uid=" + c_user.uid;
                                    }
                                }
                                return $.clearVersion(tempUrl,"v");
                            }
                            share_url = generateUrl();
                            var shareData = {
                                title: wechat.ShareTitle,
                                desc: wechat.ShareDesc,
                                imgUrl: wechat.imgUrl,
                                link: share_url
                            }
                            //alert(JSON.stringify(shareData));
                            wx.onMenuShareTimeline(shareData);
                            wx.onMenuShareAppMessage(shareData);
                            wx.onMenuShareQQ(shareData);
                            wx.onMenuShareWeibo(shareData);
                            wx.onMenuShareQZone(shareData);
                        });
                        wx.error(function (res) {});
                    }
                });
            } catch (e){
                //alert('exception'+ e);
                return;
            }
        }
    }
    /**
     * 返回
     * */
    win.back = function() {
        win.history.go(-1);
    }
    /**
     * 刷新
     * */
    win.refresh = function() {
        win.location.reload();
    }
    /**
     * c_name - key
     * value - val
     * expires - sec秒
     * */
    win.setCookie = function(c_name, value, expires){
        var exdate=new Date();
        expires = expires * 1000;
        exdate.setTime(exdate.getTime() + expires);
        doc.cookie=c_name +"="+ value + ((expires==null) ? "" : ";expires="+exdate.toGMTString());
    }
    /**
     * 异步加载
     * filename 文件名
     * filetype 类型
     * */
    win.loadScript = function(filename,filetype){
        if(filetype == "js"){
            var fileref = doc.createElement('script');
            fileref.setAttribute("type","text/javascript");
            fileref.setAttribute("src",filename);
        }else if(filetype == "css"){
            var fileref = doc.createElement('link');
            fileref.setAttribute("rel","stylesheet");
            fileref.setAttribute("type","text/css");
            fileref.setAttribute("href",filename);
        }
        if(typeof fileref != "undefined"){
            doc.getElementsByTagName("head")[0].appendChild(fileref);
        }
    }
    /**
     * get cookie
     * name - key
     * */
    win.getCookie = function(name){
        var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
        if(arr=doc.cookie.match(reg))
            return (arr[2]);
        else
            return null;
    }
    /**
     * delete cookie
     * name - key
     * */
    win.delCookie = function(name){
        var exp = new Date();
        exp.setTime(exp.getTime() - 1);
        var cval=getCookie(name);
        if(cval!=null)
            doc.cookie= name + "="+cval+";expires="+exp.toGMTString();
    }
    /**
     * set Text
     * */
    win.setText = function(cls,val) {
        $("."+cls).text(val);
    }
    /**
     * show content
     * */
    win.block = function(cls) {
        $("."+cls).removeClass("hidden");
    }
    /**
     * hide content
     * */
    win.none = function(cls) {
        $("."+cls).addClass("hidden");
    }
    /**
     * page modal
     * */
    win.pageModal = function(url,callback) {
        $(win).scroll(function(){
            console.log(window.pageToken);
            if (window.pageToken != "") {
                $("[data-pro=loading]").removeClass("hidden");
                $("[data-pro=none_more]").addClass("hidden");
                var scrollTop = $(this).scrollTop();
                var scrollHeight = $(document).height();
                var windowHeight = $(this).height();
                if (scrollTop + windowHeight == scrollHeight) {
                    $.postAjax({url : url,data:{next_page_token:window.pageToken}},function(res){
                        if (res.code == 0) {
                            if (res.data.next_page_token == "") {
                                $("[data-pro=none_more]").removeClass("hidden");
                                $("[data-pro=loading]").addClass("hidden");
                            }
                            callback(res);
                        } else { alert('请稍后重试'); }
                    });
                }
            } else {
                $("[data-pro=none_more]").removeClass("hidden");
                $("[data-pro=loading]").addClass("hidden");
            }
        });
    }
    var channel = {
        part_code : request("part_code"),
        re_uid : request("re_uid")
    }
    if (channel.part_code != "" || channel.re_uid != "") {
        win.setCookie("channel",JSON.stringify(channel),(60 * 60 * 24));
    }
    $("title").text(global._title);
    var user_url = $.setupVersion("user.html");
    var invent_url = $.setupVersion("inventory.html");
    $("#mine").bind(touchStart,function(){ if (getUser() != "") location.href = user_url; else login_jump(user_url); });
    $("#invent").bind(touchStart,function(){ if (getUser() != "") location.href = invent_url; else login_jump(invent_url); });
})($,window,document);

// last loading
window.onload = function() {
    if (global._iswx()) {
        $('script[type="text/javascript"]').each(function () {
            var _src = $(this).attr("src");
            if (_src.indexOf('.js') > 0) {
                $(this).attr("src", $.setupVersion(_src));
            }
        });
        $('a').each(function () {
            var _src = $(this).attr("href");
            if (_src.indexOf(".html") > 0) {
                $(this).attr("href", $.setupVersion(_src));
            }
        });
    }
    if ($("#backToTop").size() > 0) {
        window.addEventListener("scroll",function(){
            var top = !('pageYOffset' in window) ? (document.compatMode === "BackCompat")
                ? document.body.scrollTop : document.documentElement.scrollTop
                : window.pageYOffset;
            if (top > 400) {
                $("#backToTop").removeClass("hidden");
            } else {
                $("#backToTop").addClass("hidden");
            }
        },false);
        var backTop = document.getElementById("backToTop");
        backTop.addEventListener(touchStart,function(){
            $.backTop();
        },false);
    }
    // navigation status
    if ($(".index_btm a").size() > 0) {
        var n = {
            index : $("#index").val(),
            changeOn : function(before,after) {
                $(".index_btm ."+before).removeClass(before).addClass(after);
            }
        }
        switch (n.index) {
            case "1" :
                n.changeOn("ico-home","ico-on-home");
                break;
            case "2" :
                n.changeOn("ico-publish","ico-on-publish");
                break;
            case "3" :
                n.changeOn("ico-car","ico-on-car");
                break;
            case "4" :
                n.changeOn("ico-mine","ico-on-mine");
                break;
            default :
                break;
        }
        $(".index_btm a").eq(n.index-1).addClass("on").siblings().removeClass("on");
    }
    if ($(".m-detail-login").size() > 0) {
        if (window.getUser() != "") location.href = "user.html";
    }
    // shop car sum
    if ($("[data-pro=invent]").size() > 0) {
        var c_user = window.getUser();
        if (c_user != "") {
            var c_num = parseInt(c_user.num);
            if (c_num > 0) {
                $("[data-pro=invent]").html('<small class="car-num">' + c_num + '</small>');
            }
        }
    }
    if ($("[data-number=true]").size() > 0) {
        $("[data-number=true]").each(function(){
            $(this).bind("keyup",function(){
                var value = $(this).val();
                $(this).val(value.replace(/[^\d]/g,''));
            });
        });
    }
}