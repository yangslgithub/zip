(function(win){
    function tip(str,delay,callback) {
        if ($(".tip_dialog").size()) {
            $(".tip_dialog").remove();
        }
        var _html = '<div data-role="widget-dialog" class="tip_dialog">'
            + '<div class="widget_info tip_show"><div class="widget_body">'+str+'</div></div></div>';
        $("body").append(_html);
        var _tip = $(".tip_dialog");
        win.setTimeout(function(){
            _tip.remove();
            if (callback) callback();
        },delay);
    }
    function addLoading() {
        var _html = '<div data-role="widget-dialog" class="spinner_dialog"><div class="widget_mask"></div><div class="widget_wrap"><div class="loader"><div class="loader-inner ball-clip-rotate"><div></div></div></div></div></div>';
        $("body").append(_html);
    }
    function removeLoading() {
        $(".spinner_dialog").remove();
    }
    win._tip = function(str,delay,callback) { return tip(str,delay,callback) }
    win._addLoading = function() { return addLoading() }
    win._removeLoading = function() { return removeLoading() }
})(window);