#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os, uuid

IMG_UPLOAD_DIR = "./uploads/"
IMG_URL_PREFIX = "http://dbao-files-t.52hangpai.cn/images/"

def safe_to_float(str_input):
	try:
		return float(str_input)
	except:
	    return 0.0	

def safe_to_int(str_input):
	try:
		return int(str_input)
	except:
	    return 0	

# 将web端上传的文件保存到指定的目录下
# 返回:
#     { code: 0|1, full_path: "xxxx", final_url: "xxxx" }
def save_one_upload_file(fileobj):
	try:
		fname = fileobj['filename']
		extname = os.path.splitext(fname)[1]
		new_name = str(uuid.uuid4()) + extname
		new_file = open(IMG_UPLOAD_DIR + new_name, 'w')
		new_file.write(fileobj['body'])
		new_file.close()

		return { 'code': 0, 'full_path': IMG_UPLOAD_DIR + new_name, 'final_url': IMG_URL_PREFIX + new_name }
	except:
		return { 'code': 1 }