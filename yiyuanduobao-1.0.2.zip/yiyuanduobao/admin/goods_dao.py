#!/usr/bin/env python
# -*- coding: utf-8 -*-

## GoodsDao
## 商品表的数据访问对象(DAO=>Data Access Object)

import time
import duobao_util


class GoodsDao():
## 初始化, tdb为torndb对象
    def __init__(self, tdb):

        self.db = tdb

    # 获取商品列表	
    def get_goods_list(self):

        sql = "SELECT goods_id, price, title, sub_title, keywords, image_url,created_at FROM idb_goods " \
            "ORDER BY goods_id DESC"
        return  self.db.query(sql)

    #获取没有在plan的商品列表
    def get_goods_not_in_plan(self):
        sql = "SELECT goods_id, price, title, sub_title, keywords, image_url,created_at FROM idb_goods " \
            "WHERE goods_id in (SELECT goods_id FROM idb_duobao WHERE active_status=0) ORDER BY goods_id DESC"
        return self.db.query(sql)

    #  获取某一条商品    
    def query_one_goods(self, goods_id):
        sql = "SELECT goods_id, price, title, sub_title, keywords, image_url FROM idb_goods " \
            " WHERE goods_id=%s"
        entry = self.db.get(sql, int(goods_id))
        return entry

    #  新增一条商品，返回新商品的Id    
    def insert_new_goods(self, title, sub_title, price, thumbnail_url):
        sql = "INSERT INTO idb_goods (title,sub_title,price,image_url,created_at) " \
                        "VALUES (%s,%s,%s,%s,%s)"

        return self.db.execute_lastrowid(sql,
                        title, sub_title, price, thumbnail_url, int(time.time()))

    #  保存某商品的banner图集或detail图集(实现层)
    def save_goods_images_to_db(self, goods_id, img_type, url_list):
        if not (img_type == "sum_img" or img_type == "detail_img"):
            print "save_goods_image_list(): invalid img_type '%s'!\n" % (img_type,)
            return -1
        if goods_id < 1:
            print "save_goods_image_list(): goods_id invalid '%d'\n" % (goods_id,)
            return -1
        for img_url in url_list:
            self.db.execute("INSERT INTO idb_goods_data(goods_id, type, priority, content, created_at)" \
                " VALUES(%s, %s, 0, %s, %s)",
                goods_id, img_type, img_url, int(time.time()))
        return 0                   

    #  保存某商品的banner图集或detail图集(调用层)
    def save_goods_images(self, request_files, goods_id, img_field_name):
        url_list = []
        files = []

        field_name_2_db_type = { "banner_images": "sum_img", "detail_images": "detail_img" }

        try:
            files = request_files[img_field_name]
        except:
            pass

        for xfile in files:
            ret =  duobao_util.save_one_upload_file(xfile)
            if ret['code'] == 0:
                url_list.append(ret['final_url'])
        if len(url_list) > 0:
            return self.save_goods_images_to_db(goods_id, field_name_2_db_type[img_field_name], url_list)
        else:
            return -1   

    # 返回某商品的banner图集和detail图集，返回tuple        
    def load_goods_images(self, goods_id):
        banner_images = self.db.query("SELECT content FROM idb_goods_data WHERE goods_id= %s " \
            " AND type ='sum_img' ORDER BY content_id", goods_id)
        banner_img_urls = []
        for xitem in banner_images:
            banner_img_urls.append(xitem.content)

        detail_images = self.db.query("SELECT content FROM idb_goods_data WHERE goods_id= %s " \
            " AND type ='detail_img' ORDER BY content_id", goods_id)
        detail_img_urls = []
        for xitem in detail_images:
            detail_img_urls.append(xitem.content)

        return (banner_img_urls, detail_img_urls)  

    # 更新某商品的字段信息    
    def update_one_goods(self, goods_id, title, sub_title, price):
        self.db.execute("UPDATE idb_goods SET title = %s, sub_title = %s, price = %s " \
                "WHERE goods_id = %s", title, sub_title, price, int(goods_id))  



    def delete_one_goods(self, goods_id):

        return self.db.execute("DELETE FROM idb_goods WHERE goods_id=%s ", goods_id)