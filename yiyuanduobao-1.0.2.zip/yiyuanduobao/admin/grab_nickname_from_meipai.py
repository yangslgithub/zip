#!/usr/bin/env python
# -*- coding: utf-8 -*-


#import urllib2
import os, time
from bs4 import BeautifulSoup
import re  ## regular expression
import requests  ## 3rd requests library
import MySQLdb

TOTAL_FETCH_COUNT = 6000

#ROOT_URL = "http://www.meipai.com/user/11385068/followers?p=61"
ROOT_URL = "http://www.meipai.com/user/58410711/followers"

LOCAL_CACHE_FILE = "./meipai_11385068_followers.html"
CUR_USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36"
AVATAR_URL_PREFIX = "http://dbao-files-t.52hangpai.cn/avatar/"

ALPHABET = "0123456789bcdfghjklmnpqrstvwxyz"

MYSQL_HOST = "127.0.0.1"
MYSQL_USER = "kupaiquan"
MYSQL_PASSWD = "KupaiQ#150316"
MYSQL_DB = "iduobao"


def base36_encode(n):
    if n == 0:
        return ALPHABET[0]

    # We're only dealing with nonnegative integers.
    if n < 0:
        raise Exception() # Raise a better exception than this in real life.

    result = ""

    while (n > 0):
        result = ALPHABET[n % len(ALPHABET)] + result
        n /= len(ALPHABET)

    return result

def base36_decode(encoded):
    result = 0

    for i in range(len(encoded)):
        place_value = ALPHABET.index(encoded[i])
        result += place_value * (len(ALPHABET) ** (len(encoded) - i - 1))

    return result

def save_page_content(target_url, target_filename):
	resp = requests.get(target_url, headers= { 'User-Agent': CUR_USER_AGENT })	
	page_content = resp.content 

	tfile = open(target_filename, "w")
	tfile.write(page_content)
	tfile.close()
	return page_content

def read_local_file(target_file):
	try:
	    tfile = open(target_file, 'r')
	    readed = tfile.read()
	    tfile.close()
	    return readed
	except:
		return ""  		  

def parse_followers_url(target_url, local_filename):
	page_content = read_local_file(local_filename)
	if len(page_content) == 0:
		page_content = save_page_content(target_url, local_filename)

	if len(page_content) == 0:
		print "Fetch url '%s' failed!" % (target_filename,)	

	soup = BeautifulSoup(page_content, "html.parser")

	user_card_list = soup.select("div.content > div.content-left > div.user-card-area")
	if len(user_card_list) == 0:
		print "Can't find div.user-card-area !"
		return

	cards = user_card_list[0].find_all("div", class_ = "user-card")
	#print cards
	save_succ_num = 0
	for card_div in cards:
		# div > img[class="ucard-headpic"]
		img = card_div.find("img", class_ = "ucard-headpic")
		img_url = img['src']
		if img_url.endswith('default_avatar_60.png'):
			continue

		if not (img_url.startswith("http:") or img_url.startswith("https:")):
			img_url = "http:" + img_url
		print "src=", img_url, ", title=", img['title']


		if save_succ_num < 1:
			succ = down_thumbnail_image(img_url, "./user_img_22345.jpg")
			if succ:
				save_succ_num += 1


		# div > p[class="ucard-name"] > i[class="icon"]
		icon_tag = card_div.find("p", class_ = "ucard-name").find("i", class_ = "icon")
		print icon_tag['class']

def find_meipai_uid_from_card_div(card_div):
	if not card_div:
		return 0

	for child in card_div.children:
		if child.name == "a":
			href = child['href']
			sub_parts = href.split("/")
			if len(sub_parts) > 2:
				return int(sub_parts[2])		
			break	
				
	return 0		

def down_thumbnail_image(image_url, local_filename):
	#print "Try to download image '%s' to file '%s' ..." % (image_url, local_filename)

	r = requests.get(image_url)
	if r.status_code != 200:
		print "request url '", image_url, "' failed!"
		return False

	tfile = open(local_filename, "w")
	tfile.write(r.content)
	tfile.close()

	return True		

def get_gender_type_by_icon_tag(icon_tag):
	if icon_tag is None:
		return 'u'

	icon_class = icon_tag['class']
	for xitem in icon_class:
		if xitem.find('icon-male') != -1:
			return 'm'
		elif xitem.find('icon-female') != -1:
			return 'f'	

	return 'u'			


## 由于模拟的目标用户男性居多，因此爬到的用户不能有太多女性
def is_cur_user_allowed_by_ratio(gender, count_dict):
	if gender == 'm' or gender == 'u':
		return True

	f_cnt = count_dict['f']
	if f_cnt > 10 and (f_cnt + 1) * 3 > count_dict['m']: # 控制女性比例在1/4以下
		return False

	return True		

def update_count_dict(gender, count_dict):
	if gender == 'm' or gender == 'f':
		count_dict[gender] = count_dict[gender] + 1
	else:
		count_dict['u'] = count_dict['u'] + 1	


def save_user_list_to_db(info_list):
	db = MySQLdb.connect(host = MYSQL_HOST, user = MYSQL_USER, passwd = MYSQL_PASSWD, db = MYSQL_DB)
	cursor = db.cursor()

	db.set_character_set('utf8mb4')
	cursor.execute('SET NAMES utf8mb4')
	cursor.execute("SET CHARACTER SET utf8mb4")
	cursor.execute("SET character_set_connection=utf8mb4")

	for user_info in info_list:
		save_one_user(cursor, user_info[0], user_info[1], user_info[2], user_info[3])

	db.commit()	
	cursor.close()
	db.close()

def save_one_user(cursor, nickname, img_url, gender, mp_uid):
	sql_command = "INSERT IGNORE INTO cached_robot_users(nickname, avatar_url, gender, mp_uid) VALUES(%s, %s, %s, %s)"
	cursor.execute(sql_command, (nickname, img_url, gender, mp_uid))

def grap_one_page_nicknames(cur_url, img_down_dir, count_dict, down_uid_set):
	resp = None

	retry_times = 0
	while retry_times < 3:
		try:
			resp = requests.get(cur_url, headers= { 'User-Agent': CUR_USER_AGENT })	
			break
		except Exception as e:
			print "Fetch '%s' failed for #%d times, error: " % (cur_url, retry_times), e
			retry_times += 1
			time.sleep(3)

	if resp is None:		
		print "Fetch '%s' failed!" % (cur_url)
		return [] ## return empty list
	if resp.status_code != 200:
		print "Fetch '%s' returns http code: %d!" % (cur_url, resp.status_code)
		return [] ## return empty list

	page_content = resp.content 
	soup = BeautifulSoup(page_content, "html.parser")

	# .content > .content-left > .user-card-area
	user_card_list = soup.select("div.content > div.content-left > div.user-card-area")
	if len(user_card_list) == 0:
		print "Can't find div.user-card-area !"
		return []

	cards = user_card_list[0].find_all("div", class_ = "user-card")
	save_succ_num = 0
	ret_list = []
	for card_div in cards:
		# div > img[class="ucard-headpic"]
		img = card_div.find("img", class_ = "ucard-headpic")
		img_url = img['src']
		if img_url.endswith('default_avatar_60.png'):
			continue

		mp_uid = find_meipai_uid_from_card_div(card_div)
		if mp_uid == 0:
			continue
		mp_uid += 15423  # 加一个基数	
		if mp_uid in down_uid_set: ## the user downloaded before!
			print "User [%d] has been fetched before!" % (mp_uid,)
			continue	

		mp_uid_x36 = base36_encode(mp_uid)	
		filename = "mpu_" + mp_uid_x36 + ".jpg"
		sub_dir_name = mp_uid_x36[-1]
		target_filename = os.path.join(img_down_dir, sub_dir_name,  filename) 
		new_img_url = AVATAR_URL_PREFIX + sub_dir_name + "/" + filename

		if not (img_url.startswith("http:") or img_url.startswith("https:")):
			img_url = "http:" + img_url

		# div > p[class="ucard-name"] > i[class="icon"]
		icon_tag = card_div.find("p", class_ = "ucard-name").find("i", class_ = "icon")
		gender = get_gender_type_by_icon_tag(icon_tag)
		#print "src=", img_url, ", title=", img['title'], ", gender=", gender

		if not is_cur_user_allowed_by_ratio(gender, count_dict):
			#print "user '%d' not allowed to save!" % (mp_uid,)
			continue		

		succ = down_thumbnail_image(img_url, target_filename)
		if succ:
			update_count_dict(gender, count_dict)
			down_uid_set[mp_uid] = 1
			#print img['title'], new_img_url, gender
			ret_list.append((img['title'], new_img_url, gender, mp_uid))	

	return ret_list	

def meipai_followers_next_page(cur_page_url):
	m = re.match(r"http://(.*?)\?p=(\d+)$", cur_page_url)
	if m:
		page_str = m.group(2)
		next_page = int(page_str) +1
		return "http://" + m.group(1) + "?p=" + str(next_page)
	else:
		return cur_page_url + "?p=2"  	

def grap_meipai_nicknames(root_url, next_page_func, img_down_dir, count_dict, down_uid_set):
	cur_url = root_url

	fetched_count = 0
	page_count = 0
	while len(cur_url) > 0:
		print "Try to fetch page '%s' ..." % (cur_url,)
		ret_list = grap_one_page_nicknames(cur_url, img_down_dir, count_dict, down_uid_set)
		print "Fetched %d users from current page, total fetched user count: %d" % (len(ret_list), fetched_count + len(ret_list) )
		if len(ret_list) == 0:
			break	

		save_user_list_to_db(ret_list)	

		fetched_count += len(ret_list)
		if fetched_count >= TOTAL_FETCH_COUNT:
			break

		page_count += 1
		#if page_count >= 1:
		#	break		

		cur_url = next_page_func(cur_url)

		sleep_seconds = 2	
		print "Sleep %d seconds ..." % (sleep_seconds,)
		time.sleep(sleep_seconds)
		#cur_url = ""


def main():
	count_dict = { 'm': 0, 'f': 0, 'u': 0}
	down_uid_set = { }
	grap_meipai_nicknames(ROOT_URL, meipai_followers_next_page, "./avatar", count_dict, down_uid_set)
	print count_dict
	#parse_followers_url(ROOT_URL, LOCAL_CACHE_FILE)


if __name__ == "__main__":
    main()
	#print meipai_followers_next_page("http://www.meipai.com/user/11385068/followers?p=3")
	#print meipai_followers_next_page("http://www.meipai.com/user/11385068/followers")
