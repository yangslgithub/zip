# -*- coding: utf-8 -*-


import time
import duobao_util
import datetime

class OrderDao():
    def __init__(self,tdb):
        self.db = tdb

    # 获取订单列表
    def get_order_list(self):
        sql = "SELECT order_no, ping_order_id, user_id, status, created_at FROM idb_orders " \
              "ORDER BY order_no DESC"
        return self.db.get(sql)

    # 获取一条订单信息

