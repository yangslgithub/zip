#!/usr/bin/env python
# coding: utf-8
# author: frk

import sys
reload(sys)
sys.setdefaultencoding("utf-8")

import struct
from socket import inet_aton,inet_ntoa
import os
import MySQLdb

_unpack_V = lambda b: struct.unpack("<L", b)
_unpack_N = lambda b: struct.unpack(">L", b)
_unpack_C = lambda b: struct.unpack("B", b)

MYSQL_HOST = "127.0.0.1"
MYSQL_USER = "kupaiquan"
MYSQL_PASSWD = "KupaiQ#150316"
MYSQL_DB = "iduobao"


def save_ip_list_to_db(info_list):
    db = MySQLdb.connect(host = MYSQL_HOST, user = MYSQL_USER, passwd = MYSQL_PASSWD, db = MYSQL_DB)
    cursor = db.cursor()

    db.set_character_set('utf8')
    cursor.execute('SET NAMES utf8')
    cursor.execute("SET CHARACTER SET utf8")
    cursor.execute("SET character_set_connection=utf8")

    for ip_info in info_list:
        start_ip_int = struct.unpack("!I", ip_info[0])[0]
        start_ip_str = inet_ntoa(ip_info[0])
        end_ip_int = struct.unpack("!I", ip_info[1])[0]
        end_ip_str = inet_ntoa(ip_info[1])

        addr = ip_info[2]
        sub_parts = addr.split("\t")
        country = ""
        province = ""
        city = ""
        if len(sub_parts) > 0:
            country = sub_parts[0]
        if len(sub_parts) > 1:
            province = sub_parts[1]
        if len(sub_parts) > 2:
            city = sub_parts[2]

        #print start_ip_int, ",", start_ip_str, ",", end_ip_int, ",", end_ip_str, ",", country, ",", province, ",", city    
        save_one_user(cursor, start_ip_int, start_ip_str, end_ip_int, end_ip_str, country, province, city)

    db.commit() 
    cursor.close()
    db.close()

def save_one_user(cursor, start_ip_int, start_ip_str, end_ip_int, end_ip_str, country, province, city):
    sql_command = "INSERT IGNORE INTO ipdb_17mon(start_int, start_str, end_int, end_str, country, province, city) VALUES(%s, %s, %s, %s, %s, %s, %s)"
    cursor.execute(sql_command, (start_ip_int, start_ip_str, end_ip_int, end_ip_str, country, province, city))

class IP:
    offset = 0
    index = 0
    binary = ""

    @staticmethod
    def load(file):
        try:
            path = os.path.abspath(file)
            with open(path, "rb") as f:
                IP.binary = f.read()
                IP.offset, = _unpack_N(IP.binary[:4])
                IP.index = IP.binary[4:IP.offset]
        except Exception as ex:
            print "cannot open file %s" % file
            print ex.message
            exit(0)

    @staticmethod
    def find(ip):
        index = IP.index
        offset = IP.offset
        binary = IP.binary
        nip = inet_aton(ip)
        ipdot = ip.split('.')
        if int(ipdot[0]) < 0 or int(ipdot[0]) > 255 or len(ipdot) != 4:
            return "N/A"

        tmp_offset = int(ipdot[0]) * 4
        start, = _unpack_V(index[tmp_offset:tmp_offset + 4])

        index_offset = index_length = 0
        max_comp_len = offset - 1028
        start = start * 8 + 1024
        while start < max_comp_len:
            if index[start:start + 4] >= nip:
                index_offset, = _unpack_V(index[start + 4:start + 7] + chr(0).encode('utf-8'))
                index_length, = _unpack_C(index[start + 7])
                break
            start += 8

        if index_offset == 0:
            return "N/A"

        res_offset = offset + index_offset - 1024
        return binary[res_offset:res_offset + index_length].decode('utf-8')

    @staticmethod
    def import_all_ip():
        index = IP.index
        offset = IP.offset
        binary = IP.binary

        start_ip_str = "1.0.0.0"
        nip = inet_aton(start_ip_str)
        ipdot = start_ip_str.split('.')
        if int(ipdot[0]) < 0 or int(ipdot[0]) > 255 or len(ipdot) != 4:
            return False

        tmp_offset = int(ipdot[0]) * 4
        start, = _unpack_V(index[tmp_offset:tmp_offset + 4])

        index_offset = index_length = 0
        max_comp_len = offset - 1028
        start = start * 8 + 1024
        last_ip = nip

        entries = []
        entries_cnt = 0
        while start < max_comp_len:
            cur_ip = index[start:start + 4]
            cur_ip_int = struct.unpack("!I", cur_ip)[0]  
            cur_ip_str = inet_ntoa(cur_ip)

            #if index[start:start + 4] >= nip:
            index_offset, = _unpack_V(index[start + 4:start + 7] + chr(0).encode('utf-8'))
            index_length, = _unpack_C(index[start + 7])

            res_offset = offset + index_offset - 1024
            ip_addr = binary[res_offset:res_offset + index_length].decode('utf-8')   

            #print inet_ntoa(last_ip), "=>", cur_ip_str, ": ", ip_addr, " (", cur_ip_int, ")"
            entries.append((last_ip, cur_ip, ip_addr))
            entries_cnt += 1
            if len(entries) >= 40:
                save_ip_list_to_db(entries)
                print "save ip info to db #%d ..." % (entries_cnt,)
                entries = []

            last_ip = cur_ip
            start += 8

        if len(entries) > 0:
            save_ip_list_to_db(entries)
            entries = []


def main(target_ip):
    IP.load(os.path.abspath("17monipdb.dat"))
    #IP.import_all_ip()
    print target_ip, " => ", IP.find(target_ip)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print "Usage: %s target_ip" % (sys.argv[0])
        return

    main(sys.argv[1])            
