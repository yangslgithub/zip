#!/usr/bin/env python
# -*- coding: utf-8 -*-

## DuobaoDao
## 夺宝活动的数据访问对象(DAO=>Data Access Object)

import time
import duobao_util
import datetime


class DuobaoDao():
    ## 初始化, tdb为torndb对象
    def __init__(self, tdb):
        self.db = tdb

    # 获取夺宝列表, allowed_status为过滤条件:获取哪种状态的夺宝列表	
    def get_duobao_list(self, allowed_status):
        sql = "SELECT period, active_status, goods_id, title, image_url, price, need_total, joined_num, buy_unit FROM idb_duobao "
        if len(allowed_status) == 1:    ## 只有一种状态
            sql += " WHERE active_status=%d " % (allowed_status[0],)
        elif len(allowed_status) > 1:   ## 允许多种状态，则使用SQL IN
            sql += " WHERE active_status IN (%s) " % (",".join(str(x) for x in allowed_status) ,)  
        sql += " ORDER BY period DESC"      

        return self.db.query(sql)

    #  获取某一条夺宝    
    def query_one_duobao(self, period):
        sql = "SELECT period, active_status, goods_id, title, image_url, price, need_total, " \
                " joined_num, remain_num, buy_unit, lucky_no, lucky_guy FROM idb_duobao " \
                " WHERE period=%s"
        return self.db.get(sql, period)

    # 判断goods_id对应的商品是否已经在buy_unit规格的夺宝中
    def is_goods_in_duobao(self, goods_id, buy_unit):
        sql = "SELECT count(1) num FROM idb_duobao WHERE goods_id=%s AND (active_status=1 OR active_status=0) AND buy_unit=%s"
        ret = self.db.get(sql, goods_id, buy_unit)
        if ret and ret.num > 0:
            return True
        else:
            return False

    # 判断goods_id对应的商品是否已经在buy_unit规格的夺宝中
    def is_duobao_in_active(self, period):
                sql = "SELECT count(1) num FROM idb_duobao WHERE period=%s AND (active_status >= 1)"
                ret = self.db.get(sql, period)
                if ret and ret.num > 0:
                    return True
                else:
                    return False



    # 计算最新的夺宝期号
    def calc_latest_period_num(self):
        dt_now = datetime.datetime.now()
        year_delta = dt_now.year - 2015
        mon_and_day = "%02d%02d" % (dt_now.month, dt_now.day)
        period_num = self.query_launched_period_num_of_curday() + 1
        return str(year_delta) + mon_and_day + "%04d" % (period_num,)

    # 查询当天已经发起的夺宝期数
    def query_launched_period_num_of_curday(self):
        dt_now = datetime.datetime.now()
        date_str = dt_now.strftime("%Y%m%d") 

        sql = "SELECT max_period num FROM idb_period_of_day " \
            " WHERE date_str='%s' " % (date_str,)
        ret = self.db.get(sql)
        max_period = 0
        if ret:
            max_period = ret.num 
        # 更新当天的期数
        sql = "INSERT INTO idb_period_of_day(date_str, max_period) VALUES('%s', 1) " \
            " ON DUPLICATE KEY update max_period=max_period+1" % (date_str, )
        self.db.execute(sql)  
        
        return max_period  

    def add_one_duobao(self, goods_info, title, need_total, buy_unit):
        if len(title) == 0:
            title = goods_info.title


        period_num = int(self.calc_latest_period_num())
        sql_command = "INSERT INTO idb_duobao(period, active_status, goods_id, title, image_url, price, need_total, " \
                " joined_num, remain_num, buy_unit, created_at, publish_at, lucky_guy) VALUES(%d, 0, %d, '%s', '%s', %d, %d, " \
                " 0, %d, %d, %d, 0, 0)" % (period_num, goods_info.goods_id, title, goods_info.image_url, goods_info.price,\
                 need_total, need_total, buy_unit, int(time.time()))
        print sql_command
        self.db.execute(sql_command)

    def delete_one_plan(self, period):
        # if活动状态为停:
        # sql = "CREATE VIEW view_name AS SELECT * FROM idb_duobao WHERE active_status < 1"
        # self.db.execute(sql)

        return self.db.execute("DELETE FROM idb_duobao WHERE period=%s ", period)

    #夺宝状态改为1
    def change_status_to_one(self, period):
        sql = "UPDATE idb_duobao SET active_status=1 WHERE period=%s"
        self.db.execute(sql, period)


    # 夺宝状态改为0
    def change_status_to_o(self, period):
        sql = "UPDATE idb_duobao SET active_status=0 WHERE period=%s"
        self.db.execute(sql, period)

    #插入一条夺宝lauch
    def insert_one_duobao_lauch(self,period,create_at):
        sql = "INSERT INTO idb_duobao_lauch (period,created_at) value (%s,%s)"
        self.db.execute(sql, period, create_at)
