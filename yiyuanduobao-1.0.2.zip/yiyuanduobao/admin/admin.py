#!/usr/bin/env python
# -*- coding: utf-8 -*-

import bcrypt
import concurrent.futures
import MySQLdb
import markdown
import os.path
import re
import time
import subprocess
import torndb
import tornado.escape
import json
from tornado import gen
import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
import unicodedata
import math

from tornado.escape import json_encode
from tornado.options import define, options
import duobao_util
from goods_dao import GoodsDao
from duobao_dao import DuobaoDao
from order_dao import OrderDao
from user_dao import UserDao
import traceback

define("port", default=8432, help="run on the given port", type=int)
define("mysql_host", default="127.0.0.1", help="duobao database host")
define("mysql_database", default="iduobao", help="duobao database name")
define("mysql_user", default="kupaiquan", help="duobao database user")
define("mysql_password", default="", help="duobao database password")

executor = concurrent.futures.ThreadPoolExecutor(2)


class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/", HomeHandler),
            (r"/goods_list", GoodsListHandler),
            (r"/add_goods", AddGoodsHandler),
            (r"/edit_goods", EditGoodsHandler),
            (r"/del_goods", DeleteGoodsHandler),
            (r"/plan_list", PlanListHandler),
            (r"/add_plan", AddPlanHandler),
            (r"/edit_plan",EditPlanHandler),
            (r"/order_list", OrderListHandler),
            (r"/user_list", UserListHandler),
            (r"/auth/create", AuthCreateHandler),
            (r"/auth/login", AuthLoginHandler),
            (r"/auth/logout", AuthLogoutHandler),
            (r"/del_plan",DeletePlanHandler),
            (r"/start_plan", StartPlanHandler),
            (r"/stop_plan",StopPlanHandler),
        ]
        settings = dict(
            blog_title=u"后台管理系统",
            template_path=os.path.join(os.path.dirname(__file__), "templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
            ui_modules={"Entry": EntryModule},
            # xsrf_cookies=True
            cookie_secret="__koogo8:d32c86f2b962e1c74a59__",
            login_url="/auth/login",
            debug=True,
        )
        super(Application, self).__init__(handlers, **settings)
        # Have one global connection to the duobao DB across all handlers
        self.db = torndb.Connection(
            host=options.mysql_host, database=options.mysql_database,
            user=options.mysql_user, password=options.mysql_password)

        #self.maybe_create_tables()

    def maybe_create_tables(self):
        try:
            self.db.get("SELECT COUNT(1) from idb_goods;")
        except MySQLdb.ProgrammingError:
            subprocess.check_call(['mysql',
                                   '--host=' + options.mysql_host,
                                   '--database=' + options.mysql_database,
                                   '--user=' + options.mysql_user,
                                   '--password=' + options.mysql_password],
                                  stdin=open('schema.sql'))


class BaseHandler(tornado.web.RequestHandler):
    @property
    def db(self):
        return self.application.db

    def get_current_user(self):
        user_id = self.get_secure_cookie("admin_user")
        if not user_id: return None
        return self.db.get("SELECT * FROM idb_users WHERE user_id = %s", int(user_id))

    def any_author_exists(self):
        return bool(self.db.get("SELECT * FROM idb_users LIMIT 1"))


class HomeHandler(BaseHandler):
    def initialize(self):
        self.goods_dao = GoodsDao(self.db)

    @tornado.web.authenticated
    def get(self):
        products = self.goods_dao.get_goods_list()
        if not products:
            self.redirect("/add")
            return
        self.render("product.html", product=products)


class GoodsListHandler(BaseHandler):
    def initialize(self):
        self.goods_dao = GoodsDao(self.db)

    @tornado.web.authenticated
    def get(self):
        products = self.goods_dao.get_goods_list()
        if not products:
            self.redirect("/add_goods")
            return
        self.render("product.html", product=products)


class AddGoodsHandler(BaseHandler):
    def initialize(self):
        self.goods_dao = GoodsDao(self.db)

    @tornado.web.authenticated
    def get(self):
        goods_id = self.get_argument("goods_id", None)
        entry = None
        if goods_id:
            entry = self.goods_dao.query_one_goods(goods_id)
        self.render("product_add.html", entry=entry)

    @tornado.web.authenticated
    def post(self):
        title = self.get_argument("title")
        sub_title = self.get_argument("sub_title")
        price_str = self.get_argument("price")
        price = duobao_util.safe_to_float(price_str)

        if price < 0.00001:
            ret_obj = { 'code': 1, 'msg': "价格未填写！" }
            self.write(json_encode(ret_obj))
            return
        thumbnail_info = self.request.files['thumbnail'][0]
        ret = duobao_util.save_one_upload_file(thumbnail_info)
        if ret['code'] != 0:
            ret_obj = {'code': 1, 'msg': "save thumbnail image failed!" }
            self.write(json_encode(ret_obj))
            return
        full_path = ret['full_path']
        final_url = ret['final_url']
        goods_id = self.goods_dao.insert_new_goods(title, sub_title, price, final_url)
        if goods_id < 1:
            ret_obj = { 'code': 1, 'msg': "保存失败！" }
            self.write(json_encode(ret_obj))
            return

        print "insert_new_goods returns goods_id is ", goods_id

        ret_msg = "保存成功!"
        ret =  self.goods_dao.save_goods_images(self.request.files, goods_id, "banner_images") # banner图集
        if ret == 0:
            ret = self.goods_dao.save_goods_images(self.request.files, goods_id, "detail_images")  # 详情图集
            if ret != 0:
                ret_msg = "保存详情图集失败!"

        ret_obj = { 'code': ret,  'msg': ret_msg}
        self.write(json_encode(ret_obj))


class MyRow(dict):
    """A dict that allows for object-like property access syntax."""
    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError:
            raise AttributeError(name)


class EditGoodsHandler(BaseHandler):
    def initialize(self):
        self.goods_dao = GoodsDao(self.db)

    @tornado.web.authenticated
    def get(self):
        goods_id = self.get_argument("goods_id", None)
        entry = None
        if goods_id:
            entry = self.goods_dao.query_one_goods(goods_id)
        if not entry: raise tornado.web.HTTPError(404)

        img_list_tuple = self.goods_dao.load_goods_images(goods_id)

        key_list = [ "goods_id", "title", "sub_title", "price", "thumbnail", "banner_images", "detail_images", "keywords" ]
        value_list = [ entry.goods_id, entry.title, entry.sub_title, entry.price, entry.image_url, img_list_tuple[0], img_list_tuple[1], "" ]

        new_entry = MyRow(zip(key_list, value_list))
            
        self.render("product_edit.html", entry=new_entry)

    def post(self):
        goods_id = self.get_argument("goods_id", None)
        title = self.get_argument("title")
        sub_title = self.get_argument("sub_title")
        price_str = self.get_argument("price")
        price = duobao_util.safe_to_float(price_str)

        if goods_id:
            entry = self.goods_dao.query_one_goods(goods_id)
            if not entry: raise tornado.web.HTTPError(404)
            self.goods_dao.update_one_goods(goods_id, title, sub_title, price)

            self.redirect("/edit_goods?goods_id=%s" % (goods_id,))


class DeleteGoodsHandler(BaseHandler):
    def initialize(self):
        self.goods_dao = GoodsDao(self.db)

    ## 判断该商品是否在夺宝活动中(如果是，则不允许删除)
    def is_goods_in_duobao(self, goods_id):
        pass

    #@tornado.web.authenticated
    def post(self):
        goods_id = self.get_argument("goods_id")
        self.goods_dao.delete_one_goods(goods_id)

        data = {'msg': "删除成功！"}
        self.write(json_encode(data))


class PlanListHandler(BaseHandler):
    def initialize(self):
        self.duobao_dao = DuobaoDao(self.db)

    @tornado.web.authenticated
    def get(self):
        duobao = self.duobao_dao.get_duobao_list([1, 0])
        if not duobao:
            self.redirect("/plan_list")
            return
        self.render("idb_plan.html", duobao=duobao)


class AddPlanHandler(BaseHandler):
    def initialize(self):
        self.duobao_dao = DuobaoDao(self.db)
        self.goods_dao = GoodsDao(self.db)

    @tornado.web.authenticated
    def get(self):
        duobao = self.get_argument("period", None)
        product = self.goods_dao.get_goods_not_in_plan()
        self.render("idb_plan_add.html", duobao=duobao, product=product)

    @tornado.web.authenticated
    def post(self):
        goods_id = self.get_argument("goods_id", None)
        if not goods_id:
            return self.write(json_encode({'code': 1, 'msg': '商品Id没有传递!'}))

        one_goods = self.goods_dao.query_one_goods(goods_id)
        if not one_goods:
            return self.write(json_encode({'code': 1, 'msg': "商品Id'%s'无效!" % (goods_id,)}))

        title = self.get_argument("title")
        need_total = duobao_util.safe_to_int(self.get_argument("need_total", ""))
        if need_total == 0:
            return self.write(json_encode({'code': 1, 'msg': "'最多购买人次'没有填写!" }))

        buy_unit = duobao_util.safe_to_int(self.get_argument("buy_unit", ""))
        if buy_unit == 0:
            buy_unit = 1

        if self.duobao_dao.is_goods_in_duobao(goods_id, buy_unit):
            # 该商品已经在夺宝中，则没必要添加
            return self.write(json_encode({'code': 1, 'msg': "商品 #%s 已经在夺宝计划中!" % (goods_id,)}))

        try:
            self.duobao_dao.add_one_duobao(one_goods, title, need_total, buy_unit)
            return self.write(json_encode({'code': 0, 'msg': "保存成功!" }))
        except Exception as e:
            return self.write(json_encode({'code': 1, 'msg': "保存失败: %s" % (traceback.format_exc(),)}))

class StartPlanHandler(BaseHandler):
    def initialize(self):
        self.duobao_dao = DuobaoDao(self.db)

    @tornado.web.authenticated
    def post(self):
            period = self.get_argument("period", None)
            try:
                self.duobao_dao.change_status_to_one(period)
                self.duobao_dao.insert_one_duobao_lauch(period, time.time())
                return self.write(json_encode({'code': 0, 'msg': "更改成功！"}))
            except Exception as e:
                return self.write(json_encode({'code': 1, 'msg': "保存失败: %s" % (traceback.format_exc(),)}))


class StopPlanHandler(BaseHandler):
    def initialize(self):
        self.duobao_dao = DuobaoDao(self.db)

    @tornado.web.authenticated
    def post(self):
        period = self.get_argument("period", None)
        try:
            self.duobao_dao.change_status_to_o(period)
            return self.write(json_encode({'code': 0, 'msg': "更改成功！"}))
        except Exception as e:
            return self.write(json_encode({'code': 1, 'msg': "保存失败: %s" % (traceback.format_exc(),)}))


class EditPlanHandler(BaseHandler):
    def initialize(self):
        self.duobao_dao = DuobaoDao(self.db)
        self.goods_dao = GoodsDao(self.db)

    @tornado.web.authenticated
    def get(self):
        period = self.get_argument("period", None)
        product = self.goods_dao.get_goods_list()
        duobao = None
        if period:
            duobao = self.duobao_dao.query_one_duobao(period)
        if not duobao: raise tornado.web.HTTPError(404)

        # img_list_tuple = self.goods_dao.load_goods_images(goods_id)
        #
        # key_list = ["goods_id", "title", "sub_title", "price", "thumbnail", "banner_images", "detail_images",
        #             "keywords"]
        # value_list = [entry.goods_id, entry.title, entry.sub_title, entry.price, entry.image_url, img_list_tuple[0],
        #               img_list_tuple[1], ""]
        #
        # new_entry = MyRow(zip(key_list, value_list))

        self.render("idb_plan_edit.html", duobao=duobao, product=product)

    def post(self):
        goods_id = self.get_argument("goods_id", None)
        title = self.get_argument("title")
        sub_title = self.get_argument("sub_title")
        price_str = self.get_argument("price")
        price = duobao_util.safe_to_float(price_str)

        if goods_id:
            entry = self.goods_dao.query_one_goods(goods_id)
            if not entry: raise tornado.web.HTTPError(404)
            self.goods_dao.update_one_goods(goods_id, title, sub_title, price)

            self.redirect("/edit_goods?goods_id=%s" % (goods_id,))

class DeletePlanHandler(BaseHandler):
    def initialize(self):
        self.duobao_dao = DuobaoDao(self.db)
        self.goods_dao = GoodsDao(self.db)



    #@tornado.web.authenticated
    def post(self):
        period = self.get_argument("period")

        ## 判断该商品是否在夺宝活动中(如果是，则不允许删除)
        if self.duobao_dao.is_duobao_in_active(period):
            data = {'msg': "夺宝正在进行，无法删除！"}
            self.write(json_encode(data))

        else:
            self.duobao_dao.delete_one_plan(period)
            data = {'msg': "删除成功！"}
            self.write(json_encode(data))


class OrderListHandler(BaseHandler):
    def initialize(self):
        self.order_dao = OrderDao(self.db)

    @tornado.web.authenticated
    def get(self):
        order = self.order_dao.get_order_list()
        if not order:
            self.redirect("/order_list")
            return
        self.render("order.html", order=order)


class UserListHandler(BaseHandler):
    def initialize(self):
        self.user_dao = UserDao(self.db)

    @tornado.web.authenticated
    def get(self):
        user = self.user_dao.get_user_list()
        if not user:
            self.redirect("/add_user")
            return
        self.render("user.html", user=user)

class DeleteUserHandler(BaseHandler):
    def initialize(self):
        self.user_dao = UserDao(self.db)

    #@tornado.web.authenticated
    def post(self):
        user_id = self.get_argument("user_id")
        self.user_dao.delete_one_user(user_id)

        data = {'msg': "删除成功！"}
        self.write(json_encode(data))


# class MainHandler(BaseHandler):
#     def get(self,template_variables = {}):
#         news_timeline = self.user_dao.get_user_list()
#         current_page = int(self.get_argument('page',0))
#         template_variables["news_timeline"] = news_timeline
#         template_variables["current_page"] = current_page
#         self.render("user.html",**template_variables)





# 存储分页信息
class Page(object):

    def __init__(self, item_count, page_index=1, page_size=10):
        self.item_count = item_count
        self.page_size = page_size
        self.page_count = item_count // page_size + (1 if item_count % page_size > 0 else 0)
        if (item_count == 0) or (page_index > self.page_count):
            self.offset = 0
            self.limit = 0
            self.page_index = 1
        else:
            self.page_index = page_index
            self.offset = self.page_size * (page_index - 1)
            self.limit = self.page_size
        self.has_next = self.page_index < self.page_count
        self.has_previous = self.page_index > 1

    def __str__(self):
        return 'item_count: %s, page_count: %s, page_index: %s, page_size: %s, offset: %s, limit: %s' % (
        self.item_count, self.page_count, self.page_index, self.page_size, self.offset, self.limit)

    __repr__ = __str__


class AuthCreateHandler(BaseHandler):
    def get(self):
        self.render("create_author.html")

    @gen.coroutine
    def post(self):
        if self.any_author_exists():
            raise tornado.web.HTTPError(400, "author already created")
        hashed_password = yield executor.submit(
            bcrypt.hashpw, tornado.escape.utf8(self.get_argument("password")),
            bcrypt.gensalt())
        author_id = self.db.execute(
            "INSERT INTO authors (email, name, hashed_password) "
            "VALUES (%s, %s, %s)",
            self.get_argument("email"), self.get_argument("name"),
            hashed_password)
        self.set_secure_cookie("admin_user", str(author_id))
        self.redirect(self.get_argument("next", "/"))


class AuthLoginHandler(BaseHandler):
    def get(self):
        # 没有用户名和密码，跳转注册页面
        if not self.any_author_exists():
            self.redirect("/auth/create")
        else:
            self.render("login.html", error=None)

    @gen.coroutine
    def post(self):
        author = self.db.get("SELECT * FROM authors WHERE email = %s",
                             self.get_argument("email"))
        if not author:
            self.render("login.html", error="请输入用户名和密码")
            return
        hashed_password = yield executor.submit(
            bcrypt.hashpw, tornado.escape.utf8(self.get_argument("password")),
            tornado.escape.utf8(author.hashed_password))
        if hashed_password == author.hashed_password:
            self.set_secure_cookie("admin_user", str(author.id))
            self.redirect(self.get_argument("next", "/"))
        else:
            self.render("login.html", error="密码错误")


class AuthLogoutHandler(BaseHandler):
    def get(self):
        self.clear_cookie("admin_user")
        self.redirect(self.get_argument("next", "/"))


class EntryModule(tornado.web.UIModule):
    def render(self, entry):
        return self.render_string("modules/entry.html", entry=entry)


def main():
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.current().start()


if __name__ == "__main__":
    main()