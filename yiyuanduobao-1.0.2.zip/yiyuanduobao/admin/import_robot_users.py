#!/usr/bin/env python
# coding: utf-8
# author: frk

import sys
reload(sys)
sys.setdefaultencoding("utf-8")

import struct
from socket import inet_aton,inet_ntoa
import os, time
import random
import MySQLdb
import md5


MYSQL_HOST = "127.0.0.1"
MYSQL_USER = "kupaiquan"
MYSQL_PASSWD = "KupaiQ#150316"
MYSQL_DB = "iduobao"

ROBOT_USER_PARTCODE = "0099"

def int2ip(addr):                                                               
    return inet_ntoa(struct.pack("!I", addr)) 

def md5sum(plain_text):
	m1 = md5.new()
	m1.update(plain_text)
	return m1.hexdigest()

def init_mysql_charset(dbc, char_set):
    dbc.set_character_set(char_set)
    cursor = dbc.cursor()
    cursor.execute("SET NAMES %s" % (char_set,))
    cursor.execute("SET CHARACTER SET %s" % (char_set,))
    cursor.execute("SET character_set_connection=%s" % (char_set,))


def import_all_ip_in_china():
    db = MySQLdb.connect(host = MYSQL_HOST, user = MYSQL_USER, passwd = MYSQL_PASSWD, db = MYSQL_DB)
    cursor = db.cursor()
    init_mysql_charset(db, 'utf8')

    sql_query = "SELECT start_int, end_int, province, city FROM ipdb_17mon WHERE country = '中国' AND province NOT IN ('中国','台湾', '香港', '澳门', '西藏', '青海')"

    cursor.execute(sql_query)
    rows = cursor.fetchall()

    cursor.close()
    db.close()
    return rows

def random_select_one_ip(ip_rows):
	ip_cnt = len(ip_rows)
	if ip_cnt == 0:
		return ()

	idx = random.randint(0, ip_cnt - 1)
	start_int = ip_rows[idx][0]
	end_int = ip_rows[idx][1]
	if start_int == end_int:
		return ()

	ip_delta = end_int - start_int - 1
	cur_int = start_int + random.randint(0, ip_delta)
	cur_str = int2ip(cur_int)
	return (cur_str, ip_rows[idx][2], ip_rows[idx][3])

def insert_one_robot_user(cursor, nickname, gender, avatar, ip_rows):
	ip_info = random_select_one_ip(ip_rows)
	if len(ip_info) == 0:
		print "random_select_one_ip() failed!"
		return

	passwd_md5 = md5sum("iDuobao@1607")

	sql_command = "INSERT INTO idb_users(nick_name, password, part_code, gender, avatar, " \
		" plateform_reg, user_type, created_at, user_ip, province, city) VALUES(%s, %s, %s, %s, %s, " \
		" 'idb', 1, %s, %s, %s, %s)"
	cursor.execute(sql_command, (nickname, passwd_md5, ROBOT_USER_PARTCODE, gender, avatar, \
		int(time.time()), ip_info[0], ip_info[1], ip_info[2]))
	#print sql_command, ip_info[0], ip_info[1], ip_info[2]

def import_all_robot_users():    
    db = MySQLdb.connect(host = MYSQL_HOST, user = MYSQL_USER, passwd = MYSQL_PASSWD, db = MYSQL_DB)
    cursor = db.cursor()
    init_mysql_charset(db, 'utf8mb4')

    ip_rows = import_all_ip_in_china()    

    sql_query = "SELECT nickname, avatar_url, gender FROM cached_robot_users"
    cursor.execute(sql_query)
    rows = cursor.fetchall()

    exec_times = 0
    for row in rows:
    	insert_one_robot_user(cursor, row[0], row[2], row[1], ip_rows)
    	exec_times += 1
    	if exec_times >= 16:
    		db.commit()
    		exec_times = 0


    db.commit() 
    cursor.close()
    db.close()


def main(target_ip):
    IP.load(os.path.abspath("17monipdb.dat"))
    #IP.import_all_ip()
    print target_ip, " => ", IP.find(target_ip)

if __name__ == "__main__":
    #if len(sys.argv) < 2:
    #    print "Usage: %s target_ip" % (sys.argv[0])
    #    sys.exit(1)

    import_all_robot_users()    

    #main(sys.argv[1])  