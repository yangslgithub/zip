#!/bin/sh

python ./admin.py --log_file_prefix=./duobao-admin.log --port=8431 --mysql_host=127.0.0.1 --mysql_database=iduobao --mysql_user=kupaiquan --mysql_password=KupaiQ#150316 &
