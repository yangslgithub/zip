#!/usr/bin/env python
# -*- coding: utf-8 -*-

## GoodsDao
## 商品表的数据访问对象(DAO=>Data Access Object)

import time
import duobao_util

class UserDao():
    ## 初始化, tdb为torndb对象
    def __init__(self, tdb):
        self.db = tdb

    # 获取用户列表
    def get_user_list(self):
        sql = "SELECT user_id, nickname, avatar_url, gender, mp_uid FROM cached_robot_users " \
              "ORDER BY user_id DESC"
        return self.db.query(sql)

    # 更新用户列表
    def update_one_user(self, user_id, nickname, avatar_url, gender):
        self.db.execute("UPDATE user_id SET nickname = %s, avatar_url = %s, gender = %s " \
                        "WHERE user_id = %s", nickname, avatar_url, gender, int(user_id))

    def delete_one_user(self, user_id):
        return self.db.execute("DELETE FROM cached_robot_users WHERE user_id=%s ", user_id)