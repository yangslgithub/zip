#!/bin/sh

psCount=`ps aux|grep admin.py|grep -v 'grep'|wc -l`
if [ $psCount -lt 1 ]; then
    echo "admin.py not running"
    exit 1
fi


pid=`ps aux|grep admin.py|grep -v 'grep'|awk '{print $2}'`
echo "try to stop process $pid ... "
kill -9 $pid
