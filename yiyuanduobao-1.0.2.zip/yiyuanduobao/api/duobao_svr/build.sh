#!/bin/sh

export GOPATH=/usr/local/kupaiq/go-projects/account_svr/
go build -o ihp_acct_svr ihp_accounts_service.go
