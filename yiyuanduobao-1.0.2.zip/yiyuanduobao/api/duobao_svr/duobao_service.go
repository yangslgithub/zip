package main

import (
	"./duobao"
	"encoding/json"
	"flag"
	"fmt"
	"github.com/alecthomas/log4go"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"os/signal"
	"runtime"
	"runtime/debug"
	"strings"
	"syscall"
	"time"
)

const (
	TIME_OUT_MSG = "{ \"state\":408,\"message\": \"time out\" }"
)

var g_sequence uint64

type DuobaoService struct {
}

var g_sc *duobao.ServerConfig
var g_env string

func init() {
	flag.StringVar(&g_env, "env", "idc", "accounts service run enviroment, debug|beta|idc")
}

func ReadFile(path string) (string, error) {
	fi, err := os.Open(path)
	if err == nil {
		defer fi.Close()
		fd, err := ioutil.ReadAll(fi)
		return string(fd), err
	} else {
		return "", err
	}
}

func Action(w http.ResponseWriter, r *http.Request) {
	defer func() {
		//捕获异常,防止进程退出
		if err := recover(); err != nil {
			debug.PrintStack()
			log4go.Error("Account service panic: %s, path=%s, data=%#v", err, r.URL.Path, r.Form)
		}
	}()

	r.ParseForm()
	r.ParseMultipartForm(1024 * 1024 * 4)

	var result string
	g_sequence++
	log4go.Info("handle request %d %s", g_sequence, r.RequestURI)

	if strings.HasPrefix(r.URL.Path, "/api/") || strings.HasPrefix(r.URL.Path, "/apiv2/") {
		result = g_api_handler.Handle(w, r, g_sequence)
	}
	w.Write([]byte(result))
	//fmt.Fprintf(w, result)
}

func formatJson(obj interface{}) string {
	j, _ := json.Marshal(obj)
	return string(j)
}

func (f *DuobaoService) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	Action(w, r)
}

var g_api_handler *duobao.APIHandler

func main() {
	log.SetFlags(log.Lshortfile | log.LstdFlags)
	flag.Parse()
	runtime.GOMAXPROCS(runtime.NumCPU())

	configPath := "./duobao.conf"

	log4go.LoadConfiguration("./log4go.xml")
	defer log4go.Close()

	conf, err := ReadFile(configPath)
	if err != nil {
		log.Fatalln(err)
	}
	log.Println(conf)

	sc := new(duobao.ServerConfig)
	err = json.Unmarshal([]byte(conf), &sc)
	if err != nil {
		log.Fatalln(err) 
	}

	log.Println("NewApiHandler()...")
	g_api_handler, err = duobao.NewApiHandler(sc)
	if err != nil {
		log.Fatalln(err)
	}

	listen := fmt.Sprintf(":%s", sc.Serverport)
	log4go.Debug("Config: Serverport = %s", sc.Serverport)
	timeout := sc.Timeout
	if timeout == 0 {
		timeout = 1
	}

	//函数处理响应耗时告警
	if sc.WaringHighwater == 0 {
		sc.WaringHighwater = 2 //默认值为2s
	}
	if sc.TokenLifeTime < 1800 {
		sc.TokenLifeTime = 1800  // 15 minutes
	} else if(sc.TokenLifeTime > 86400 * 90){
		sc.TokenLifeTime = 86400 * 90   // 90 days
	}

	log4go.Debug("Config: TokenLifeTime = %d", sc.TokenLifeTime)
	
	g_sequence = 0
	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		s := <-sigs
		log4go.Info("Received signal %s, start to close ...", s.String())
		if g_api_handler != nil {
			g_api_handler.Close()
		}
		os.Exit(0)
	}()
	sc.Env = g_env

	g_sc = sc

	//init service
	accountHandler := &DuobaoService{}
	handler := http.TimeoutHandler(accountHandler, time.Duration(timeout*time.Second), TIME_OUT_MSG)
	http.Handle("/", handler)

	err = http.ListenAndServe(listen, nil)
	if err != nil {
		log4go.Info("ListenAndServe: ", err)
	}
	log4go.Info("Accounts service stop...")
}
