package duobao

import (
	"io"
	"crypto/md5"
	"crypto/hmac"
	"crypto/sha1"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"hash/fnv"
	"html/template"
	"net/http"
	"os"
	"regexp"
	"strings"
	"strconv"
	"sync"
	"time"
	"unicode/utf8"
	"math/rand"
	"github.com/alecthomas/log4go"
)

const PTOKEN_DATA_OFFSET = 23

//截取字符串
func Substr(str string, start, length int) string {
	strArr := []rune(str)
	strLen := len(strArr)
	
	//初始化参数
	if start < 0 {
		start = 0
	}
	if start > (strLen - 1) {
		return ""
	}
	if length < 0 {
		length = 0
	}
	if (start + length) > strLen {
		length = strLen - start
	}
	end := start + length
	
	return string(strArr[start:end])
}

func LeftStrUpTo(str string, maxPartLen int) string {
	if maxPartLen <= 0 {
		return str
	}
	if maxPartLen > 0 && maxPartLen > len(str) {
		return str
	}
	concatStr := ""
	charLen := 0
	for _, oneChar := range str {
		concatStr += fmt.Sprintf("%c",oneChar)
		charLen += 1
		if charLen >= maxPartLen {
			break
		}
	}

	if len(str) == len(concatStr) {
		return concatStr
	} else {
		return concatStr + " ..."
	}
}

func SplitStrByPos(str string, nextStartPos int) (string, string) {
	if nextStartPos <= 0 {
		return str, ""
	}
	if nextStartPos > 0 && nextStartPos > len(str) {
		return str, ""
	}

	concatStr := ""
	charLen := 0
	for _, oneChar := range str {
		concatStr += fmt.Sprintf("%c",oneChar)
		charLen += 1
		if charLen >= nextStartPos {
			break
		}
	}

	if len(str) == len(concatStr) {
		return concatStr, ""
	} else {
		return concatStr, str[len(concatStr):]
	}
}

/*
 * 根据email进行hash, 分到对应的表里面去
 */
func GetTableName(email, tableBaseName string, count uint32) string {
	h := fnv.New32a()
	h.Write([]byte(email))
	number := h.Sum32()
	index := number % count
	tablename := fmt.Sprintf("%s_%d", tableBaseName, index)
	return tablename
}

// Request.RemoteAddress contains port, which we want to remove i.e.:
// "192.168.4.188:58292" => "192.168.4.188"
func ipAddrFromRemoteAddr(s string) string {
	idx := strings.LastIndex(s, ":")
	if idx == -1 {
		return s
	}
	return s[:idx]
}

// 从http.Request里面得到客户端IP地址
// 由于服务可能部署在反向代理(如nginx)后面，因此还需要从http头部字段获取地址
func GetClientIpAddr(r *http.Request) string {
	hdr := r.Header
	hdrRealIp := hdr.Get("X-Real-Ip")
	hdrForwardedFor := hdr.Get("X-Forwarded-For")
	if hdrRealIp == "" && hdrForwardedFor == "" {
		return ipAddrFromRemoteAddr(r.RemoteAddr)
	}
	if hdrForwardedFor != "" {
		// X-Forwarded-For is potentially a list of addresses separated with ","
		parts := strings.Split(hdrForwardedFor, ",")
		for i, p := range parts {
			parts[i] = strings.TrimSpace(p)
		}
		// TODO: should return first non-local address
		return parts[0]
	}
	return hdrRealIp
}

/**
 *	生成用户的唯一随机ID
 */
var l sync.Mutex

func GetUserUUID() string {
	l.Lock()
	defer l.Unlock()

	f, _ := os.OpenFile("/dev/urandom", os.O_RDONLY, 0)
	b := make([]byte, 6)
	f.Read(b)
	f.Close()
	uuid := fmt.Sprintf("%d%d%d%d%d%d", b[0], b[1], b[2], b[3], b[4], time.Now().Second())
	return uuid
}

/**
 *	生成用户的随机密码
 */
var mutex sync.Mutex

func GetRandomPassword() string {
	mutex.Lock()
	defer mutex.Unlock()
	f, _ := os.OpenFile("/dev/urandom", os.O_RDONLY, 0)
	b := make([]byte, 3)
	f.Read(b)
	f.Close()
	pass := fmt.Sprintf("%x%x%x", b[0], b[1], b[2])
	return pass
}

//自动生成唯一的email
func GetRandomEmailName() string {
	mutex.Lock()
	defer mutex.Unlock()
	f, _ := os.OpenFile("/dev/urandom", os.O_RDONLY, 0)
	b := make([]byte, 6)
	f.Read(b)
	f.Close()
	email := fmt.Sprintf("%x%x-%x-%x-%x%x", b[0], b[1], b[2], b[3], b[4], b[5])
	return email
}

//自动生成唯一的激活码
func GetRandomSign() string {
	mutex.Lock()
	defer mutex.Unlock()
	f, _ := os.OpenFile("/dev/urandom", os.O_RDONLY, 0)
	b := make([]byte, 8)
	f.Read(b)
	f.Close()
	sign := fmt.Sprintf("%x%x%x%x%x%x%x%x", b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7])
	return sign
}

func formatJson(obj interface{}) string {
	j, _ := json.Marshal(obj)
	return string(j)
}

//检测是否合法的email
func CheckEmail(email string) bool {
	re := regexp.MustCompile(".+@.+\\..+")
	matched := re.Match([]byte(email))
	return matched
}

//生成cookie
func GetCookie() string {
	f, _ := os.OpenFile("/dev/urandom", os.O_RDONLY, 0)
	b := make([]byte, 16)
	f.Read(b)
	f.Close()
	uuid := fmt.Sprintf("%x-%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:])
	return base64.URLEncoding.EncodeToString([]byte(uuid))
}

func IsEmpty(str string) bool {
	return len(str) <= 0
}

//进行xss过滤
func SafeParams(r *http.Request, key string) string {
	//value := strings.TrimSpace(r.FormValue(key))
	value := r.FormValue(key)
	value = template.HTMLEscapeString(value)
	return value
}

//进行xss过滤
func SafeParamsFromPost(r *http.Request, key string) string {
	value := r.PostFormValue(key)
	value = template.HTMLEscapeString(value)
	return value
}


/*
 * password MD5
 */
func Encrypt(pwd string) string {
	//TODO:这里无法加salt,有些调参软件直接传密码的md5过来,囧啊
	// salt := fmt.Sprintf("%x", md5.Sum([]byte(pwd)))
	// initData := fmt.Sprintf("%s%s", pwd, salt)
	encrypt := fmt.Sprintf("%x", md5.Sum([]byte(pwd)))
	return encrypt
}

func CheckSignature(content, token, toBeCheck string) (string, bool) {
	sourceStr := fmt.Sprintf("%s-%s", token, content)
	calcSignature := fmt.Sprintf("%x", md5.Sum([]byte(sourceStr)))
	log4go.Debug("CheckSignature() sourceStr:%s, calcSignature=%s", sourceStr, calcSignature)
	return calcSignature, toBeCheck == calcSignature
}

func genImSessionId(fromUid, toUid int64) string {
	sourceStr := fmt.Sprintf("[%d-%d][#2]", fromUid, toUid)
	return fmt.Sprintf("%x", md5.Sum([]byte(sourceStr)))
}

// 根据deviceId生成sessionId
func genDeviceSessionId(deviceId string) string {
	sourceStr := fmt.Sprintf("[%s-iHangpai]", deviceId)
	return fmt.Sprintf("%x", md5.Sum([]byte(sourceStr)))
}

func int64ArrayToStrArray(iArr []int64) []string {
	sArr := make([]string, 0, len(iArr))
	for _, i := range iArr {
		sArr = append(sArr, strconv.Itoa(int(i)))
	}
	return sArr
}

func stringArrayToInt64Array(sArr []string) []int64 {
	iArr := make([]int64, 0, len(sArr))
	for _, s := range sArr {
		i, err := strconv.Atoi(s)
		if err == nil {
			iArr = append(iArr, int64(i))	
		}
	}
	return iArr	
}

func versionCompare(ver1, ver2 string) int {
	subFields_1 := strings.Split(ver1, ".")
	subFields_2 := strings.Split(ver2, ".")

	len1 := len(subFields_1)
	len2 := len(subFields_2)
	minLen := len1
	if len2 < minLen {
		minLen = len2
	}
	for i := 0; i < minLen; i += 1 {
		n1, err1 := strconv.Atoi(subFields_1[i])
		n2, err2 := strconv.Atoi(subFields_2[i])
		if err1 != nil && err2 == nil {
			return -1
		}else if(err1 == nil && err2 != nil){
			return 1
		}else if(err1 == nil && err2 == nil){
			if n1 != n2 {
				return n1 - n2
			}
		}else{
			return 0
		}
	} 

	return len1 - len2
}

func String2Int64(str string) int64 {
	retValue, err := strconv.ParseInt(str, 10, 64)
	if err != nil {
		return 0
	}else{
		return retValue
	}
}

func Int64List2InSQL(intList []int64) string {
	if len(intList) == 0{
		return ""
	}

	strList := make([]string, 0, len(intList))
	for _, intVal := range intList {
		strList = append(strList, fmt.Sprintf("%d", intVal))
	}
	return strings.Join(strList, ",")
}

func GenPageToken(lastId int64, lastPos int64, nextPage bool) string {
	direction := "ne"
	if !nextPage {
		direction = "pr"
	}

	return fmt.Sprintf("%x_%x_%s", lastId+PTOKEN_DATA_OFFSET, lastPos+PTOKEN_DATA_OFFSET, direction)
}

func GenPageTokenByString(lastId string, nextPage bool) string {
	direction := "ne"
	if !nextPage {
		direction = "pr"
	}

	return fmt.Sprintf("%s_%s", lastId, direction)
}

func ParsePageTokenByString(ptoken string) (string, bool) {
	log4go.Info("ParsePageTokenByString() begin")
	subParts := strings.Split(ptoken, "_")
	if len(subParts) < 2 {
		log4go.Info("ParsePageTokenByString() ptoken less than 2")
		return "", false
	}

	lastId := subParts[0]
	nextPage := true
	if subParts[1] != "ne" {
		nextPage = false
	}
	return lastId, nextPage
}


func ParsePageToken(ptoken string) (int64, int64, bool) {
	log4go.Info("ParsePageToken() begin")
	subParts := strings.Split(ptoken, "_")
	if len(subParts) < 3 {
		log4go.Info("ParsePageToken() ptoken less than 3")
		return -1, -1, false
	}

	lastId, err1 := strconv.ParseInt(subParts[0], 16, 64)
	lastPos, err2 := strconv.ParseInt(subParts[1], 16, 64)
	log4go.Info("ParsePageToken() lastId is %d, lastPos is %d", lastId, lastPos)
	if err1 != nil || err2 != nil {
		log4go.Info("ParsePageToken() ParseInt err1 is %d, err2 is %d", err1, err2)
		return -1, -1, false
	}
	if lastId < PTOKEN_DATA_OFFSET || lastPos < PTOKEN_DATA_OFFSET {
		log4go.Info("ParsePageToken() less than PTOKEN_DATA_OFFSET(%d)", PTOKEN_DATA_OFFSET)
		return -1, -1, false
	}
	nextPage := true
	if subParts[2] != "ne" {
		nextPage = false
	}
	return lastId-PTOKEN_DATA_OFFSET, lastPos-PTOKEN_DATA_OFFSET, nextPage
}

func Gen36baseListString(intList []int64) string {
	if len(intList) == 0 {
		return ""
	}

	strList := make([]string, 0, len(intList))
	for _, intVal := range intList {
		// 转换为36进制
		strList = append(strList, strconv.FormatInt(intVal, 36))
	}
	return strings.Join(strList, ",")	
}

func Parse36baseListString(x36ListStr string) []int64 {
	if len(x36ListStr) == 0 {
		return nil
	}

	strs := strings.Split(x36ListStr, ",")
	retList := make([]int64, 0, len(strs))
	for _, strVal := range strs {
		intVal, err := strconv.ParseInt(strVal, 36, 64)
		if err == nil {
			retList = append(retList, intVal)
		}
	}

	return retList
}

func GenCidListString(cidList []int64) string {
	return Gen36baseListString(cidList)
}

func ParseCidListString(cidListStr string) []int64 {
	return Parse36baseListString(cidListStr)
}

func IsSameVersionByMajorMinor(ver1,ver2 string) bool {
	if len(ver1) == 0 && len(ver2) == 0 {
		return true
	}
	if len(ver1) > 0 && len(ver2) == 0 {
		return false
	}
	if len(ver1) == 0 && len(ver2) > 0 {
		return false
	}

	subParts1 := strings.Split(ver1, ".")
	subParts2 := strings.Split(ver2, ".")
	if len(subParts1) < 2 || len(subParts2) < 2 {
		return false
	}
	if subParts1[0] == subParts2[0] && subParts1[1] == subParts2[1] {
		return true
	}
	return false
}

func Resolution2WidthHeight(resolution string) (int, int) {
	subParts := strings.Split(resolution, "x")
	if len(subParts) < 2 {
		subParts = strings.Split(resolution, "*")
		if len(subParts) < 2 {
			return 0, 0
		}
	}

	width, _ := strconv.Atoi(subParts[0])
	height, _ := strconv.Atoi(subParts[1])
	return width, height
}

func FindStringPrefixList(source string) []string {
	nextPos := 0
	sourceBytes := []byte(source)
	retList := make([]string, 0, len(source))
	for nextPos < len(sourceBytes) {
		_, size := utf8.DecodeRune(sourceBytes[nextPos:])
		nextPos += size

		retList = append(retList, string(sourceBytes[:nextPos]))
		if len(retList) >= 6 {
			break
		}
	}
	return retList
}

func RandomSelectElementsFromIntArray(srcArr []int64, selCount int) ([]int64) {
	if selCount <= 0 || selCount >= len(srcArr) {
		return srcArr
	}

	retArr := make([]int64, 0, selCount)
	curArrSize := len(srcArr)
	selected := 0
	for ; selected < selCount; {
		selIdx := rand.Intn(curArrSize)
		retArr = append(retArr, srcArr[selIdx])
		if selIdx < curArrSize - 1 {
			srcArr[selIdx], srcArr[curArrSize - 1] = srcArr[curArrSize - 1], srcArr[selIdx]
		}
		curArrSize -= 1
		selected += 1
	}

	return retArr
}

func calcDistinctCountOfTwoIntArray(arr1 []int64, arr2 []int64) int {
	if len(arr1) == 0 {
		return len(arr2)
	}
	if len(arr2) == 0 {
		return len(arr1)
	}

	intSet := make(map[int64]bool)
	for _, value := range arr1 {
		intSet[value] = true
	}
	for _, value := range arr2 {
		intSet[value] = true
	}

	return len(intSet)
}

func findFirstLineAndNext(totalStr string) (string, string) {
	sepStrings := []string { "\r\n", "\r", "\n"}
	for _, sepStr := range sepStrings {
		pos := strings.Index(totalStr, sepStr)
		if pos > -1 {
			return totalStr[0:pos], totalStr[pos+len(sepStr):]
		}
	}
	return totalStr, ""
}

func findFirstSentenseAndNext(totalStr string) (string, string) {
	sepStrings := []string { "。", "！", "!"}
	for _, sepStr := range sepStrings {
		pos := strings.Index(totalStr, sepStr)
		if pos > -1 {
			return totalStr[0:pos], totalStr[pos+len(sepStr):]
		}
	}
	return totalStr, ""
}

func UrlSafeBase64(srcData []byte) (string) {
	destStr := base64.StdEncoding.EncodeToString(srcData)
	result := strings.Replace(destStr, "+", "-", -1)
	result = strings.Replace(result, "/", "_", -1)
	return result
}

func genHmacSha1(key, content string) []byte {
	h := hmac.New(sha1.New, []byte(key))
	h.Write([]byte(content))
	return h.Sum(nil)
	//return hex.EncodeToString(h.Sum(nil))	
}

func genSha1(data string) string {
	t := sha1.New();
	io.WriteString(t,data);
	return fmt.Sprintf("%x",t.Sum(nil));
}

func genQboxFopsAccessToken(pathOfUrl string) string{
	sign := genHmacSha1(QBOX_SECRET_KEY, pathOfUrl)
	encodedSign := UrlSafeBase64(sign)
	return QBOX_ACCESS_KEY + ":" + encodedSign
}

func genQboxFopsExpireTime() string{
	expire := fmt.Sprintf("e=%d", time.Now().Unix()+3600)
	return expire
}

func genQboxSignedPlayUrl(playUrlSrc string) string{
	expire := genQboxFopsExpireTime()
	urlSrc := playUrlSrc + "?" + expire
	token := genQboxFopsAccessToken(urlSrc)
	playUrl := fmt.Sprintf("%s&token=%s", urlSrc, token)
	//log4go.Debug("genQboxSignedPlayUrl(): token:%s, expire:%s, playUrl:%s", token, expire, playUrl)
	return playUrl
}

// 1466236997360 ---> "2016-06-18 16:03:17.360"
func  transUnixTime2MilDateString(milUnix int64) string {
	secUnix := milUnix/1000
	Tm := time.Unix(secUnix, 0)	
	TimeStr := Tm.Format("2006-01-02 15:04:05")
	milSec := milUnix%1000
	MilTimeStr := fmt.Sprintf("%s.%03d", TimeStr, milSec)
	return MilTimeStr
}

// 1466236997 ---> "2016-06-18 16:03:17"
func  transUnixTime2DateString(UnixTime int64) string {
	if UnixTime == 0 { // 0时间设为空
		return ""
	}
	Tm := time.Unix(UnixTime, 0)	
	TimeStr := Tm.Format("2006-01-02 15:04:05")
	return TimeStr
}

// 1466236997360 ---> "160317360"
func  transUnixTime2CalcValue(milUnix int64) string {
	secUnix := milUnix/1000
	Tm := time.Unix(secUnix, 0)	
	hh, mm, ss := Tm.Clock()
	milSec := milUnix%1000
	value := fmt.Sprintf("%02d%02d%02d%03d", hh, mm, ss, milSec)
	return value
}

//生成随机字符串
func GetRandomString(length int) string{
   str := "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
   bytes := []byte(str)
   result := []byte{}
   r := rand.New(rand.NewSource(time.Now().UnixNano()))
   for i := 0; i < length; i++ {
      result = append(result, bytes[r.Intn(len(bytes))])
   }
   return string(result)
}