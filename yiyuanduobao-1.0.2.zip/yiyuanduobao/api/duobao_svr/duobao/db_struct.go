//mysql 表结构映射对应的结构体

package duobao

import (
	//"database/sql"
	//"encoding/json"
	//"time"
)


//定义DB用户数据表结构
type UserInfoDb struct {
	UserId        int64   `db:"user_id"`
	Password      string  `db:"password"`
	PartCode      string  `db:"part_code"`
	ReUid      	  int64   `db:"recommend_uid"`
	Nickname      string  `db:"nick_name"`
	Gender        string  `db:"gender"`
	Avatar		  string  `db:"avatar"`
	Mobile		  string  `db:"mobile"`
	OpenId 		  string  `db:"openid"`
	RegDevice	  string  `db:"reg_device"`
	BindMobile	  string  `db:"binding_mobile"`
	LastIP   	  string  `db:"user_ip"`
	City	 		  string	 `db:"city"`
	AddrDefaultCode int   `db:"addr_default_code"`
	AddrDeliveryCode int  `db:"addr_delivery_code"`
	PlatformName  string  `db:"plateform_reg"` 		
	UserType         int  `db:"user_type"`
	Gold      	   int   `db:"gold"`
	CreatedAt      int64  `db:"created_at"`
}

// 用户Token信息
type UserTokenInfo struct {
	UserId    int64 `db:"user_id"`
	CurToken  string `db:"cur_token"`
	TokenUpdatedAt int64 `db:"token_updated_at"`
	PreToken  string `db:"pre_token"`
	PreTokenExpired int64 `db:"pre_token_expired"`
}

// 合作方信息
type PartnerDb struct {
	PartCode    string 	`db:"part_code"`
	Name  		string 	`db:"name"`
	Proportion 	float32 `db:"proportion"` // 分成比例
	CreatedAt   int64  	`db:"created_at"`
}

// 商品概要信息
type GoodsInfoDb struct {
	GoodsId   	int64  `db:"goods_id"`
	Price    	int64  `db:"price"`
	CategoryId 	int    `db:"category_id"`
	BrandId    	int    `db:"brand_id"`
	CidList  	string `db:"cid_list"`
	Title  		string `db:"title"`
	SubTitle  	string `db:"sub_title"`
	Keywords  	string `db:"keywords"`
	ImageUrl    string `db:"image_url"`
	Description string `db:"description"`
	CreatedAt   int64  `db:"created_at"`
}

// 商品图文
type GoodsMediaDb struct {
	ContentId   int64  `db:"content_id"`
	GoodsId   	int64  `db:"goods_id"`
	MediaType  	string `db:"type"`    // sum_img sum_txt detail_img detail_txt
	Content  	string `db:"content"`
	Priority  	int 	   `db:"priority"` // 显示顺序
	CreatedAt   int64  `db:"created_at"`
}

// 汇总订单
type SumOrderDb struct {
	OrderNo   	 string `db:"order_no"`
	PingOrderNo   string `db:"ping_order_id"`
	UserId    	 int64 	`db:"user_id"`
	SubOrderList string `db:"sub_order_list"`
	Amount   	 int64  `db:"amount"`
	Gold   	 	 int    `db:"gold"`      // 使用的金币额
	RestGold   	 int    `db:"rest_gold"` // 购买此单后剩余的金币额
	Status   	 int  	`db:"status"`  	// 订单状态(0未付款，1已付款)
	CreatedAt    int64  `db:"created_at"`
}

// 子订单
type SubOrderDb struct {
	OrderNo  	string 	`db:"order_no"`
	MOrderNo  	string 	`db:"main_order_no"`
	GoodsId  	int64  	`db:"goods_id"`
	UserId		int64 	`db:"user_id"`
	Period   	int64  	`db:"period"`
	BuyTotal   	int  	`db:"buy_total"`
	Amount   	int  	`db:"amount"`
	Status   	int  	`db:"status"`  // 订单状态(0未付款，1已付款)
	CreatedAt   int64  	`db:"created_at"`
}

// 子订单分配号码详细
type OrderDetailDb struct {
	OrderNo  	string 	`db:"order_no"`
	UserId		int64 	`db:"user_id"`
	Period   	int64  	`db:"period"`
	AllCode   	string  `db:"all_code"`
	CodeTotal   	int     `db:"buy_total"`
}

// 一期夺宝活动
type DuobaoInfoDb struct {
	Period   	int64   `db:"period"`
	Status 		int    	`db:"active_status"` // 夺宝活动状态(1-买入中,2-正在揭晓,3-已揭晓)
	GoodsId   	int64  	`db:"goods_id"`
	Title  		string 	`db:"title"`
	ImageUrl  	string 	`db:"image_url"`
	Price    	int  	`db:"price"`
	NeedTotal   int  	`db:"need_total"`
	JoinedNum   int  	`db:"joined_num"`
	RemainNum   int  	`db:"remain_num"`
	BuyUnit   	int  	`db:"buy_unit"`
	LuckyNo   	string  `db:"lucky_no"`
	LuckyGuy   	int64  	`db:"lucky_guy"`
	SscPeriodNo string  `db:"ssc_period_no"`
	ShowTag   	string  `db:"show_tag"`
	CreatedAt   int64  	`db:"created_at"`
	PublishAt   int64 	`db:"publish_at"`    // 揭晓时间
}

// 清单
type CartDb struct {
	UserId		int64 	`db:"user_id"`
	Period   	int64  	`db:"period"`
	CreatedAt   int64  	`db:"created_at"`
}

// 联系客服信息
type MessageDb struct {
	Id			int64 	`db:"id"`
	UserId		int64 	`db:"user_id"`
	Content		int64 	`db:"content"`
	Status   	int  	`db:"status"`  // 信息状态(-1发送失败;0成功)
	Sent_at     int64  	`db:"sent_at"`
}

// 用户地址信息
type AddrListDb struct {
	UserId 		int64 	`db:"user_id"`
	Nickname 	string 	`db:"nick_name"`
	Mobile 		string  	`db:"mobile"`
	Code			int 		`db:"code"`
	Address 		string  	`db:"address"` 
	IsDefault	int 		`db:"is_default"` 
	CreatedAt   int64  	`db:"created_at"`
}

// banner
type BannerConfDb struct {
	Id		  int64   `db:"id"`
	ImageUrl  string  `db:"image_url"`  
	RefUrl    string  `db:"ref_url"`
}


// 某期夺宝参与记录
type JoinedRecord struct {
	OrderNo		string 	`db:"order_no"`
	UserId		int64 	`db:"user_id"`
	GoodsId		int64 	`db:"goods_id"`
	Period		int64 	`db:"period"`
	BuyTotal   	int  	`db:"buy_total"`
	CreatedAt   int64  	`db:"created_at"`
	TimeValue   int64  	`db:"time_value"` // 时间换算成计算详情的值
	NickName    string  `db:"nick_name"`
	AvatarPath  string  `db:"avatar"`
	LastIp      string  `db:"user_ip"`
	City		    string  `db:"city"`
}

// 清单列表
type CartInfo struct {
	UserId		int64 	`db:"user_id"`
	Period		int64 	`db:"period"`
	CreatedAt   int64  	`db:"created_at"`
	Status 		int    	`db:"active_status"`	
	GoodsId		int64 	`db:"goods_id"`
	Title  		string 	`db:"title"`
	NeedTotal   int64  	`db:"need_total"`
	JoinedNum   int64  	`db:"joined_num"`
	RemainNum   int64  	`db:"remain_num"`	
	BuyUnit   	int  	`db:"buy_unit"`
	BuyTotal   	int  	`db:"buy_total"`
	ImageUrl    string 	`db:"image_url"`
}

// 我的全部参与
type MyJoinedInfoDb struct {
	OrderNo   	string  `db:"order_no"`
	BuyTotal    int  	`db:"buy_total"`
	CreatedAt   int64  	`db:"created_at"`
	PublishAt   int64 	`db:"publish_at"`    // 揭晓时间
	Period		int64 	`db:"period"`	
	Status 		int    	`db:"active_status"` // 夺宝活动状态(1-买入中,2-正在揭晓,3-已揭晓)
	GoodsStatus 	int    	`db:"status"`  		// 商品状态(1-未发货,2-已发货,3-配送中)
	GoodsId   	int64  	`db:"goods_id"`	
	Title  		string 	`db:"title"`
	ImageUrl    string 	`db:"image_url"`
	NeedTotal   int  	`db:"need_total"`
	JoinedNum   int  	`db:"joined_num"`
	RemainNum   int  	`db:"remain_num"`
	BuyUnit   	int  	`db:"buy_unit"`	
	LuckyGuy   	int64  	`db:"lucky_guy"`
	LuckyNo   	string  	`db:"lucky_no"`
	ShowTag   	string  `db:"show_tag"`	
}

// 夺宝启动记录
type LauchRecordDb struct {
	Id			int64 	`db:"id"`
	Period		int64 	`db:"period"`
	CreatedAt   int64  	`db:"created_at"`
}

// 时时彩开奖信息
type CqsscDb struct {
	PeriodNo	string 	`db:"period_no"`
	OpenCode	string 	`db:"open_code"`
	OpenAt   int64  	`db:"opened_at"`
}

// 夺宝分配号码池
type CodePoolDb struct {
	Period	string 	`db:"period"`
	Code		string 	`db:"code"`
	IsAssigned int  `db:"is_assigned"`
}

// 用户地址信息
type LocatInfoDb struct {
	UserId		int64 	`db:"user_id"`
	Country		string 	`db:"country"`
	Province		string 	`db:"province"`
	City			string 	`db:"city"`
	Location		string 	`db:"location"`
	ByWhat		string 	`db:"by_what"`
}

// 退款
type RefundDb struct {
	PayId		string 	`db:"pay_order_id"`
	MainOrderNo	string 	`db:"main_order_no"`
	Status 		int    	`db:"status"`
	Amount   	int  	`db:"amount"`
	PayChannel   string  `db:"pay_channel"`
	CreatedAt   int64  	`db:"created_at"`
}

// 当天已启动期数
type PeriodOfDayDb struct {
	DateStr	  string `db:"date_str"`
	MaxPeriod int `db:"max_period"`
}

// 用户获取金币记录
type GoldRecordDb struct {
	Id			int64 	`db:"id"`
	UserId		int64 	`db:"user_id"`
	OpType		string 	`db:"op_type"`
	ParamId 		int64   `db:"param_id"`
	Gold   		int  	`db:"gold"`
	OrderNo   	string  `db:"order_no"`   // 主单号
	CreatedAt   int64   `db:"created_at"`
}

// 用户系统消息
type NotifyMsgDb struct {
	Id			int64 	`db:"id"`
	UserId		int64 	`db:"user_id"`
	Content		string 	`db:"content"`
	Status 		int     `db:"status"`   	// 0未读，1已读
	MsgType   	string  	`db:"msg_type"`  // sys|contact 
	IsDel   		int   	`db:"is_del"`
	CreatedAt   int64   `db:"created_at"`
}

// 合作方提成明细
type CommissionDb struct {
	PartCode		string 	`db:"part_code"`
	OrderNo		string 	`db:"order_no"`   	// 主单号
	UserId		int64 	`db:"user_id"`
	NickName 	string  `db:"nick_name"`   	
	GoodsName   	string  	`db:"goods_list"`    // 商品名称列表 
	Amount   	int   	`db:"amount"`		// 总额,单位元
	Commission  int   	`db:"commission"`    // 提成额，单位分
	CreatedAt   int64    `db:"created_at"`
}