package duobao

import (
	//"encoding/json"
	//"errors"
	//"fmt"
	"github.com/coopernurse/gorp"
	"github.com/alecthomas/log4go"
	"net/http"
	"strconv"
	"strings"
	"time"
)

var EMPTY_SESSION_LIST = make([]ImSessionRespInfo, 0)

/*
*  发送聊天消息
*  基本逻辑:  0. 检查是否为垃圾或广告消息
*            1. 检查对方的版本是否只能聊天功能: 如果是1.3版本将只推送一条web通知，1.3以前版本则忽略
*            2. 如果请求没有带session_id，则查找session_id或者创建新session
*            3. 将该消息的概要写入到ihp_t_message表(content字段不用填写), uuid为session_id; 写入后得到msg_id
*            4. 将msg_id及消息的其他信息写入ihp_t_imsession_messages表
*            5. 更新ihp_t_imsession_summary表
*            6. push消息给接收方(构造一条消息写入redis队列)
*/
func (o *APIHandler) SendImMsg(r *http.Request, headers *CommonHeaders, sequence uint64) (string,error) {
	clientReq, retCode, retMsg := handleSendMsgParams(r, headers)
	if clientReq == nil {
		result := ResponseInfo{ Code: retCode, Msg: retMsg }
		return formatJson(result), nil
	}
	if isSpawnMsg(r, headers, clientReq) {
		result := ResponseInfo{ Code: RET_SPAWN_TEXT, Msg: MSG_SPAWN_TEXT }
		return formatJson(result), nil		
	}

	meUid, err := o.queryUserIdByToken(headers.UserToken)
	if err != nil || meUid == -1 {
		log4go.Error("SendImMsg(): User token(%s) invalid: error=%s", headers.UserToken, err)
		result := ResponseInfo{ Code: RET_TOKEN_EXPIRED, Msg: MSG_TOKEN_EXPIRED }
		return formatJson(result),nil
	}

	log4go.Debug("SendImMsg() called, ToUid=%d, SessionId='%s', msgType='%s', msgContent='%s'...", clientReq.ToUid,
		clientReq.SessionId, clientReq.MsgType, clientReq.MsgContent)	

	nowUnix := time.Now().UnixNano() / int64(time.Millisecond)
	respJson, msgId, curSessionId, err := o.sendMsgImpl(clientReq, meUid, nowUnix, true)
	if err != nil || msgId <= 0 || len(curSessionId) == 0 {
		return respJson, err
	}

	result := ResponseInfo{ 
		Code: RET_OK, Msg: MSG_OK,
		Data: SendImMsgData {
			MsgId: msgId, 
			MsgTs: nowUnix,
			Session: ImSessionBasicInfo { Sid: curSessionId  },
		},
	}	
	return formatJson(result),nil	

}

func (o *APIHandler)isAllowChatUserId(userId int64) bool {
	if len(o.sc.NoCheckImUserIdList) == 0 {
		return false
	}

	uidStrs := o.sc.NoCheckImUserIdList
	uidStrArr := strings.Split(uidStrs, "-")
	if len(uidStrArr) == 0 {
		return false
	}
	for _, uidStr := range uidStrArr {
		uid, _ := strconv.Atoi(uidStr)
		if uid > 0 && uid == int(userId) {
			return true
		}
	}
	return false
}


func (o *APIHandler)getDbTransaction() (*gorp.Transaction, error) {
	dbMap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}

	dbMap.AddTableWithName(MyMessageInfoDb{}, "idb_message").SetKeys(true, "id")
	dbMap.AddTableWithName(ImSessionUsersDb{}, "idb_imsession_users")
	dbMap.AddTableWithName(ImSessionSummaryDb{}, "idb_imsession_summary")
	dbMap.AddTableWithName(ImSessionMessageDb{}, "idb_imsession_messages")

	return dbMap.Begin()	
}

/*
*  接收当前会话的聊天消息
*  基本逻辑:   0. 检查session_id及last_id(如果last_id>0)参数是否有效
*             1. 检查当前用户(根据token)是否在session里面
*             2. 按照要求获取ihp_t_imsession_messages表最后N条消息或者last_id之前/之后的N条消息
*             3. 对获取到的每条消息，去ihp_t_messages表批量检查该消息是否已读，如果是未读则置为已读
*/
func (o *APIHandler) RecvImMsg(r *http.Request, headers *CommonHeaders, sequence uint64) (string,error) {
	// 参数检查
	clientReq, retCode, retMsg := handleRecvMsgParams(r, headers)
	if clientReq == nil {
		result := ResponseInfo{ Code: retCode, Msg: retMsg }
		return formatJson(result), nil
	}	

	meUid, err := o.queryUserIdByToken(headers.UserToken)
	if err != nil || meUid == -1 {
		log4go.Error("RecvImMsg(): User token(%s) invalid, error = %s", headers.UserToken, err)
		result := ResponseInfo{ Code: RET_TOKEN_EXPIRED, Msg: MSG_TOKEN_EXPIRED }
		return formatJson(result),nil
	}	

	includesMe, err := o.isUserInSession(meUid, clientReq.SessionId)
	if err != nil {
		result := ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
		return formatJson(result),nil		
	}
	if !includesMe {
		log4go.Warn("RecvImMsg(): user [%d] not in session '%s', receive_message not allowed!", meUid, clientReq.SessionId)
		result := ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID }
		return formatJson(result), nil		
	}

	afterward := true
	if clientReq.Direction != "afterward"{
		afterward = false
	}
	msgs, err := o.loadSessionMessages(clientReq.SessionId, clientReq.LastId, afterward, clientReq.PageSize)
	if err != nil {
		result := ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
		return formatJson(result),nil		
	}
	finalMsgs := make([]ImMsgRespInfo, 0, len(msgs))
	for _, msgInfo := range msgs {
		finalMsg := o.transformSessionMessage(&msgInfo)
		if finalMsg == nil {
			continue
		}
		finalMsgs = append(finalMsgs, *finalMsg)
	}

	msgIds := make([]int64, 0, len(msgs))
	for _, msgInfo := range msgs {
		msgIds = append(msgIds, msgInfo.MsgId)
	}
	msgId2status, err := o.queryAndSetMsgStatus(msgIds, meUid, clientReq.SessionId, clientReq.LastId)
	if err != nil {
		result := ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
		return formatJson(result),nil		
	}

	maxMsgId := int64(-1)
	retMsgIds := make([]int64, 0, len(finalMsgs))
	for idx, _ := range finalMsgs {
		retMsgIds = append(retMsgIds, finalMsgs[idx].MsgId)

		msgInfo := &finalMsgs[idx]
		status, ok := msgId2status[msgInfo.MsgId]
		if ok  {
			msgInfo.ReadFlag = status
		}
		if maxMsgId < msgInfo.MsgId {
			maxMsgId = msgInfo.MsgId
		}
	}
	if maxMsgId > -1 {
		o.updateUserMaxFetchMsgId(clientReq.SessionId, meUid, maxMsgId)
	}
	if len(retMsgIds) > 0 {
		log4go.Debug("RecvImMsg(): returned msgIds for user-session [uid:%d - %s] is: %s", 
			meUid, clientReq.SessionId, Int64List2InSQL(retMsgIds))
	}

	result := ResponseInfo { Code: RET_OK,
		Msg: MSG_OK,
		Data: RecvSessionMsgsResp {
			List: finalMsgs,
			NextInterval: 5,
		},
	 }

	return formatJson(result),nil	
}

/*
*  获取当前用户的聊天会话列表
*  基本逻辑:   0. 参数检查:last_id(如果last_id>0)参数是否有效
*             1. 获取当前用户参与的所有session列表(根据ihp_t_imession_users表)
*             2. 按照会话最后聊天时间倒序，取出排序后的所有会话(参考ihp_t_imsession_summary表)，写入redis
*             2. 如果请求不是从第1页开始，从直接从redis缓存获取；如果请求第0页，则从步骤1开始执行
*             3. 每个会话，要从ihp_t_imsession_messages里面获取最后一条消息
*/
func (o *APIHandler) GetImSessions(r *http.Request, headers *CommonHeaders, sequence uint64) (string,error) {
	// 参数检查

	meUid, err := o.queryUserIdByToken(headers.UserToken)
	if err != nil || meUid == -1 {
		log4go.Error("GetImSessions(): User token(%s) invalid, error = %s", headers.UserToken, err)
		result := ResponseInfo{ Code: RET_TOKEN_EXPIRED, Msg: MSG_TOKEN_EXPIRED }
		return formatJson(result),nil
	}
	log4go.Debug("GetImSessions() called, meUid=%d ...", meUid)	

	allSessions, err := o.querySessionsOfOneUser(meUid)
	if err != nil {
		result := ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
		return formatJson(result),nil		
	}
	log4go.Debug("GetImSessions(): total loaded %d sessions of user [%d]", len(allSessions), meUid)	

	nowTime := time.Now().Unix()
	if len(allSessions) == 0 {
		result := ResponseInfo { Code: RET_OK,
			Msg: MSG_OK,
			Data: FetchSessionsResp {
				NowTime: transUnixTime2DateString(nowTime),
				List: EMPTY_SESSION_LIST,
				NextInterval: 30*1000,
			},
		 }

		return formatJson(result),nil		
	}

	otherUidList := make([]int64, 0, len(allSessions))
	for _, sessionLite := range allSessions {
		//log4go.Debug("GetImSessions(): sessionLite is [ %v ]", sessionLite)
		otherUidList = append(otherUidList, sessionLite.UserId)
	}
	otherUsers, err := o.GetUsrInfoByIdList(otherUidList)
	if err != nil {
		result := ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
		return formatJson(result),nil		
	}
	
	log4go.Debug("GetImSessions(): total find %d other-users for such sessions", len(otherUsers))	
	uid2LiteInfo := make(map[int64]UserRespLite)
	
	for _, userInfo := range otherUsers {
		var userLite UserRespLite
		userLite = UserRespLite { 
						UserId: userInfo.UserId+DUOBAO_USER_ID_BASE, 
						Nickname: userInfo.Nickname, 
						Gender: userInfo.Gender,
						Avatar: userInfo.Avatar,
					}
		uid2LiteInfo[userInfo.UserId] = userLite
	}
	
	lastMsgIdList := make([]int64, 0, len(allSessions))
	retSessions := make([]ImSessionRespInfo, 0, len(allSessions))
	retCount := 0
	for _, sessionLite := range allSessions {

		msgInDb, err := o.getSessionLastMsg(sessionLite.SessionId)
		if err != nil || msgInDb == nil {
			continue
		}

		lastMsg := o.transformSessionMessage(msgInDb)
		if lastMsg == nil {
			continue
		}
		lastMsgIdList = append(lastMsgIdList, lastMsg.MsgId)
		unreadNum, _ := o.queryMyUnreadMsgNumInOneSession(meUid, sessionLite.SessionId)

		curUser, ok := uid2LiteInfo[sessionLite.UserId]
		if !ok {
			continue
		}

		sessionInfo := ImSessionRespInfo{
			Session: ImSessionBasicInfo { Sid: sessionLite.SessionId } ,
			OtherUsers: []UserRespLite { curUser },
			LastMessage: lastMsg,
			UnreadNum: unreadNum,
		}
		retSessions = append(retSessions, sessionInfo)
		retCount++
		if retCount >= 10 {
			break
		}
	}

	msgId2status, err := o.queryMultiMsgReadedStatus(lastMsgIdList)
	if msgId2status != nil {
		for idx, _ := range retSessions {
			sessionInfo := &retSessions[idx]
			status, ok := msgId2status[sessionInfo.LastMessage.MsgId]
			if ok {
				sessionInfo.LastMessage.ReadFlag = status
			}
		}
	}
	
	result := ResponseInfo { Code: RET_OK,
		Msg: MSG_OK,
		Data: FetchSessionsResp {
			NowTime: transUnixTime2DateString(nowTime),
			List: retSessions,
			NextInterval: 5000, // 前端使用毫秒
		},
	 }

	return formatJson(result),nil
}

/*
*  查询会话的详细信息
*  基本逻辑:   0. 检查请求参数是session_id还是to_uid
*                 > 如果是sesson_id,需要检查session_id是否有效
*                 > 如果是to_uid,需要根据to_uid查询到session_id
*             1. 从ihp_t_imsession_users查询用户列表
*             2. 去ihp_t_imsession_messages表查询最后一条消息
*             2. 将去ihp_t_message表查询该session未读消息数量
*             3. 
*/
func (o *APIHandler) QuerySessionDetails(r *http.Request, headers *CommonHeaders, sequence uint64) (string,error) {
	// 参数检查
	clientReq, retCode, retMsg := handleQuerySessionParams(r, headers)
	if clientReq == nil {
		result := ResponseInfo{ Code: retCode, Msg: retMsg }
		return formatJson(result), nil
	}	

	meUid, err := o.queryUserIdByToken(headers.UserToken)
	if err != nil || meUid == -1 {
		log4go.Error("QuerySessionDetails(): User token(%s) invalid, error = %s", headers.UserToken, err)
		result := ResponseInfo{ Code: RET_TOKEN_EXPIRED, Msg: MSG_TOKEN_EXPIRED }
		return formatJson(result),nil
	}	

	sessionId := ""
	otherUid := int64(-1)
	if len(clientReq.SessionId) > 0 {
		// session_id 有效
		isValid, _ := o.isValidSessionId(clientReq.SessionId)
		if !isValid {
			log4go.Error("QuerySessionDetails(): cant find such session '%s' in db.", clientReq.SessionId)
			result := ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID }
			return formatJson(result), nil			
		}
		sessionId = clientReq.SessionId
	}else{
		sid, err := o.querySessionByFromAndToUser(meUid, clientReq.ToUid)
		if err == nil && len(sid) > 0 {
			sessionId = sid
			otherUid = clientReq.ToUid
		}else{
			if isHelperAccount(clientReq.ToUid) &&  meUid != clientReq.ToUid {
				// 当用户主动和"一起飞"账号聊天, 创造一个session，模拟"一起飞"主动打招呼的场景
				sid, err = o.simulateSendMsg(clientReq.ToUid, meUid, "text", o.sc.HelperGreetingMsg)
				if err == nil && len(sid) > 0 {
					sessionId = sid
				}
			}

			if sessionId == "" {
				log4go.Warn("QuerySessionDetails(): cant find such session by to_uid [%d]", clientReq.ToUid)
				result := ResponseInfo{ Code: RET_OK, Msg: MSG_OK }
				return formatJson(result), nil										
			}
		}
	}

	if otherUid == -1 {
		// 查询session的其他用户
		log4go.Debug("try to query other userId by sessionId '%s'...", sessionId)
		otherUidList, err := o.queryOtherUsersBySessionId(sessionId, meUid)
		if err != nil || len(otherUidList) == 0 {
			log4go.Error("QuerySessionDetails(): cant find other users in session '%s'", sessionId)
			result := ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
			return formatJson(result), nil									
		}

		otherUid = otherUidList[0]
	}
	otherUser, err := o.queryUserLiteInfoById(otherUid)
	if err != nil {
		log4go.Error("QuerySessionDetails(): cant find other user detail by userId [%d]", otherUid)
		result := ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
		return formatJson(result), nil											
	}

	msgInDb, err := o.getSessionLastMsg(sessionId)
	if err != nil {
		log4go.Error("QuerySessionDetails(): load last message error [ %s ]", err)
		result := ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
		return formatJson(result), nil	
	}
	lastMsg := o.transformSessionMessage(msgInDb)
	readedStatus, _ := o.queryMsgReadedStatus(msgInDb.MsgId)
	lastMsg.ReadFlag = readedStatus

	unreadNum, _ := o.queryMyUnreadMsgNumInOneSession(meUid, sessionId)

	sessionInfo := ImSessionRespInfo {
		Session: ImSessionBasicInfo { Sid: sessionId },
		OtherUsers: []UserRespLite { *otherUser },
		LastMessage: lastMsg,
		UnreadNum: unreadNum,
	}
	result := ResponseInfo { 
		Code: RET_OK,
		Msg: MSG_OK,
		Data: sessionInfo,
	}	

	return formatJson(result),nil
}

func (o *APIHandler)simulateSendMsg(fromUid, toUid int64, msgType, msgContent string) (string, error) {
	log4go.Debug("simulateSendMsg(): fromUid=%d, toUid=%d, msgContent='%s'.", fromUid, toUid, msgContent)

	clientReq := sendMsgClientReq {
		ToUid: toUid,
		SessionId: "",
		MsgType: msgType,
		MsgContent: msgContent,
	}	

	nowUnix := time.Now().UnixNano() / int64(time.Millisecond)
	_, _, sessionId, err := o.sendMsgImpl(&clientReq, fromUid, nowUnix, false)
	return sessionId,err
}
