package duobao

type ResponseInfo struct {
	Code	int  `json:"code"`
	Msg 	string `json:"msg"`
	Data	 interface{} `json:"data"`
}

type CommonDataList struct {
	List interface{} `json:"list"`
	AdList interface{} `json:"adlist,omitempty"`
}

type LoginRetInfo struct {
	UserId int64 `json:"user_id"`
	Nickname string `json:"nickname"`
	Gender string `json:"gender"`
	Token  string `json:"token"`
	Avatar string `json:"avatar"`
	Location string `json:"location"`
	PlatformName string `json:"platform_name"`
	BindingMobile string `json:"binding_mobile"`
	//UserVerify string `json:"user_verify"`
	CartGoodsNum int `json:"cart_goods_num"` // 清单货品个数
}

type UserRespLite struct {
	UserId       int64     	`json:"user_id"`
	Nickname     string  	`json:"nick_name"`
	Gender       string    	`json:"gender"`
	Avatar		 string 	`json:"avatar_url"`
}


type YunpianResp struct {
	Code int `json:"code"`
	Msg string `json:"msg"`
	Result interface {} `json:"result"`
}

// batchno
type XieheResp struct {
	Code int `json:"code"`
	Batchno string `json:"batchno"`
}


/*=============================================================================*/
type BannerResp struct {
	Id   int64 `json:"item_id"`
	Image  string `json:"image"`
	RefUrl string `json:"ref_url"`
}

type IndexLuckyResp struct {
	UserId    int64 `json:"uid"`
	Nickname  string `json:"nick_name"`
	GoodsName string `json:"gname"`
	Period int64  	`json:"period"`
	RefUrl 	  string `json:"ref_url"`
}

type Thumbnail struct {
	SmallPic string `json:"small_pic"`
	BigPic   string `json:"big_pic"`
}

type GoodsImage struct {
	ImageUrl string `json:"imgurl"`
	Width int `json:"width"`
	Height int `json:"height"`
}

// 参与夺宝的时间和号码
type OwnerAllCode struct {
	Time  	string   `json:"join_time"` 		// 用户下单时间
	Total 	int		`json:"join_total"`		// 本单得到的号码数量
	Code 	string  `json:"code_list"`	    // 本单得到的号码列表
}

type GoodsDetail struct {
	GoodsImages []GoodsImage `json:"image_list"`
}

// 一次夺宝记录
type DuobaoRecord struct {
	Time  string   	`json:"join_time"` 	// 用户下单时间
	Total int	    `json:"total"` 		// 用户本次参与x人次
	Owner OwnerInfo  `json:"owner"` 		// 用户信息
}

type DuobaoRecords struct {
	Items []DuobaoRecord `json:"items"`
}

type OnePageDuobaoRecords struct {
	Items []DuobaoRecord `json:"items"`
	NextPageToken string `json:"next_page_token"`
}

type DuobaoLuckyInfo struct {
	LuckyCode string `json:"lucky_code"` 	// 幸运号码
	CodeTotal int 	`json:"code_total"`   	// 用户本次参与x人次
	Owner OwnerInfo  `json:"owner"` 		// 用户信息
	//OrderNo string   `json:"sub_order_no"` 	// 订单号
	//PublishAt int64  `json:"publish_time"`  // 揭晓时间
}

type MyJoinedInfo struct {
	UserId    	int64 	`json:"uid"`
	CodeTotal 	int   	`json:"code_total"`  // 用户本次参与x人次
	Time  		string  `json:"join_time"` 	// 用户下单时间
	CodeList  	string  `json:"code_list"` 	// 号码列表
}

// 往期(已揭晓)一次夺宝记录
type PreDuobaoRecord struct {
	Period int64  	`json:"period"`
	PublishTm string `json:"publish_time"` 	// 中奖揭晓时间
	JoinTime int64 	`json:"join_time"`  		// 参与夺宝时间	
	Total int	    `json:"total"` 			// 用户本次参与x人次
	Owner OwnerInfo `json:"owner"` 			// 用户本次参与x人次
	LuckyCode string `json:"lucky_code"`  	// 幸运号码
}

// 已揭晓 截止该商品最后夺宝时间最后50条全站参与记录
type DuobaoResultRecord struct {
	UserId    int64 		`json:"uid"`
	Time  	  string    `json:"time"`
	TimeValue  string    `json:"time_value"`
	Nickname  string  	`json:"nick_name"`
}

type PreDuobaoRecords struct {
	Items []PreDuobaoRecord `json:"items"`
	NextPageToken string `json:"next_page_token"`
}

type DuobaoResultRecords struct {
	Status 	  	int     `json:"status"`
	ValueA 	  	int64   `json:"value_a"`
	ValueB 	  	int64   `json:"value_b"`
	SscPeriod 	string  `json:"ssc_period"`
	LuckyCode 	string 	`json:"lucky_code"`	
	List []DuobaoResultRecord `json:"joined_list"`
}

// 
type OwnerInfo struct {
	UserId       int64   `json:"uid"`
	Nickname     string  `json:"nick_name"`
	Gender       string  `json:"gender,omitempty"`
	AvatarPath  	string  	`json:"avatars_url"`
	LastIP		string  	`json:"user_ip"`
	City	 		string	 `json:"city"`
	AddrDefaultCode int   `json:"addr_default_code,omitempty"`
	AddrDeliveryCode int  `json:"addr_delivery_code,omitempty"`
	PlatformName  string  `json:"plateform_reg,omitempty"` 
	HasNewMsg	 int	 `json:"has_new_message"`		
}

// 商品概要信息
type GoodsSummaryResp struct {
	Status int    `json:"status"` 				// 1-夺宝进行中; 2-揭晓倒计时中 ; 3-已揭晓
	Period int64  `json:"period"`
	PublishTime string  `json:"publish_time"` 		// 中奖揭晓时间
	PubCountDown int64    `json:"pub_countdown"`	// 中奖揭晓剩余秒数，揭晓倒计时用
	GoodsId int64    	`json:"gid"`
	GoodsName string    `json:"gname"`
	GoodsDesc string    `json:"gdesc"`
	TotalTimes int    	`json:"total_times"`
	RemainingTimes int 	`json:"remaining_times"`
	BuyUnit 		int    	`json:"buy_unit"`
	LuckyCode 	string 	`json:"lucky_code"`
	LuckyUser 	string 	`json:"lucky_guy"`
	LuckyUid 	int64   `json:"lucky_uid"`
	LuckyBuyTotal 	int `json:"lucky_buy_total"`	// 中奖人本期购买的总数
	CoverImage string   `json:"cover_image"`    	// 封面图片 
	Thumbnails []Thumbnail `json:"thumbnail_list"` 	// 商品图片
	ShowTag string    	`json:"show_tag"`       	// 专区标识
}

// 首页数据
type IndexRespInfo struct {
	CartGoodsNum int `json:"cart_goods_num"` // 清单货品个数
	BannerList []BannerResp `json:"banner_list`
	LuckyList []IndexLuckyResp `json:"lucky_list`
	GoodsList []GoodsSummaryResp `json:"goodsList`
}

// 活动详情
type ActivityDetailRespInfo struct {
	Status int    `json:"status"`								// 1-夺宝进行中; 2-揭晓倒计时中 ; 3-已揭晓
	Period int64  `json:"period"`								// 期号
	NextPeriod int64  `json:"next_period"`					// 下期期号
	Tips   string `json:"tips"`								// 夺宝提示(可不要?)
	StartTime string `json:"start_time"`				    		// 开始时间
	PubCountDown int64  `json:"pub_countdown"`				// 中奖揭晓剩余秒数，揭晓倒计时用
	PublishTime string  `json:"publish_time"`					// 揭晓时间
	Goods GoodsSummaryResp `json:"goods"` 					// 商品概要描述
	LuckyInfo DuobaoLuckyInfo `json:"lucky_info,omitempty"`   // 幸运用户信息
	JoinedInfo MyJoinedInfo `json:"my_joined_info,omitempty"` // 我参与信息
	Records OnePageDuobaoRecords `json:"latest_records"` 		// 参与记录
}

// 商品详情
type GoodsDetailRespInfo struct {
	DescList []GoodsImage `json:"desc_list"`  // 商品详情图列表
}


type CartListRespInfo struct {
	Status 		int    	`json:"status"` 		// 1-夺宝进行中; 2-揭晓倒计时中 ; 3-已揭晓
	Period 		int64  	`json:"period"`
	PublishTime int64  	`json:"publish_time"` 	// 中奖揭晓时间，揭晓倒计时用
	GoodsId 	int64   `json:"gid"`
	GoodsName 	string  `json:"gname"`
	TotalTimes 	int64   `json:"total_times"`
	RemainingTimes int64 `json:"remaining_times"`
	BuyUnit 		int    	`json:"buy_unit"`
	BuyTotal 	int    	`json:"buy_total"`
	Thumbnails 	string 	`json:"thumbnail"` 		// 商品图片
	ShowTag 	string  `json:"show_tag"`       // 专区标识
}

// 单条下单
type SingleOrder struct {
	Period 		int64  	`json:"period"`
	GoodsId 		int64   `json:"gid"`
	GoodsName 	string  `json:"gname"`
	BuyUnit 		int    	`json:"buy_unit"`
	BuyTotal 	int    	`json:"buy_total"`
	SubTotal 	int     `json:"sub_total"`
}

// 用户下单上传参数
type UploadOrderReq struct {
	Signed 		string `json:"signature"` 	// 加密认证
	AmountTotal 	int    `json:"amount_total"` // 下单总价
	Gold 		int    `json:"gold"`			// 抵扣金币(元)
	Amount 		int    `json:"amount"`    	// 实付金额
	SumTotal 	int    `json:"sum_total"` 	// 购买总人次
	Channel 		string `json:"charge_channel"` // 支付方式
	OpenId 		string `json:"open_id"` 		// 支付方式
	List []SingleOrder `json:"list"` 			// 单条下单信息
}

type RetChargeRespInfo struct {
	IsNeedPay int `json:"is_need_pay"`
	OrderNo string `json:"order_no"`
	ChargeObj *ChargeInfo `json:"charge_obj"`
}

// 下单返回
type OrderResp struct {
	Amount 		int 		`json:"amount"`    	// 总额
	OrderTime 	int64   `json:"order_time"` 	// 下单时间
	OrderNo 		string 	`json:"order_no"` 	// 订单号
}

type LuckyOwnerInfo struct {
	UserId       int64   `json:"uid"`
	Nickname     string  `json:"nick_name"`
	BuyTotal     int  	`json:"buy_total"`		
}
	
// 参与夺宝
type MyJoinedResp struct {
	Status 		int    	`json:"active_status"` // 夺宝状态
	GoodsStatus 	int    	`json:"goods_status"` // 货品状态
	Period		int64 	`json:"period"`	
	PublishTime string   `json:"publish_time"`
	GoodsId 		int64   `json:"gid"`
	GoodsName 	string  `json:"gname"`	
	TotalTimes 	int    	`json:"total_times"`
	RemainingTimes int 	`json:"remaining_times"`
	BuyUnit 		int    	`json:"buy_unit"`
	Thumbnails 	string  `json:"thumbnail"` 			
	ShowTag   	string  `json:"show_tag"`
	Time  		string  `json:"time"` 		 // 用户下单时间
	BuyTotal    int  	`json:"buy_total"`
	IsBingo 		int 		`json:"is_bingo"`	 // 用户是否中奖	
	LuckyCode string 	`json:"lucky_code"`   // 幸运号码
	LuckyOwner LuckyOwnerInfo `json:"lucky_owner,omitempty"`	 // 中奖用户信息
}

// 地址信息
type UserAddrInfoResp struct {
	Code		int	  	`json:"code"`    
	Nickname	string  `json:"nick_name"`
	Mobile      string  `json:"mobile"`
	Address 	string  `json:"address"` 	
	IsDefault 	int 	`json:"is_default"` // 是否默认地址
	Signed 		string 	`json:"signature,omitempty"` 	// 加密认证
}

// 支付子单信息
type ChargeSubOrder struct {
	UserId      int64
	OrderNo 		string     // 子订单号
	Period 		int64  
	GoodsId 		int64  
	BuyUnit 		int    
	BuyTotal 	int    	
	SubTotal 	int  
	Gold        int  
}		

// 插入订单返回信息
type InsertOrderResp struct {
	MainOrderNo 	string     		// 主订单号
	InsertTime  int64			// 插入时间(毫秒级)
	mapSubOrder map[int64]string // 期号->子订单号
}

// 获取微信token返回
type WxAccTokenResp struct {
	AccToken 		string   `json:"access_token"` // 
	ExpireIn 		int   	`json:"expires_in"`
	RefreshToken 	string   `json:"refresh_token"`
	OpenId 			string   `json:"openid"`
	Scope 			string   `json:"scope"`
}

// 获取微信公众号开发config返回
type WxPubDevCfgResp struct {
	Appid 		string   `json:"app_id"` 
	TimeStamp 	int64   	`json:"time_stamp"`
	Noncestr 	string   `json:"noncestr"`
	Signature 	string   `json:"signature"`
}

// 获取微信用户信息返回
type WxUserInfoResp struct {
	OpenId 		string   `json:"openid"` 
	NickName 	string   `json:"nickname"`
	Sex 			int		 `json:"sex"`
	Province 	string   `json:"province"`
	City 		string   `json:"city"`
	Country 		string   `json:"country"`
	HeadImgUrl 	string   `json:"headimgurl"`
}

// 获取QQ用户信息返回
type QQUserInfoResp struct {
	OpenId 		string   `json:"openid"` 
	NickName 	string   `json:"nickname"`
	Gender 		string	 `json:"gender"`
	Province 	string   `json:"province"`
	City 		string   `json:"city"`
	Year 		string   `json:"year"`
	HeadImgUrl 	string   `json:"figureurl_qq_1"`
}

// 支付通知子单返回信息
type ChargeSubOrderResp struct {
	SubOrderNo 	string    `db:"order_no" json:"sub_order_no"` // 子订单号
	Period 		int64   	  `db:"period" json:"period"`
	GoodsId 		int64     `db:"goods_id" json:"goods_id"`
	GoodsName   string    `db:"title" json:"gname"`
	BuyTotal 	int       `db:"buy_total" json:"buy_total"`
	Status 		int       `db:"status" json:"status"`
	CodeList  	[]string  `json:"code_list"` 	  // 号码列表
}

// 支付通知返回
type ChargeSuccResp struct {
	UserId      int64  `json:"user_id"`
	GoodNum		int   `json:"goods_num"` 
	SumTotal 	int   `json:"sum_total"` 
	NextAccessTm int   `json:"next_time"` // 过几秒后重新访问，0代表已成功，不用重新访问
	SubList		[]ChargeSubOrderResp `json:"sub_list"`
}

// 获取金币明细
type GetGoldDetailResp struct {	
	Message	string   `json:"message"`
	Time  string `json:"time"`
}

// 我的金币页面
type MyGoldResp struct {
	NextPageToken string `json:"next_page_token"`
	GoldNum		float32   `json:"gold_num"` 
	GetDetail 	[]GetGoldDetailResp   `json:"get_detail"` 
}

// 期号-商品
type PeriodGoodsSt struct {	
	Period	int64   `json:"period"`
	GoodsName string `json:"gname"`
}

// 使用金币明细
type UseGoldDetailResp struct {	
	PeriodGoods []PeriodGoodsSt `json:"period_list"`
	UsedGold  float32 `json:"used_gold"`
	RestGold  float32 `json:"rest_gold"`
	Time  string `json:"time"`
}
