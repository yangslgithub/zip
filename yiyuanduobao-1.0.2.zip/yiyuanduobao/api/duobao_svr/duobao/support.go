package duobao

import (
	"strings"
	"fmt"
	"encoding/json"
	"database/sql"
	"io/ioutil"
	"net/http"
	"time"
	"github.com/alecthomas/log4go"
)

type userLocationInfo struct {
	Country string `db:"country"`
	Province string `db:"province"`
	City string `db:"city"`
	Location string `db:"location"`
}

// 用户id+Ip查询location
type LocationQuryEntity struct {
	usrId int64
	ip    string
}

// 存储地址库位置具体信息
type addrInfoDetail struct {
	Country  string `json:"country"` // 国家
	Area     string `json:"area"`    // 地区
	Province string `json:"region"`  // 省(区)
	City     string `json:"city"`    // 城市
}

// 存储地址库网站返回的位置信息
type addrQueryInfo struct {
	Code int            `json:"code"` // 返回码
	Data addrInfoDetail `json:"data"` // 位置信息
}

// 淘宝通过ip查询位置信息的URL
var g_strQueryLocaTbAddr string = "http://ip.taobao.com/service/getIpInfo.php?ip="

func (o *APIHandler) httpGetLocationFromTaobao(ip string) (addrInfo *addrQueryInfo, err error) {
	var addrInfo_b []byte
	resp, err := http.Get(g_strQueryLocaTbAddr + ip)
	log4go.Debug("httpGetLocationFromTaobao(): url = %s", g_strQueryLocaTbAddr+ip)
	if err != nil {
		log4go.Error("httpGetLocationFromTaobao(): error [ %s ]", err)
		return nil, err
	}

	defer resp.Body.Close()
	addrInfo_b, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	//log4go.Debug("Taobao return data : %s", string(addrInfo_b))
	addrInfo = &addrQueryInfo{}
	err = json.Unmarshal(addrInfo_b, addrInfo) // JSON to Struct
	if err != nil {
		log4go.Error("httpGetLocationFromTaobao JSON to Struct(): error [ %s ]", err)
		return addrInfo, err
	}
	return addrInfo, err
}

func (o *APIHandler) FillOneLocationMaybe(entity LocationQuryEntity) error {
	log4go.Info("FillOneLocationMaybe usrid: %d, ip: %s", entity.usrId, entity.ip)
	// 去数据库user表和location_maybe表查询该用户是否已填入有位置信息，以CITY是否填入为准
	locInfo, err := o.queryCityByUserid(entity.usrId)
	if err != nil {
		log4go.Error("FillOneLocationMaybe(): error [ %s ]", err)
		return err
	}

	// 无地址信息
	if (locInfo == nil) || (len(locInfo.Province) == 0 && len(locInfo.City) == 0) {
		// 去淘宝查询位置信息
		addrInfo, err := o.httpGetLocationFromTaobao(entity.ip)
		if err != nil {
			log4go.Error("httpGetLocationFromTaobao() return: error [ %s ]", err)
			return err
		}

		// 查询ip位置信息返回成功
		if 0 == addrInfo.Code {
			// 省名统一
			if len(addrInfo.Data.Province) > 0 {
				str := GetProvinceFullName(addrInfo.Data.Province)
				if str != "" {
					addrInfo.Data.Province = str
				}
			}
			// 更新location mayber表
			err = o.updateLocationMaybe(&addrInfo.Data, entity.usrId)
		}
	}
	return err
}

// 根据userid先从ihp_t_users表查位置信息，没有再查ihp_user_location_maybe
// 都没查到位置,如果location_maybe没有用户位置记录则插入，有则更新
func (o *APIHandler) queryCityByUserid(userid int64) (*userLocationInfo, error) {
	dbMap, tableName := o.GetUserDBMap()

	var locInfo userLocationInfo

	sqlQuery := fmt.Sprintf("SELECT province, city, location FROM %s WHERE user_id=%d", tableName, userid)
	err := dbMap.SelectOne(&locInfo, sqlQuery)
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Info("queryCityByUserid(): can't find location in user table by userId [%d]", userid)
		}else {
			log4go.Error("queryCityByUserid() query db error:  %s", err)
			return nil, err
		}
	}

	if len(locInfo.Province) > 0 || len(locInfo.City) > 0 {
		return &locInfo, nil
	}

	dbMap, tableName = o.GetUserLocationMaybeDbMap()
	sqlQuery = fmt.Sprintf("SELECT province, city FROM %s WHERE user_id = %d", tableName, userid)
	err = dbMap.SelectOne(&locInfo, sqlQuery)
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Info("queryCityByUserid(): can't find location in user_location_maybe table by userId [%d]", userid)
			return nil, nil
		}else {
			log4go.Error("queryCityByUserid() query user_location_maybe table error:  %s", err)
			return nil, err
		}
	}
	return &locInfo, err
}

// 更新ihp_user_location_maybe位置信息
func (o *APIHandler) updateLocationMaybe(addrDetail *addrInfoDetail, userid int64) error {
	dbMap, tableName := o.GetUserLocationMaybeDbMap()

	country := addrDetail.Country
	province := addrDetail.Province
	city := addrDetail.City

	log4go.Debug("updateLocationMaybe() country:%s, province:%s, city:%s, %d, %d", country, province, city, userid)

	sqlCommand := fmt.Sprintf("INSERT INTO %s (user_id, country, province, city, location, by_what) "+
		"VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE country=?, province=?, city=?, location=?, by_what=?", tableName)

	_, err := dbMap.Exec(sqlCommand, userid, country, province, city, "", "ip", country, province, city, "", "ip")
	if err != nil {
		log4go.Error("updateLocationMaybe(): UPDATE ihp_user_location_maybe userid:%d error [ %s ]", userid, err)
		return err
	}
	return nil
}

// go runtine补全用户位置信息(表ihp_user_location_maybe)
func (o *APIHandler) FillLocationMaybe() error {
	for entity := range o.locationChannel {
		o.FillOneLocationMaybe(entity)
	}

	return nil
}

// 根据当前时间获取时时彩的下期开奖期号和开奖时间 返回 1-最近开奖期号; 2-最近准备开奖期号; 3-最近已开奖时间
func (o *APIHandler) GetCqsscPeriod(nowUnix int64) (string, string, int64, int64) {	
	
	// 最近准备开奖期号
	var periodNoNex string
	// 最近上期开奖期号
	var periodNoPre string	
	// 最近开奖期时间
	var openTimePre int64
	// 最近下期开奖期时间
	var openTimeNex int64
	
	// 销售时间：10:00-22:00，共72期    22:00-01:55，共48期
	nowTm := time.Unix(nowUnix, 0)	
	nowTmStr := nowTm.Format("20060102 15:04:05") // 15代表24小时制
	dateStr := nowTmStr[:8]
	
	log4go.Debug("GetCqsscPeriodNo ...... ")
	log4go.Debug("GetCqsscPeriodNo nowTmStr: %s, nowUnix:%d", nowTmStr, nowUnix)
		
	// 今天早上10点unixtime
	T10TmStr := fmt.Sprintf("%s 10:00", dateStr) /*20160606 10:00*/
	T10TmUnix, _ := time.ParseInLocation("20060102 15:04", T10TmStr, time.Local)
	
	// 今天晚上22点unixtime
	T22TmStr := fmt.Sprintf("%s 22:00", dateStr) /*20160606 22:00*/
	T22TmUnix, _ := time.ParseInLocation("20060102 15:04", T22TmStr, time.Local)	
	
	// 今天凌晨0点unixtime
	T00TmStr := fmt.Sprintf("%s 00:00", dateStr) /*20160606 00:00*/
	T00TmUnix, _ := time.ParseInLocation("20060102 15:04", T00TmStr, time.Local)
	
	// 今天凌晨2点unixtime
	T02TmStr := fmt.Sprintf("%s 02:00", dateStr) /*20160606 02:00*/
	T02TmUnix, _ := time.ParseInLocation("20060102 15:04", T02TmStr, time.Local)
	
	log4go.Debug("T00TmStr:%s, T10TmStr:%s, T22TmStr:%s, T02TmStr:%s", T00TmStr, T10TmStr, T22TmStr, T02TmStr)
	log4go.Debug("T02TmUnix:%d, T10TmUnix:%d, T22TmUnix:%d, T02TmUnix:%d", T00TmUnix.Unix(), T10TmUnix.Unix(), T22TmUnix.Unix(), T02TmUnix.Unix())	
	
	// 00:00-02:00 5分钟一期 0点开始，算第一期
	if nowUnix >= T00TmUnix.Unix() && nowUnix < T02TmUnix.Unix() {
		interval := (nowUnix - T00TmUnix.Unix()) / 300
		periodNoNex = fmt.Sprintf("%s%03d", dateStr, interval+1)
		periodNoPre = fmt.Sprintf("%s%03d", dateStr, interval)
		openTimeNex = T00TmUnix.Unix() + (interval+1)*300
		openTimePre = T00TmUnix.Unix() + interval*300
		if nowUnix - T00TmUnix.Unix() < 300 { // 昨天最后一期
			LastTm := time.Unix(nowUnix-300, 0)	
			LastTmStr := LastTm.Format("20060102 15:04:05") 
			lastDateStr := LastTmStr[:8]
			periodNoPre = fmt.Sprintf("%s120", lastDateStr)
			openTimeNex = T00TmUnix.Unix()
		}
	} else if nowUnix >= T02TmUnix.Unix() && nowUnix <= T10TmUnix.Unix() { 
		periodNoNex = fmt.Sprintf("%s%03d", dateStr, 25)
		periodNoPre = fmt.Sprintf("%s%03d", dateStr, 24)
		openTimeNex = T10TmUnix.Unix() // 10点开奖
		openTimePre = T02TmUnix.Unix()
	} else if nowUnix >= T10TmUnix.Unix() && nowUnix < T22TmUnix.Unix() {	
		interval := (nowUnix - T10TmUnix.Unix()) / 600
		periodNoNex = fmt.Sprintf("%s%03d", dateStr, 24+interval+1)
		periodNoPre = fmt.Sprintf("%s%03d", dateStr, 24+interval)
		openTimeNex = T10TmUnix.Unix() + (interval+1)*600
		openTimePre = T10TmUnix.Unix() + interval*600
	} else if nowUnix >= T22TmUnix.Unix() && nowUnix < (T00TmUnix.Unix()+86400) { // 22:00-24:00 5分钟一期
		interval := (nowUnix - T22TmUnix.Unix()) / 300
		periodNoNex = fmt.Sprintf("%s%03d", dateStr, 96+interval+1)
		periodNoPre = fmt.Sprintf("%s%03d", dateStr, 96+interval)
		openTimeNex = T22TmUnix.Unix() + (interval+1)*300	
		openTimePre = T22TmUnix.Unix() + interval*300
	} 
	return periodNoPre, periodNoNex, openTimePre, openTimeNex
}

// 获取最近一期时时彩的中奖号码
func (o *APIHandler)GetSscOpenCode(sscPeriod string) (string) {
	log4go.Info("GetSscOpenCode() sscPeriod: %s", sscPeriod)
	var xmlData []byte	
	
	if len(sscPeriod) != 9 {
		log4go.Info("GetSscOpenCode() sscPeriod:%s Invalid", sscPeriod)
		return ""
	}
	dateString := fmt.Sprintf("20%s", sscPeriod[:6])
	url := fmt.Sprintf("%s%s.html", DUOBAO_QCSSC_URL, dateString)
	log4go.Info("GetSscOpenCode() url: %s", url)
	resp, _ := http.Get(url)
	
	defer resp.Body.Close()
	
	xmlData, _ = ioutil.ReadAll(resp.Body)		
	xmlString := string(xmlData)	
	//log4go.Info("xmlData: %s", string(xmlData))
	
	target := fmt.Sprintf("data-period=\"%s\"", sscPeriod) 
	pos1 := strings.Index(xmlString, target)
	log4go.Info("pos1: %d", pos1)
	
	if pos1 <= 0 {
		log4go.Error("Can not find pos for %s", target)
		return ""
	}
		
	sourceStr := xmlString[pos1-50:pos1+32]
	log4go.Info("sourceStr: %s", sourceStr)	
	dataWinConStr := "data-win-number="
	pos2 := strings.Index(sourceStr, dataWinConStr)
	if pos2 <= 0 {
		return ""
	}
	
	pos3 := strings.Index(sourceStr, "'")
	if pos3 <= 0 || pos3 < pos2 {
		return ""
	}
	openCodeTmp := sourceStr[pos3+1:pos3+10]	
	openCodeStr := strings.Replace(openCodeTmp, " ", "", -1)
	log4go.Info("openCodeStr: %s", openCodeStr)
	
	return openCodeStr	
}

// 获取最近一期时时彩的中奖号码 routine
func (o *APIHandler)GetSscOpenCodeRoutine() (error) {
	sleepSeconds := 60   // 
	for {	
		time.Sleep(time.Duration(sleepSeconds) * time.Second)
		hh, mm, ss := time.Now().Clock()		
		log4go.Info("GetSscOpenCodeRoutine routine will sleep %d seconds......%d:%d:%d", sleepSeconds, hh,mm,ss)
		if (hh <= 2 ) || hh >= 10 { // 凌晨2点-早上10点，不用去获取。	
			// 最近开奖的一期时时彩期号
			nowUnix := time.Now().Unix()
			periodNo, _, openTime, _ := o.GetCqsscPeriod(nowUnix) // 最近一期开奖的期号 
			periodStr := periodNo[2:]
			log4go.Info("GetSscOpenCodeRoutine periodNo=%s", periodStr)
			// 获取时时彩的开奖号码
			openCode := o.GetSscOpenCode(periodStr)
			// 写入数据库
			o.InsertSscOpenInfoDb(periodNo, openCode, openTime)
		}
	}
}


func (o *APIHandler)GetWxPubApiCfgInfoFun() (error) {	
	log4go.Info("GetWxPubApiCfgInfoFun ......")
	token, err := o.GetWxPubApiTokenImpl()
	if err == nil && token != nil {
		o.GetWxPubApiTicketImpl(token)
	}
	return err
}
// 获取微信api开发配置信息 routine
func (o *APIHandler)GetWxPubApiCfgInfoRoutine() (error) {
	sleepSeconds := 3600   // 
	for {	
		time.Sleep(time.Duration(sleepSeconds) * time.Second)
		hh, mm, ss := time.Now().Clock()		
		log4go.Info("GetWxPubApiCfgInfoRoutine routine will sleep %d seconds......%d:%d:%d", sleepSeconds, hh,mm,ss)
		o.GetWxPubApiCfgInfoFun()			
	}
}
