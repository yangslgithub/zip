package duobao

type ImSessionBasicInfo struct {
	Sid string `json:"sid"`
	AvatarUrl string `json:"avatar_url"`
	Name string `json:"name",omitempty`
}

type ImMsgRespInfo struct {
	MsgId int64 `json:"msg_id"`
	MsgType string `json:"msg_type"`
	MsgContent string `json:"msg_content"`
	MsgTs string `json:"msg_ts"`
	FromUser *UserRespLite `json:"from_user"`
	ReadFlag int `json:"read_flag"`
}

type ImSessionRespInfo struct {
	Session ImSessionBasicInfo `json:"session"`
	OtherUsers []UserRespLite `json:"other_users"`
	LastMessage *ImMsgRespInfo `json:"last_message"`
	UnreadNum int64 `json:"unread_num"`
}

type FetchSessionsResp struct {
	NowTime string `json:"now_time"`
	List []ImSessionRespInfo `json:"list"`
	NextInterval int `json:"next_interval"`
}

type RecvSessionMsgsResp struct {
	List []ImMsgRespInfo `json:"list"`
	NextInterval int `json:"next_interval"`
}

type SendImMsgData struct {
	MsgId int64 `json:"msg_id"`
	MsgTs int64 `json:"msg_ts"`
	Session ImSessionBasicInfo `json:"session"`
}