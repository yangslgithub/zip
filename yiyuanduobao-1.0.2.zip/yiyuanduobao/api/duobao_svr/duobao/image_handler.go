package duobao

/*
import (
	"image/gif"
	"crypto/md5"
	"encoding/json"
	"fmt"
	"database/sql"
	"../gosexy/redis"
	_ "github.com/go-sql-driver/mysql"
	//"github.com/coopernurse/gorp"
	"github.com/gographics/imagick/imagick"
	"github.com/alecthomas/log4go"
	"github.com/rwcarlsen/goexif/exif"
	"github.com/rwcarlsen/goexif/mknote"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"net/url"	
	"os"
	"path"
	"strings"
	//"sync"
	"strconv"
	"time"
	"bytes"
)


type SizeInfo struct {
	Width  uint
	Height uint
	Corp   uint
}

type UploadInfo struct {
	UserId 		int64
	Md5 			string
	SrcPath 		string
	NewPath 		string
	Filename 	string
	Width 		uint
	Height 		uint
	Corp        uint
	ContentType string
	FileSize    int64
	Type        string
	FileExt 	    string 
	IsOrg		int // 是否原图上传
	//UpToken 		string
}

var (
	normalSizeList []SizeInfo
	avatarSizeList []SizeInfo
)

const (
	AVATAR_ROOT = "/data/www/files/avatar/duobao/"
	AVATAR_IMG_URL_PREFIX = "http://t-avatar.52hangpai.cn/duboao/"
)


func FileExist(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}


func (o *APIHandler) UploadFile(r *http.Request, headers *CommonHeaders,  sequence uint64) string {
	//同步处理,等待处理完成
	o.Wg.Add(1)
	
	defer o.Wg.Done()

	var result ResponseInfo

	var upload UploadInfo
	result.Code = RET_OK
	
	//得到用户id
	userToken := headers.UserToken 
	user_id, err := o.queryUserIdByToken(userToken)
	if err != nil || user_id == -1 {
		log4go.Error("User token(%s) invalid: error=%s", userToken, err)
		result.Code = RET_TOKEN_EXPIRED 
		result.Msg = MSG_TOKEN_EXPIRED 
		return formatJson(result)
	}
	upload.UserId = user_id

	r.ParseMultipartForm(32 << 20)
	file, handler, err := r.FormFile("picture")
	if err != nil {
		log4go.Error("Can't find 'picture' field: %s", err)
		result.Code = RET_PARAM_MISSING 
		result.Msg = MSG_PARAM_MISSING
		return formatJson(result)
	}
	defer file.Close()

	imgType := r.FormValue("imgType")
	
	contentLen := r.Header.Get("Content-Length")
	fileSize, err := strconv.Atoi(contentLen)
	upload.FileSize = int64(fileSize)
	log4go.Debug("Request #%d imgType = [ %s ], Content-Length = %d", sequence, imgType, upload.FileSize)	

	upload.Md5 = calcFileMd5(file)
	upload.FileExt = path.Ext(handler.Filename)

	filePath := fmt.Sprintf("%s/%s/%s-org%s", AVATAR_ROOT, makeMidLayeredPath(upload.Md5), upload.Md5, upload.FileExt)
	if imgType == "avatar" {	
		filePath = fmt.Sprintf("%s/%s/%s-org%s", h.Config.AvatarRoot, makeMidLayeredPath(upload.Md5), upload.Md5, upload.FileExt)		
	}
	os.MkdirAll(path.Dir(filePath), os.ModePerm)

	f, err := os.OpenFile(filePath, os.O_WRONLY|os.O_CREATE, 0666)
	if err != nil {
		log4go.Info("open file err is %s", err)
		result.Code =  RET_INTERNAL_ERROR 
		result.Msg = MSG_INTERNAL_ERROR
		return h.formatJson(result)
	}
	log4go.Info("Try to copy file '%s' to '%s' ...", handler.Filename, filePath)
	io.Copy(f, file)
	f.Close()	
	
	upload.Type = imgType 
	isOrgStr := SafeParams(r, "isOrg")
	if isOrgStr != "" {
		isOrg, err := strconv.Atoi(isOrgStr)
		if err == nil {
			upload.IsOrg = isOrg
		}
	}

	upload.SrcPath = filePath

	contentType := handler.Header.Get("Content-Type")

	if !strings.Contains(contentType, "image/") {
		//非图片类型的直接返回
		result.Code =  RET_PARAM_INVALID 
		result.Msg =  "Content-Type not starts with image/***" 
		log4go.Error("path=%s, Content-Type=%s", upload.SrcPath, contentType)
	} else if !FileExist(upload.SrcPath) {
		result.Code = RET_INTERNAL_ERROR 
		result.Msg = MSG_INTERNAL_ERROR
	} else {
		upload.ContentType = contentType
		//一期先同步处理
		//go h.handUpload(upload)
		fileh, err := os.Open(filePath)
		if err != nil {
			log4go.Error("handUpload open file [%s] failed, [err=%s]", filePath, err.Error())
		}
		save_path, cid, extra_id, err := o.handUpload(&upload, fileh)
		if fileh != nil {
			fileh.Close()
		}
		log4go.Info("save_Path=%s", save_path)
		if err != nil {
			result.Code = RET_INTERNAL_ERROR 
			result.Msg = MSG_INTERNAL_ERROR
		} else {
			var imgRet ImgResult
			imgRet.OrgUrl = save_path
			imgRet.ImgId = cid
			imgRet.ExtraId = extra_id

			result.Code = RET_OK
			result.Msg = MSG_OK
			result.Data = imgRet 
		}

		//删除nginx的目录的文件
		os.Remove(handler.Filename) 
	}

	log4go.Debug("Successfully finished image-upload request #%d ", sequence)	
	return h.formatJson(result)
}

func (o *APIHandler) handUpload(upload *UploadInfo, f *os.File) (string, int64, int64, error) {
	mw := imagick.NewMagickWand()
	defer mw.Destroy()

	start := time.Now().UnixNano()
	err := mw.ReadImage(upload.SrcPath)
	if err != nil {
		log4go.Error("MagickWand ReadImage() error: %s", err)
		return "", -1, -1, err
	}

	imgWidth := mw.GetImageWidth()
	imgHeight := mw.GetImageHeight()
	imgOrientation := int(mw.GetImageOrientation())
	log4go.Debug("Image [%s] size: %d x %d, orientation=%d,imgOrientation=%d", upload.SrcPath, imgWidth, imgHeight,
		int(mw.GetOrientation()), mw.GetImageOrientation())
	if imgOrientation >= 5 && imgOrientation <= 8 {
		imgWidth, imgHeight = imgHeight, imgWidth
		log4go.Debug("After transform, image [%s] size: %d x %d", upload.SrcPath, imgWidth, imgHeight)
	}

	now := time.Now()
	//保存原图时用
	upload.NewPath = h.makeCopyPath(now, upload.UserId, upload.SrcPath,  upload.Filename)
	start = time.Now().UnixNano()
	sizeList := normalSizeList
	if upload.Type == "avatar" {
		sizeList = avatarSizeList
	}

	// gif图
	bIsGif := false
	fileExt := upload.FileExt
	fileExt = strings.ToLower(fileExt)
	if strings.Contains(fileExt, ".gif") {	
		gifInfo, err := gif.DecodeAll(f)
		if err == nil {
			log4go.Info("gifInfo.LoopCount:%d, len(gifInfo.Delay):%d, len(gifInfo.Image):%d", gifInfo.LoopCount, len(gifInfo.Delay), len(gifInfo.Image))
			if len(gifInfo.Image) > 1 {
				bIsGif = true
			}			
		} else {
			log4go.Info("gif.DecodeAll err:%s", err)
		}
	}	
	
	var resultList []compressResult
	if bIsGif == false { // gif 不压缩
		resultList, err = h.compress(upload, sizeList, mw, now)
	
		if err != nil || len(resultList) == 0 {
			return "", -1, -1, err		
		}
	} else {
		size := compressResult{Width: int64(imgWidth), Height: int64(imgHeight),}
		resultList = append(resultList, size)
	}

	end := time.Now().UnixNano()
	log4go.Info("handUpload.compress [time: %d us][filesize: %d]", (end-start)/1000, upload.FileSize)

	img2Path := h.calcImagePathMap(upload, resultList, bIsGif) 

	if upload.Type == "avatar" {
		cid, extraId,  err := h.SaveUserAvatar2Db(upload.UserId, upload.FileSize, int(imgWidth), int(imgHeight),  img2Path)		
		return img2Path["AvatarPath"], cid, extraId, err
	} else{
		log4go.Warn("handUpload(): unexpected imageType: %s", upload.Type)
		return "", -1, -1, nil
	}
}



func makeMidLayeredPath(md5Str string) string {
	return fmt.Sprintf("%s/%s", md5Str[0:2], md5Str[30:32])
}

func (o *APIHandler) makePath(now time.Time, userid int64, srcPath, filename string, width, height uint) string {
	name := fmt.Sprintf("%s.%dx%d.%s", userid, width, height, filename)
	p := fmt.Sprintf("%s%d/%d/%d/%d/%s", AVATAR_ROOT, now.Year(), now.Month(), now.Day(), now.Hour(), name)
	return p
}

func (o *APIHandler) makeCopyPath(now time.Time, userid int64, srcPath, filename string) string {
	name := fmt.Sprintf("%s.%s", userid, filename)
	p := fmt.Sprintf("%s%d/%d/%d/%d/%s", AVATAR_ROOT, now.Year(), now.Month(), now.Day(), now.Hour(), name)
	return p
}


func (o *APIHandler)calcImagePathMap(upload *UploadInfo, resultList []compressResult, isGif bool) map[string]string {
	img2Path := map[string]string{ }	
	
	if isGif {
		urlPrefix := h.Config.NormalImgUrlPrefix
		img2Path["OrgPath"] = fmt.Sprintf("%s/%s/%s-org%s", urlPrefix, makeMidLayeredPath(upload.Md5), upload.Md5, upload.FileExt)
		img2Path["T1Path"] = img2Path["OrgPath"]	
		img2Path["T2Path"] = img2Path["OrgPath"]
		img2Path["T3Path"] = img2Path["OrgPath"]
		log4go.Debug("gif OrgPath=%s", img2Path["OrgPath"])
		return img2Path
	}

	if upload.Type != "avatar" {
		urlPrefix := h.Config.NormalImgUrlPrefix
		img2Path["OrgPath"] = fmt.Sprintf("%s/%s/%s-org%s", urlPrefix, makeMidLayeredPath(upload.Md5), upload.Md5, upload.FileExt)
		if len(resultList) > 0 {
			img2Path["T1Path"] = fmt.Sprintf("%s/%s/%s-%d%s", urlPrefix, makeMidLayeredPath(upload.Md5), upload.Md5,
				resultList[0].Width, upload.FileExt)
			log4go.Debug("T1Path='%s'...", img2Path["T1Path"])
		}
		if len(resultList) > 1 {
			img2Path["T2Path"] = fmt.Sprintf("%s/%s/%s-%d%s", urlPrefix, makeMidLayeredPath(upload.Md5), upload.Md5,
				resultList[1].Width, upload.FileExt)
			log4go.Debug("T2Path='%s'...", img2Path["T2Path"])
		}
		if len(resultList) > 2 {
			img2Path["T3Path"] = fmt.Sprintf("%s/%s/%s-%d%s", urlPrefix, makeMidLayeredPath(upload.Md5), upload.Md5,
				resultList[2].Width, upload.FileExt)
			log4go.Debug("T3Path='%s'...", img2Path["T3Path"])			
		}
	}else{
		urlPrefix := AVATAR_IMG_URL_PREFIX
		if len(resultList) > 0 {
			//img2Path["AvatarPath"] = resultList[0].Filename
			img2Path["AvatarPath"] = fmt.Sprintf("%s/%s/%s-%d%s", urlPrefix, makeMidLayeredPath(upload.Md5), upload.Md5,
				resultList[0].Width, upload.FileExt)
		}else{
			img2Path["AvatarPath"] = fmt.Sprintf("%s/%s/%s-%d%s", urlPrefix, makeMidLayeredPath(upload.Md5), upload.Md5,
				h.Config.AvatarThumbnail_1.Width, upload.FileExt)
		}
	}

	return img2Path
}

func (o *APIHandler) SaveCompressedImg(upload *UploadInfo, size string, data []byte) (string, error) {
	var dest_path string
	rootDir := AVATAR_ROOT
	if upload.Type == "avatar" {
		rootDir = h.Config.AvatarRoot
	}

	if len(size) > 0 {
		dest_path = fmt.Sprintf("%s/%s/%s-%s%s", rootDir, makeMidLayeredPath(upload.Md5), upload.Md5, size, upload.FileExt)
	} else {
		dest_path = fmt.Sprintf("%s/%s/%s%s", rootDir, makeMidLayeredPath(upload.Md5), upload.Md5, upload.FileExt)
	}
	os.MkdirAll(path.Dir(dest_path), os.ModePerm)

	err := ioutil.WriteFile(dest_path, data, 0666)

	if err != nil {
		log4go.Error("save to local storage failed, [userid=%d][path:%s]", upload.UserId,  dest_path)
	} else {
		log4go.Info("save to local storage success,[userid=%d][path:%s]", upload.UserId, dest_path)
	}

	return dest_path, err
}

func calcFileMd5(file multipart.File) (string) {
	file.Seek(0, 0)

	buf := make([]byte, 256)

	hash := md5.New()
	for {
		n, err := file.Read(buf)
		if err != nil {
			log4go.Error("Read file error: %s", err)
			break
		}
		if n > 0 {
			if n < 256 {
				io.WriteString(hash, string(buf[0:n]))
				break
			}else{
				io.WriteString(hash, string(buf))
			}
		}
	}
	file.Seek(0, 0)

	md5Hex := fmt.Sprintf("%x", hash.Sum(nil))
	log4go.Info("File md5 is: %s", md5Hex)
	return md5Hex
}

func calcDescMd5(descText string) string {
	return fmt.Sprintf("%x", md5.Sum([]byte(descText)))
}

*/
