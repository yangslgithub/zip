package duobao

import (
	"encoding/json"
	"io/ioutil"
	"net/url"
	"errors"
	"bytes"
	"github.com/garyburd/redigo/redis"
	//"bytes"
	"database/sql"
	//"encoding/json"
	//"io/ioutil"
	//"errors"
	"fmt"
	"github.com/alecthomas/log4go"
	"github.com/coopernurse/gorp"
	_ "github.com/go-sql-driver/mysql"
	"crypto/md5"
	"log"
	"net/http"
	//"net/url"
	"math/rand"
	"strconv"
	"strings"
	"sync"
	"time"
)


//
type APIHandler struct {
	sc           *ServerConfig
	duobaoDB     *sql.DB
	AccountDBMap *gorp.DbMap
	RedisPool    *redis.Pool
	//report       *itil.RequestCounter
	WaringMap    map[string]int
	lock         sync.Mutex
	Wg           sync.WaitGroup
	countDownCh  chan int64 // 支付成功，夺宝分配完号码即添加到倒计时通道
	locationChannel  chan LocationQuryEntity
}

type SmsInfo struct {
	TextTmpl string
	ParamNum int
}

var (
	Err_Mobile_Invalid  = errors.New("Mobile number invalid")
	Err_SmsCode_Not_Expire = errors.New("Verify code not expired")
	g_smsNo2Info map[string]SmsInfo
	//g_notify_sms_channel chan smsNotifyInfo
)

var g_wxApiToken string
var g_wxApiTicket string
var g_rsa_private_key string

//创建一个新的Handler
func NewApiHandler(sc *ServerConfig) (*APIHandler, error) {
	duobaoDB, err := sql.Open("mysql", sc.DBServer)
	if err != nil {
		log4go.Error("open db %s failed, err=%s", sc.DBServer, err.Error())
		log.Fatalf("open db %s failed, err=%s", sc.DBServer, err.Error())
	}

	//设置最大连接数
	duobaoDB.SetMaxIdleConns(sc.MySqlPoolCnt)

	h := new(APIHandler)
	if len(sc.Redis) > 0 {
		//只使用第一个redis
 		h.RedisPool = redis.NewPool(func() (redis.Conn, error) {
			c, err := redis.Dial("tcp", fmt.Sprintf("%s:%d", sc.Redis[0].Ip, sc.Redis[0].Port))
			if err != nil {
				errMsg := fmt.Sprintf("connect redis server [%s:%d] failed, errMsg: %s\n", sc.Redis[0].Ip, sc.Redis[0].Port, err)
				log4go.Error(errMsg)
				return nil, err
			}

			return c, err
		}, sc.RedisPoolcnt)

		log4go.Info("Connect redis-server [%s:%d] success.\n", sc.Redis[0].Ip, sc.Redis[0].Port)
	}

	h.sc = sc
	h.duobaoDB = duobaoDB
	h.WaringMap = make(map[string]int, 10)

	h.InitTable()

	rand.Seed(time.Now().UnixNano())
	
	privateKeyFilePath := "./rsa_private_key.pem"
	rsaPrivateKey, err := ioutil.ReadFile(privateKeyFilePath)	
	if err != nil {
		log4go.Error("rsaPrivateKey open error:%s", err)
	} else {
		g_rsa_private_key = string(rsaPrivateKey)
	}	

	go h.ResetWaringMap()
	
	h.countDownCh = make(chan int64, 32)
	
	// 倒计时
	//go h.CountdownDuobao()
	
	// 揭晓中奖
	go h.PublishDuobaoRoutine()
	
	// 获取时时彩中奖号码
	go h.GetSscOpenCodeRoutine()
	
	// 用于用户位置信息补齐
	h.locationChannel = make(chan LocationQuryEntity, 32)
	go h.FillLocationMaybe()	
	
	// wx api token
	h.GetWxPubApiCfgInfoFun()
	go h.GetWxPubApiCfgInfoRoutine()

	return h, nil
}

//关闭连接
func (o *APIHandler) Close() {
	if o.duobaoDB != nil {
		o.duobaoDB.Close()
	}
}

//初始化数据库表
func (o *APIHandler) InitTable() {
	//o.GetUserProductDBMap().CreateTablesIfNotExists()
}

//用于避免发送告警邮件,周期内同样的错误只发送一次
func (o *APIHandler) ResetWaringMap() {
	for {
		select {
		case <-time.After(time.Minute * o.sc.SendEmailInterval):
			o.lock.Lock()
			o.WaringMap = map[string]int{}
			o.lock.Unlock()
		}
	}
}

//兼容API的路由
func (o *APIHandler) Handle(w http.ResponseWriter, r *http.Request, sequence uint64) string {
	//TODO: 同一用户,同一IP的频率请求限制
	log4go.Info("Api_handler handle request [route:%s][remoteip:%s]", r.URL.Path, GetClientIpAddr(r))

	w.Header().Set("Content-Type", "application/json")

	w.Header().Set("Access-Control-Allow-Headers", "User-Token,Os,App-Ver,Device-Id,Os-Ver,Screen,Content-Type,Network")
	w.Header().Set("Access-Control-Allow-Origin", o.sc.WebPubUrl)
	w.Header().Set("Access-Control-Allow-Credentials", "true")

	header := new(ReqHeader)
	respStr := parseCommonHeaders(header, r)
	if respStr != "" {
		return respStr
	}

	var result string
	st := time.Now()
	switch r.URL.Path {

	case "/api/accounts/get_sms_code": 	// 获取验证码
		result, _ = o.SendSMSCode(r, &header.Header, sequence)
	case "/api/accounts/send_sms_text":  // 获取验证码
		//result, _ = o.SendSMSText(r, &header.Header, sequence)
	case "/api/accounts/check_sms_code": // 检查验证码	
		//result, _ = o.CheckSmsCode(r, &header.Header, sequence)	
	case "/api/accounts/register": 	    // 注册
		result, _ = o.RegisterUser(r, &header.Header, sequence)
	case "/api/accounts/login":  			// 登录
		result, _ = o.Login(w, r, &header.Header, sequence)
	case "/api/accounts/reset_passwd":	// 重置密码
		result, _ = o.ResetPasswdByCode(r, &header.Header, sequence)
	case "/api/accounts/login_3rd_party": // 第三方登录
		result, _ = o.LoginFrom3rdParty(w, r, &header.Header, sequence)
	case "/api/accounts/set_user_location":
		result, _ = o.setUserLocation(r, &header.Header, sequence)
	case "/api/accounts/bind_mobile":     // 绑定手机号
		result, _ = o.bindMobile(r, &header.Header, sequence)
	case "/api/accounts/get_wx_appid":    // 微信appid
		result, _ = o.GetWxAppId(r, &header.Header, sequence)
	case "/api/accounts/get_access_token": // 微信token （登录）
		result, _ = o.GetAccessTokenByCode(r, &header.Header, sequence)
	case "/api/accounts/get_wx_api_config": // 微信公众api配置
		result = o.GetWxPubApiCfgInfo(r, &header.Header, sequence)		
				
		
		
	case "/api/img_upload":
		//result = o.UploadFile(r, &header.Header, sequence)			
		
	case "/api/get_user_by_id":
		result, _ = o.GetUsrInfo(r, &header.Header, sequence)
	case "/api/index": 				// 首页
		result, _ = o.GetIndexInfo(r, &header.Header, sequence)	
	case "/api/activity_detail":   	// 活动详情
		result = o.GetActivityDetail(r, &header.Header, sequence)
	case "/api/goods_detail":   		// 商品详情(商品图片列表)
		result = o.GetGoodsDetail(r, &header.Header, sequence)
	case "/api/prev_activity_results": // 往期揭晓
		result = o.GetPrevActivityResults(r, &header.Header, sequence)
	case "/api/get_latest_period": 	 // 获取该商品最新的夺宝期号
		result = o.GetLatestDuobaoPeriod(r, &header.Header, sequence)		
	case "/api/publish_duobao": 		 // 前台调用揭晓夺宝
		result = o.PublishDuobaoApi(r, &header.Header, sequence)		
	case "/api/calc_details": 		// 计算详情
		result = o.GetCalcResults(r, &header.Header, sequence)
	case "/api/next_joined_records": // 查询下一页夺宝参与记录	
		result = o.NextJoinedRecords(r, &header.Header, sequence)
	case "/api/newly_publish":  		// 最新揭晓
		result, _ = o.GetNewlyPublish(r, &header.Header, sequence)	
	case "/api/cart_list":  			// 查看清单
		result = o.GetCartList(r, &header.Header, sequence)
	case "/api/add_2_cart":  		// 添加到清单
		result = o.Add2Cart(r, &header.Header, sequence)
	case "/api/delete_from_cart":  	// 从清单中删除
		result = o.DelFromCart(r, &header.Header, sequence)	
	case "/api/query_joined": 		// 查询某期下单分到的所有号码
		result = o.GetAllBuyCodeFromPeroid(r, &header.Header, sequence)	
	case "/api/settlement": 			// 结算
		result = o.Settlement(r, &header.Header, sequence)		
	case "/api/order": 			   	// 下单，点支付
		result = o.Order(r, &header.Header, sequence)
	case "/api/notify_payment": 		// 支付通知
		result = o.NotifyPayment(r, &header.Header, sequence)
	case "/api/auto_order": 			// 自动下单
		result = o.AutoOrder(r, &header.Header, sequence)			
	
	case "/api/charge_test": 		// 支付（test）
		result = o.ChargesTest(r, &header.Header, sequence)					
	case "/api/charge_test_success_url": 			   // 支付（test）
		result = o.ChargesTestSuccessUrl(r, &header.Header, sequence)
	case "/api/charge_test_cancel_url": 			   // 支付（test）
		result = o.ChargesTestCancelUrl(r, &header.Header, sequence)											
		
	case "/api/charge_Webhooks": 	  // ping++支付结果回调
		result = o.ChargeWebhooks(w, r, &header.Header, sequence)	
		
					
	case "/api/create_duobao": 	  // 创建夺宝活动(私用)
		result = o.CreateDuobao(r, &header.Header, sequence)
	case "/api/lauch_duobao": 	  // 启动夺宝活动(私用)
		result = o.LauchDuobao(r, &header.Header, sequence)
	case "/api/init_code_pool": 	  // 初始化夺宝号码池(私用)
		result = o.TestInitDuobaoCodePool(r, &header.Header, sequence)	
		
	case "/api/develop_test": 	  // 自测
		result = o.DevelopTest(r, &header.Header, sequence)				
								
	
	case "/api/my_duobao_records": // 个人中心(全部参与 夺宝记录)
		result = o.GetMyDuobaoRecords(r, &header.Header, sequence)	
	case "/api/my_lucky_records":  // 个人中心(中奖记录)
		result = o.GetMyLuckyRecords(r, &header.Header, sequence)	
	case "/api/user_profile":  	  // 查看个人资料
		result = o.GetUserProfile(r, &header.Header, sequence)
	case "/api/other_user_profile": // 查看客态个人资料
		result = o.GetOtherUserProfile(r, &header.Header, sequence)			
	case "/api/modify_user_info":  // 修改个人资料
		result = o.ModifyUserProfile(r, &header.Header, sequence)			
	case "/api/address_list":      // 收货地址查看
		result = o.GetUserAddressList(r, &header.Header, sequence)			
	case "/api/add_address":       // 增加收货地址
		result = o.AddAddress(r, &header.Header, sequence)
	case "/api/del_address":       // 删除收货地址
		result = o.DelAddress(r, &header.Header, sequence)	
	case "/api/modify_address":    // 修改收货地址
		result = o.ModifyAddress(r, &header.Header, sequence)	
	case "/api/my_gold_detail":    // 我的金币
		result = o.MyGoldDetail(r, &header.Header, sequence)
	case "/api/get_next_gold_detail": // 金币获取明细，一页
		result = o.GetOnePageGetGoldDetail(r, &header.Header, sequence)	
	case "/api/used_gold_detail": 	// 金币使用明细，一页
		result = o.GetOnePageUsedGoldDetail(r, &header.Header, sequence)			
	case "/api/user_message_notify": 	// 用户消息通知
		result = o.UserMessageNotify(r, &header.Header, sequence)				
				
		
	case "/api/im/send_message":   // 联系客服
		result, _ = o.SendImMsg(r, &header.Header, sequence)
	case "/api/im/get_sessions":
		result, _ = o.GetImSessions(r, &header.Header, sequence)	
	case "/api/im/receive_message":
		result, _ = o.RecvImMsg(r, &header.Header, sequence)	
	case "/api/im/query_session_details":
		result, _ = o.QuerySessionDetails(r, &header.Header, sequence)								
														
		
	default:
		var notfound  ResponseInfo 
		notfound.Code =  RET_ROUTE_NOT_FOUND 
		notfound.Msg = MSG_ROUTE_NOT_FOUND 
		result = formatJson(notfound)
		log4go.Error("Request route '%s' not found!", r.URL.Path)
	}
	et := time.Now()
	consuming := (et.UnixNano() - st.UnixNano()) / (1000 * 1000)
	log4go.Trace("handle route [%s] request , timeConsumed= %d ms", r.URL.Path, consuming)

	//根据耗时阀值判断是否需要发送邮件进行告警
	if consuming >= (o.sc.WaringHighwater * 1000) {
		_, exist := o.WaringMap[r.URL.Path]
		if !exist {
			o.WaringMap[r.URL.Path] = HAVE_SEND_EMAIL
			log4go.Warn("DoSendWaringEmail %s consuming time %d ms", r.URL.Path, consuming)
			//go DoSendWaringEmail(r.URL.Path, o.sc.Env, consuming, o.sc.WaringEmailList)
		}
	}
	return result
}


func parseCommonHeaders(header *ReqHeader, r *http.Request) (string) {
	header.Header.UserToken = r.Header.Get("User-Token")
	header.Header.DeviceId = r.Header.Get("Device-Id")
	header.Header.AppVer = r.Header.Get("App-Ver")
	header.Header.Os = r.Header.Get("Os")
	header.Header.OsVersion = r.Header.Get("OsVersion")
	header.Header.Screen = r.Header.Get("Screen")
	header.Header.Network = r.Header.Get("Network")

	// 修正, 有的版本传入的是"1920*1080"这样的屏幕尺寸
	header.Header.Screen = strings.Replace(header.Header.Screen, "*", "x", 1)


	log4go.Info("Request [%s] header info: User-Token=%s, Device-Id=%s, App-Ver=%s, Os=%s, OsVersion=%s, Screen=%s, Network=%s", 
		r.URL.Path, header.Header.UserToken, header.Header.DeviceId, header.Header.AppVer, header.Header.Os, 
		header.Header.OsVersion, header.Header.Screen, header.Header.Network)	

	if header.Header.DeviceId == "" || header.Header.AppVer == "" {
		log4go.Warn("Device-Id or App-Ver not found in http headers!") 
		var resp ResponseInfo
		resp.Code = RET_PARAM_MISSING
		resp.Msg = MSG_PARAM_MISSING
		//return formatJson(resp)				
	}	
	if versionCompare(header.Header.AppVer, "1.4") >= 0 && header.Header.Network == "" {
		log4go.Warn("'Network' not found in http headers!") 		
	}

	return ""
} 

//进行请求次数上报
func (o *APIHandler) RequestReport(key string, state int) {
/*
	stamp := time.Now().Unix()
	info := o.report.AddCount(key, 1, stamp, (state == RET_OK))
	// 周期内错误数超过阀值,发送邮件告警
	if info.Failed >= o.sc.ErrorHighwater {
		_, exist := o.WaringMap[key]
		if !exist {
			o.WaringMap[key] = HAVE_SEND_EMAIL
			errmsg := fmt.Sprintf("function [%s] occur %d times error at %s. ",
				key, info.Failed, time.Now().Format(TIME_FORMAT))
			log4go.Error("DoSendErrorEmail %s", errmsg)
			go DoSendErrorEmail(key, o.sc.Env, errmsg, o.sc.WaringEmailList)
		}
	}
*/
}

func (o *APIHandler) SendSMSCode(r *http.Request, headers *CommonHeaders, sequence uint64) (string,error) {
	var result ResponseInfo

	verify_type := SafeParams(r, "verify_type")
	mobile := SafeParams(r, "mobile")
	log4go.Info("SendSMSCode(): verify_type:%s, mobile:%s", verify_type, mobile)
	if len(mobile) < 9 {
		log4go.Error("Mobile number invalid: %s", mobile)
		result.Code = RET_OK
		result.Msg = MSG_PARAM_INVALID 
		return formatJson(result), nil
	}
	
	var mobileKey string
	/*if verify_type != "" {
		mobileKey = fmt.Sprintf("smscode-%s-%s",verify_type,mobile)
	} else {
		mobileKey = fmt.Sprintf("smscode-%s",mobile)
	}*/
	mobileKey = fmt.Sprintf("smscode-%s",mobile)
	
	_, unxTime := o.readCachedVerifyCodeByMobile(mobileKey)
	if unxTime > 0 && time.Now().Unix() - int64(unxTime) < 60 {
		log4go.Warn("Prev SMS code for mobile '%s' still valid!", mobile)
		result.Code = RET_REQUEST_TOO_FREQUENT 
		result.Msg = MSG_REQ_TOO_FREQUENT
		return formatJson(result), nil
	}

	randCode := 1000 + rand.Int31n(8999)
	smsCode := strconv.Itoa(int(randCode))

	smsText := fmt.Sprintf("您的验证码是%s。如非本人操作，请忽略本短信【酷购吧】", smsCode)

	var err error
	if strings.ToLower(o.sc.SmsProvider) == "yunpian" {
		err = sendSmsByYunpian(mobile, smsText) // 云片网
	}else{
		err = sendSmsByXiehe( mobile, smsText)  // 广州谐和
	}
	if err != nil {
		result.Code = RET_INTERNAL_ERROR
		result.Msg = MSG_INTERNAL_ERROR
		return formatJson(result), err		
	}

	codeAndTime := fmt.Sprintf("%s-%d", smsCode, time.Now().Unix())
	redisConn := o.RedisPool.Get()
	defer redisConn.Close()
	_, err = redisConn.Do("SETEX", mobileKey, SMS_CODE_EXPIRE_IN_SECONDS, []byte(codeAndTime))
	//_, err = o.RedisClient.SetEx(mobileKey, int64(SMS_CODE_EXPIRE_IN_SECONDS), []byte(codeAndTime))
	if err != nil {
		log4go.Warn("Set redis cache item '%s' failed: %s", mobileKey, err)
	}

	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result), nil
}

func (o *APIHandler) SendSMSText(r *http.Request, headers *CommonHeaders, sequence uint64) (string,error) {
	var result ResponseInfo

	mobile := SafeParams(r, "mobile")
	if len(mobile) < 9 {
		log4go.Error("Mobile number invalid: %s", mobile)
		result.Code = RET_PARAM_INVALID
		result.Msg = MSG_PARAM_INVALID 
		return formatJson(result), nil
	}

	template_no := SafeParams(r, "tmpl_no")
	smsInfo, ok := g_smsNo2Info[template_no]
	if !ok {
		log4go.Error("SendSMSText(): invalid 'tmpl_no' [ %s ]", template_no)
		result.Code = RET_PARAM_INVALID
		result.Msg = MSG_PARAM_INVALID 
		return formatJson(result), nil		
	}
	params_num_str := SafeParams(r, "params_num")
	params_num, err := strconv.Atoi(params_num_str)
	if err != nil || params_num > 4 {
		log4go.Error("SendSMSText(): invalid 'params_num' [ %s ]", params_num_str)
		result.Code = RET_PARAM_INVALID
		result.Msg = MSG_PARAM_INVALID 
		return formatJson(result), nil				
	}
	finalText := smsInfo.TextTmpl
	if params_num == 1 {
		finalText = fmt.Sprintf(finalText, SafeParams(r, "params_1"))
	}else if params_num == 2 {
		finalText = fmt.Sprintf(finalText, SafeParams(r, "params_1"), SafeParams(r, "params_2"))		
	}else if params_num == 3 {
		finalText = fmt.Sprintf(finalText, SafeParams(r, "params_1"), SafeParams(r, "params_2"), SafeParams(r, "params_3"))				
	}else if params_num == 4 {
		finalText = fmt.Sprintf(finalText, SafeParams(r, "params_1"), SafeParams(r, "params_2"), SafeParams(r, "params_3"), SafeParams(r, "params_4"))						
	}

	mobileKey := fmt.Sprintf("smstxt-%s", mobile)
	_, unxTime := o.readCachedVerifyCodeByMobile(mobileKey)
	if unxTime > 0 && time.Now().Unix() - int64(unxTime) < 10 {
		log4go.Warn("Prev SMS text for mobile '%s' still valid!", mobile)
		result.Code = RET_REQUEST_TOO_FREQUENT 
		result.Msg = MSG_REQ_TOO_FREQUENT
		return formatJson(result), nil
	}

	randCode := 1000 + rand.Int31n(8999)
	smsCode := strconv.Itoa(int(randCode))

	//var err error
	if strings.ToLower(o.sc.SmsProvider) == "yunpian" {
		err = sendSmsByYunpian(mobile, finalText) // 云片网
	}else{
		err = sendSmsByXiehe(mobile, finalText)  // 广州谐和
	}
	if err != nil {
		result.Code = RET_INTERNAL_ERROR
		result.Msg = MSG_INTERNAL_ERROR
		return formatJson(result), err		
	}

	redisConn := o.RedisPool.Get()
	defer redisConn.Close()

	codeAndTime := fmt.Sprintf("%s-%d", smsCode, time.Now().Unix())
	redisConn.Do("SETEX", mobileKey, SMS_CODE_EXPIRE_IN_SECONDS, []byte(codeAndTime))
	//o.RedisClient.SetEx(mobileKey, int64(SMS_CODE_EXPIRE_IN_SECONDS), []byte(codeAndTime))

	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result), nil
}

func  sendSmsByXiehe(mobile string, smsText string) error {
	if len(mobile) == 0 || len(smsText) == 0 {
		log4go.Warn("sendSmsByXiehe(): mobile or smsText is empty!!")
		return nil
	}

	log4go.Info("Try to send SMS text '%s' to mobile '%s' using Xiehe ...", smsText, mobile)

    smsHost := "http://124.172.243.56:8080"
    svrRes := "/sms/sendsms.jsp"
    params := url.Values{}
    params.Set("account", "kupai")
    params.Add("passwd", "3O1yzRUv")
    params.Add("mobiles", mobile)
	sendText := smsText //fmt.Sprintf("亲,您的验证码是%s。如非本人操作，请忽略这条短信。", smsCode)	
    params.Add("content", sendText)
    params.Add("digest", "e1922eb464437df7e765dcde2678e06d")

    u, _ := url.ParseRequestURI(smsHost)
    u.Path = svrRes
    urlStr := fmt.Sprintf("%v", u) // "http://124.172.243.56:8080/sms/sendsms.jsp"
	req, err := http.NewRequest("POST", urlStr, bytes.NewBufferString(params.Encode()))
	if err != nil {
		log4go.Error("Create http request error: %s", err)
		return  err
	}
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")
    req.Header.Add("Content-Length", strconv.Itoa(len(params.Encode())))

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log4go.Error("Post to XieHe server error: %s", err)
		return  err
	}	
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	xhResp := new(XieheResp)   // /*  {"code":0, "batchno": "10001"}  */
	err = json.Unmarshal(body, &xhResp)
	if err != nil {
		log4go.Error("Failed to parse resp from XieHe server : [ %s ]", string(body))
		return err
	}	
	if xhResp.Code != 200 {
		log4go.Error("Resp code from XieHe server is [ %d ] !", xhResp.Code)
		return errors.New(fmt.Sprintf("Resp code from XieHe is '%d'", xhResp.Code))		
	}	

	return nil
}

func sendSmsByYunpian(mobile string, smsText string) error {
	log4go.Info("Try to send SMS text '%s' to mobile '%s' using Yunpian ...", smsText, mobile)

	postString := fmt.Sprintf("apikey=ffc726c3603c17edc40677a71623134a&mobile=%s&text=%s",
		mobile, smsText)
	SMS_URL := "http://yunpian.com/v1/sms/send.json"
	req, err := http.NewRequest("POST", SMS_URL, bytes.NewBufferString(postString))
	if err != nil {
		log4go.Error("Create http request error: %s", err)
		return  err
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log4go.Error("Post to yunpian.com error: %s", err)
		return  err
	}	
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	/*  {"code":0,"msg":"OK","result":{"count":1,"fee":1,"sid":2369488203}}  */
	ypResp := new(YunpianResp)
	err = json.Unmarshal(body, &ypResp)
	if err != nil {
		log4go.Error("Failed to parse resp from yunpian.com : [ %s ]", string(body))
		return err
	}	
	if ypResp.Code != RET_OK {
		log4go.Error("Resp code from yunpian.com is [ %d ] !", ypResp.Code)
		return errors.New(fmt.Sprintf("Resp code from yunpian is '%d'", ypResp.Code))		
	}	

	return nil
}


func (o *APIHandler) readCachedVerifyCodeByMobile(mobile string) (string, int64) {
	redisConn := o.RedisPool.Get()
	defer redisConn.Close()
	codeAndGetTime, err := redis.String(redisConn.Do("GET", mobile))
	if err != nil {
		log4go.Error("readCachedVerifyCodeByMobile() read redis '%s' error [ %s ]", mobile, err)
		return "", 0
	}	
	//codeAndGetTime, _ := o.RedisClient.Get(mobile)
	if len(codeAndGetTime) == 0 {
		return "", 0
	}

	subFields := strings.Split(codeAndGetTime, "-")
	if len(subFields) < 2 {
		return "", 0
	}

	getTime := subFields[1]
	unxTime, err := strconv.Atoi(getTime)
	if err != nil {
		return "", 0
	}

	return subFields[0], int64(unxTime)
}

// 检查用户验证码是否正确
func (o *APIHandler) CheckSmsCode(r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {
	mobile := SafeParams(r, "mobile")
	verify_code := SafeParams(r, "verify_code")	
	log4go.Info("CheckSmsCode(): mobile=%s, verify_code=%s", mobile, verify_code)

	var result ResponseInfo
	if len(mobile) < 11 {
		result.Code = RET_PARAM_INVALID 
		result.Msg = MSG_PARAM_INVALID 
		log4go.Error("CheckSmsCode failed, invalid mobile number: %s", mobile)
		return formatJson(result), nil
	}

	// 检查验证码是否正确(从redis读取)
	mobileKey := fmt.Sprintf("smscode-%s",mobile)
	lastCode, _ := o.readCachedVerifyCodeByMobile(mobileKey)
	if 	lastCode != verify_code {
		result.Code = RET_SMSCODE_INCORRECT
		result.Msg = MSG_SMSCODE_INCORRECT
		log4go.Error("CheckSmsCode failed, request verify code is '%s', but cached sms code is '%s'", verify_code, lastCode) 
		return formatJson(result), nil
	}

	result.Code = RET_OK
	result.Msg = MSG_OK
	log4go.Info("CheckSmsCode() OK, mobile=%s", mobile)
	return formatJson(result),nil
}


// 用户注册

func genInitNickname(mobile string) string{
	nlen := len(mobile)

	return mobile[0:nlen-8] + "****" + mobile[nlen-4:]
}

type tokenPair struct {
	token string `db:"cur_token"`
	updatedAt time.Time `db:"token_updated_at"`
}


func setLoginCookie(w http.ResponseWriter, user_id int64) string {
	if user_id < 0 {
		log4go.Error("setLoginCookie failed.user_id err.")
		return ""
	}

	//存入保持登录的cookie
	expire := time.Now().Add(6 * time.Hour)
	time_unix := expire.Unix()
	secret_key := "ihangpai!@#"
	user_id_str := fmt.Sprintf("%d", user_id)
	time_unix_str := fmt.Sprintf("%d", time_unix)
	//加密
	salt := user_id_str + time_unix_str + secret_key
	salt = calcDescMd5(salt)
	user_verify := user_id_str + "-" + time_unix_str + "-" + salt;
	//user_verify_cookie := http.Cookie{Name: "user_verify", Value: user_verify, Domain: ".52hangpai.cn", Path: "/", Expires: expire, MaxAge: 86400}
	user_verify_cookie := http.Cookie{Name: "user_verify", Value: user_verify, Domain: ".52hangpai.cn", Path: "/"}
	http.SetCookie(w, &user_verify_cookie)
	
	return user_verify
}

func genUserToken(user_id int64) string {
	srcStr := fmt.Sprintf("[%d-%d][ihp-token]", user_id, time.Now().UnixNano())
	return fmt.Sprintf("%x", md5.Sum([]byte(srcStr)))
}

func calcDescMd5(descText string) string {
	return fmt.Sprintf("%x", md5.Sum([]byte(descText)))
}


func (o *APIHandler) CountdownDuobao() error {
	for period := range o.countDownCh {
		o.SetOneDuobaoCountdown(period)
	}
	return nil
}


func SetWxApiToken(token string) {
	if len(token) <= 0 {
		log4go.Error("SetWxApiToken token invalid")
		return 
	} 
	g_wxApiToken = token
}

func GetWxApiToken() string {
	return g_wxApiToken
}

func SetWxApiTicket(ticket string) {
	if len(ticket) <= 0 {
		log4go.Error("SetWxApiTicket ticket invalid")
		return 
	} 
	g_wxApiTicket = ticket
}

func GetWxApiTicket() string {
	return g_wxApiTicket
}
