package duobao

import (
	"github.com/coopernurse/gorp"		
	//"github.com/alecthomas/log4go"
)

/*
 * 获取user表的db操作对象
 */
func (o *APIHandler) GetUserDBMap() (*gorp.DbMap, string) {
	tableName := "idb_users" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(UserInfoDb{}, tableName).SetKeys(true, "user_id")
	return dbmap, tableName
}

/**
* 获取 idb_user_token 操作对象
*/
func (o *APIHandler) GetUserTokenDBMap(mobile string) (*gorp.DbMap, string) {
	tableName := "idb_user_token" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(UserTokenInfo{}, tableName).SetKeys(true, "user_id")
	return dbmap, tableName
}

/*
 * 获取商品表的db操作对象
 */
func (o *APIHandler) GetGoodsDBMap() (*gorp.DbMap, string) {
	tableName := "idb_goods" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(GoodsInfoDb{}, tableName).SetKeys(true, "goods_id")
	return dbmap, tableName
}

/*
 * 获取商品数据表操作对象
 */
func (o *APIHandler) GetGoodsDataDBMap() (*gorp.DbMap, string) {
	tableName := "idb_goods_data" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(GoodsMediaDb{}, tableName).SetKeys(true, "content_id")
	return dbmap, tableName
}

/*
 * 获取一期夺宝活动表的db操作对象
 */
func (o *APIHandler) GetDuobaoDBMap() (*gorp.DbMap, string) {
	tableName := "idb_duobao" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(DuobaoInfoDb{}, tableName).SetKeys(true, "period")
	return dbmap, tableName
}

/*
 * 获取idb_duobao_lauch操作对象
 */
func (o *APIHandler) GetDuobaoLauchDBMap() (*gorp.DbMap, string) {
	tableName := "idb_duobao_lauch" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(LauchRecordDb{}, tableName)
	return dbmap, tableName
}

/*
 * 获取banner db操作对象
 */
func (o *APIHandler) GetBannerDBMap() (*gorp.DbMap, string) {
	tableName := "idb_banner_config" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(BannerConfDb{}, tableName).SetKeys(true, "id")
	return dbmap, tableName
}

/*
 * 获取idb_sub_orders操作对象
 */
func (o *APIHandler) GetOrdersDBMap() (*gorp.DbMap, string) {
	tableName := "idb_orders" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(SumOrderDb{}, tableName).SetKeys(true, "OrderNo")
	return dbmap, tableName
}

/*
 * 获取idb_sub_orders操作对象
 */
func (o *APIHandler) GetSubOrderDBMap() (*gorp.DbMap, string) {
	tableName := "idb_sub_orders" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(SubOrderDb{}, tableName).SetKeys(true, "OrderNo")
	return dbmap, tableName
}

/*
 * 获取idb_order_detail操作对象
 */
func (o *APIHandler) GetOrderDetailDBMap() (*gorp.DbMap, string) {
	tableName := "idb_order_detail" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(OrderDetailDb{}, tableName).SetKeys(true, "OrderNo")
	return dbmap, tableName
}

/*
 * 获取idb_cart操作对象
 */
func (o *APIHandler) GetCartDBMap() (*gorp.DbMap, string) {
	tableName := "idb_cart" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(CartDb{}, tableName)
	return dbmap, tableName
}

/*
 * 获取idb_user_addr_list操作对象
 */
func (o *APIHandler) GetAddrListDBMap() (*gorp.DbMap, string) {
	tableName := "idb_user_addr_list" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(AddrListDb{}, tableName)
	return dbmap, tableName
}

/*
 * 获取idb_cqssc操作对象
 */
func (o *APIHandler) GetCqsscDBMap() (*gorp.DbMap, string) {
	tableName := "idb_cqssc" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(CqsscDb{}, tableName)
	return dbmap, tableName
}

/*
 * 获取idb_assign_code_pool操作对象
 */
func (o *APIHandler) GetCodePoolDBMap() (*gorp.DbMap, string) {
	tableName := "idb_assign_code_pool" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(CodePoolDb{}, tableName)
	return dbmap, tableName
}

/*
 * 获取idb_user_location_maybe操作对象
 */
func (o *APIHandler) GetUserLocationMaybeDbMap() (*gorp.DbMap, string) {
	tableName := "idb_user_location_maybe"
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(LocatInfoDb{}, tableName)
	return dbmap, tableName
}

/*
 * 获取idb_pub_latest_orders操作对象
 */
func (o *APIHandler) GetPubLastestDBMap() (*gorp.DbMap, string) {
	tableName := "idb_pub_latest_orders" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(JoinedRecord{}, tableName)
	return dbmap, tableName
}

/*
 * 获取idb_refund_order操作对象
 */
func (o *APIHandler) GetRefundDBMap() (*gorp.DbMap, string) {
	tableName := "idb_refund_order" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(RefundDb{}, tableName)
	return dbmap, tableName
}


/*
 * 获取idb_user_get_gold_record操作对象
 */
func (o *APIHandler) GetGoldRecordDBMap() (*gorp.DbMap, string) {
	tableName := "idb_user_get_gold_record" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(GoldRecordDb{}, tableName)
	return dbmap, tableName
}

/*
 * 获取idb_period_of_day操作对象
 */
func (o *APIHandler) GetPeriodOfDayDBMap() (*gorp.DbMap, string) {
	tableName := "idb_period_of_day" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(PeriodOfDayDb{}, tableName)
	return dbmap, tableName
}

/*
 * 获取idb_message操作对象
 */
func (o *APIHandler) GetMessageDBMap() (*gorp.DbMap, string) {
	tableName := "idb_message" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(NotifyMsgDb{}, tableName).SetKeys(true, "id")
	return dbmap, tableName
}

/*
 * 获取idb_partner_commission操作对象
 */
func (o *APIHandler) GetCommissionDBMap() (*gorp.DbMap, string) {
	tableName := "idb_partner_commission" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(CommissionDb{}, tableName)
	return dbmap, tableName
}

/*
 * 获取idb_partners操作对象
 */
func (o *APIHandler) GetPartnerDBMap() (*gorp.DbMap, string) {
	tableName := "idb_partners" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(PartnerDb{}, tableName)
	return dbmap, tableName
}