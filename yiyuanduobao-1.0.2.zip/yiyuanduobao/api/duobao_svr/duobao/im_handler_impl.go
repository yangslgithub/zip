package duobao

import (
	//"encoding/json"
	"errors"
	"fmt"
	//"github.com/garyburd/redigo/redis"	
	"github.com/alecthomas/log4go"
	"net/http"
	"strconv"
	"strings"
	//"time"
)

const (
	HTTP_PROTOCOL_PREFIX = "http://"
	HTTPS_PROTOCOL_PREFIX = "https://"
)

type sendMsgClientReq struct {
	ToUid int64
	SessionId string 
	MsgType string 
	MsgContent string 
}

type recvMsgClientReq struct {
	SessionId string 
	LastId int64 
	Direction string 
	PageSize int
}

type querySessionReq struct {
	SessionId string
	ToUid int64 
}


type PushImMessageSub struct {
	Session ImSessionBasicInfo `json:"session"`
	FromUser *UserRespLite `json:"from_user"`
	MsgId int64 `json:"msg_id"`
	MsgType string `json:"msg_type"`
	MsgTs int64 `json:"msg_ts"`
	MsgContent string `json:"msg_content"`
}

type PushWebUrlMessageSub struct {
	Params string `json:"params"`
	PageTitle string `json:"page_title"`
}


func handleSendMsgParams(r *http.Request,headers *CommonHeaders) (*sendMsgClientReq, int, string) {
	toUidStr := r.PostFormValue("to_uid")
	sidStr := r.PostFormValue("session_id")
	if len(toUidStr) == 0 && len(sidStr) == 0 {
		log4go.Warn("send_message(): both 'to_uid' and 'session_id' are empty!")
		return nil, RET_PARAM_MISSING, MSG_PARAM_MISSING
	}
	toUid := int64(-1)
	if len(sidStr) == 0 {
		// session_id没提供，需要得到to_uid
		intVal, _ := strconv.Atoi(toUidStr)
		toUid = int64(intVal)
		if toUid <= 0 {
			log4go.Warn("send_message(): 'to_uid' invalid [ %s ]", toUidStr)
			return nil, RET_PARAM_INVALID, MSG_PARAM_INVALID
		}
	}

	msgType := r.PostFormValue("msg_type")
	if !(msgType == "text" || msgType == "image" || msgType == "audio" || msgType == "video"){
		log4go.Warn("send_message(): invalid 'msg_type' [ %s ]", msgType)
		return nil, RET_PARAM_INVALID, MSG_PARAM_INVALID		
	}

	msgContent := r.PostFormValue("msg_content")
	if len(msgContent) == 0 {
		log4go.Warn("send_message(): 'msg_content' is empty!")
		return nil, RET_PARAM_INVALID, MSG_PARAM_INVALID		
	}

	signature := r.PostFormValue("signature")	
	calcSig, matched := CheckSignature(msgContent, headers.UserToken, signature)
	if signature != "e06df229a6c9214e6739974737ab8cbf" && !matched {
		log4go.Error("send_message(): signature check failed, serverSig=[ %s ]， clientSig=[ %s ]", calcSig, signature)
		//return nil, RET_SIG_CHECK_FAILED, MSG_SIG_CHECK_FAILED
	}

	if msgType == "text" {
		// 对认证过的url进行自定义超链标记
		msgContent = markCertifiedUrl(msgContent)
	}
	clientReq := sendMsgClientReq {
		ToUid: toUid-DUOBAO_USER_ID_BASE,
		SessionId: sidStr,
		MsgType: msgType,
		MsgContent: msgContent,
	}
	return &clientReq, RET_OK, MSG_OK
}

func markCertifiedUrl(msgContent string) string {
	pos := strings.Index(msgContent, HTTP_PROTOCOL_PREFIX)
	prefixLen := len(HTTP_PROTOCOL_PREFIX)
	if pos == -1 {
		// 没有http超链接，尝试https
		pos = strings.Index(msgContent, HTTPS_PROTOCOL_PREFIX)
		prefixLen = len(HTTPS_PROTOCOL_PREFIX)
		if pos == -1{
			return msgContent
		}
	}
	//log4go.Debug("markCertifiedUrl('%s'): pos=%d, prefixLen=%d", msgContent, pos, prefixLen)

	// 找到host
	nextPos := pos + prefixLen
	nextStr := msgContent[nextPos:]
	//log4go.Debug("markCertifiedUrl('%s'): nextPos=%d, nextStr='%s'", msgContent, nextPos, nextStr)

	pos2 := strings.Index(nextStr, "/")
	if pos2 == -1 {
		pos2 = strings.Index(nextStr, " ")
		if pos2 == -1 {
			return msgContent
		}
	}

	host := nextStr[:pos2]
	//log4go.Debug("markCertifiedUrl('%s'): pos2=%d, host='%s'", msgContent, pos2, host)
	if !(strings.HasSuffix(host, "52hangpai.com") ||
		strings.HasSuffix(host, "52hangpai.cn")) {
		// 来自可靠域名
		return msgContent	
	}

	pos2 = strings.Index(nextStr, " ")
	//log4go.Debug("markCertifiedUrl('%s'): nextStr('%s') pos2=%d", msgContent, nextStr, pos2)

	if pos2 == -1 {
		return msgContent
	}
	urlPart := msgContent[pos:nextPos+pos2]
	urlText := urlPart[prefixLen:]
	//log4go.Debug("markCertifiedUrl('%s'): urlPart='%s', pos=%d, pos2=%d", msgContent, urlPart, pos, pos2)

	newContent := msgContent[:pos] + fmt.Sprintf(`<ihplink url="%s">`, urlPart) + urlText + "</ihplink>" + msgContent[nextPos + pos2:]

	log4go.Debug("Msg content '%s' replaced as '%s'.", msgContent, newContent)

	return newContent
}

func (o *APIHandler)sendMsgImpl(clientReq *sendMsgClientReq, meUid int64, nowUnix int64, needPush bool) (string, int64, string, error) {
	toUid := int64(-1)
	curSessionId := ""
	sessionCreated := false
	if len(clientReq.SessionId) > 0 {
		uidList, err := o.queryUsersBySessionId(clientReq.SessionId)
		if err != nil {
			result := ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
			return formatJson(result), -1, curSessionId, err			
		}
		includesMe := false
		for _, xUid := range uidList {
			if meUid == xUid {
				includesMe = true
				//break	
			}else{
				toUid = xUid
				clientReq.ToUid = xUid
			}
		}
		if !includesMe {
			log4go.Error("SendImMsg(): invalid session [%s], current user [%d] not included in this session", clientReq.SessionId, meUid)
			result := ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID }
			return formatJson(result), -1, curSessionId, errors.New(fmt.Sprintf("User '%d' not included in session '%s'", meUid, clientReq.SessionId))	
		}
		curSessionId = clientReq.SessionId
	}else{
		// 需要根据user_id创建或者查询session
		toUid  = clientReq.ToUid
	}

	if curSessionId == "" {
		curSessionId, _ = o.querySessionByFromAndToUser(meUid, toUid)
		if curSessionId == "" {
			// 查询不到对应的session,需要创建
			curSessionId = genImSessionId(meUid, toUid)
			sessionCreated = true
		}		
	}

	result := ResponseInfo{ Code: RET_OK, Msg: MSG_OK }	

	log4go.Debug("SendImMsg(): try to save message info to db.")		
	tranx, err := o.getDbTransaction()
	if err != nil {
		log4go.Error("SendImMsg(): getDbTransaction failed, error [ %s ]", err)
		result = ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
		return formatJson(result),  -1, curSessionId, err			
	}

	defer func() {
        if result.Code == RET_OK {
        	tranx.Commit()
        }else{
        	tranx.Rollback()
        }
    }()	

	//nowUnix := time.Now().UnixNano() / int64(time.Millisecond)
	// 插入一条消息在 idb_message
	msgId, err := o.saveImMsgToMyMsg(clientReq, curSessionId, meUid, nowUnix, tranx)
	if err != nil {
		result = ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
		return formatJson(result),  msgId, curSessionId, err			
	}
	if sessionCreated {
		// 保存session的相关信息
		err = o.saveNewImSession(curSessionId, meUid, toUid, msgId, tranx)
		if err != nil {
			result = ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
			return formatJson(result), msgId, curSessionId, err			
		}
	}else {
		// 更新session的maxMsgId
		err = o.updateImSessionMaxMsgId(curSessionId, meUid, toUid, msgId, tranx)
		if err != nil {
			result = ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
			return formatJson(result), msgId, curSessionId,err			
		}		
	}

	// 将消息写入 idb_imsession_messages
	err = o.saveImMsgToSession(clientReq, curSessionId, meUid, msgId, nowUnix, tranx)
	if err != nil {
		result = ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR }
		return formatJson(result), msgId, curSessionId,err			
	}	

	// 更新ihp_t_imsession_summary表
	o.updateSessionSummary(curSessionId, msgId, nowUnix, tranx)	

	return formatJson(result), msgId, curSessionId,nil	
}

// 是否是垃圾或广告消息
func isSpawnMsg(r *http.Request,headers *CommonHeaders, sendMsgReq *sendMsgClientReq) bool {
	// TODO: imlementation
	// 先简单实现
	if strings.Contains(sendMsgReq.MsgContent, "赚钱") ||
	   strings.Contains(sendMsgReq.MsgContent, "开店") ||
	   strings.Contains(sendMsgReq.MsgContent, "加盟") ||
	   strings.Contains(sendMsgReq.MsgContent, "加QQ") ||
	   strings.Contains(sendMsgReq.MsgContent, "加qq") {
	   	log4go.Warn("Msg '%s' identified as as spawn message!")
	   	return true
	}

	return false
}

// 检查me_uid是否包含在session_id对应的session里面 
func (o *APIHandler)isValidSender(meUid int64, sessionId string) bool {
	// TODO: implementation
	return true
}

func (o *APIHandler)transformSessionMessage(msgDbInfo *ImSessionMessageDb) *ImMsgRespInfo {
	if msgDbInfo == nil {
		return nil
	}
	fromUser, err := o.queryUserLiteInfoById(msgDbInfo.FromUid)
	if err != nil {
		return nil
	}
	fromUser.UserId = fromUser.UserId+DUOBAO_USER_ID_BASE
	msgResp := ImMsgRespInfo{
		MsgId: msgDbInfo.MsgId, 
		MsgType: msgDbInfo.MsgType,
		MsgContent: msgDbInfo.MsgContent,
		MsgTs: transUnixTime2DateString(msgDbInfo.MsgTs/1000), 
		FromUser: fromUser,
	}

	return &msgResp
}

func handleRecvMsgParams(r *http.Request,headers *CommonHeaders) (*recvMsgClientReq, int, string) {
	sidStr := r.FormValue("session_id")
	if len(sidStr) == 0 {
		log4go.Warn("receive_message(): 'session_id' is empty!")
		return nil, RET_PARAM_MISSING, MSG_PARAM_MISSING
	}
	
	lastIdStr := r.FormValue("last_id")
	lastId, _ := strconv.Atoi(lastIdStr)
	if lastId < 0 {
		log4go.Warn("receive_message(): 'last_uid' invalid [ %s ]", lastIdStr)
		return nil, RET_PARAM_INVALID, MSG_PARAM_INVALID
	}
	
	direction := r.FormValue("direction")
	if lastId > 0 && !(direction == "afterward" || direction == "forward") {
		log4go.Warn("receive_message(): 'direction' invalid [ %s ]", direction)
		return nil, RET_PARAM_INVALID, MSG_PARAM_INVALID		
	}

	pageSizeStr := r.FormValue("page_size")
	pageSize, _ := strconv.Atoi(pageSizeStr)
	if pageSize < 0 || pageSize % 10 != 0 /*|| pageSize > 30*/ {
		log4go.Warn("receive_message(): 'page_size' invalid [ %s ]", pageSizeStr)
		return nil, RET_PARAM_INVALID, MSG_PARAM_INVALID
	}
	if pageSize == 0 {
		pageSize = 10
	}

	clientReq := recvMsgClientReq {
		SessionId: sidStr,
		LastId: int64(lastId),
		Direction: direction,
		PageSize: pageSize,
	}
	return &clientReq, RET_OK, MSG_OK
}

func handleQuerySessionParams(r *http.Request,headers *CommonHeaders) (*querySessionReq, int, string) {
	sidStr := r.FormValue("session_id")
	toUidStr := r.FormValue("to_uid")
	if len(sidStr) == 0 && len(toUidStr) == 0 {
		log4go.Warn("query_session_details(): both 'session_id' and 'to_uid' are empty!")
		return nil, RET_PARAM_MISSING, MSG_PARAM_MISSING
	}
	
	clientReq := querySessionReq {
		SessionId: sidStr,
		ToUid: int64(-1),
	}
	if len(sidStr) > 0 {
		return &clientReq, RET_OK, MSG_OK
	}

	toUid, err := strconv.Atoi(toUidStr)
	if err != nil || toUid <= 0 {
		log4go.Warn("query_session_details(): invalid 'to_uid' [%s]", toUidStr)
		return nil, RET_PARAM_INVALID, MSG_PARAM_INVALID		
	}
	clientReq.ToUid = int64(toUid)
	log4go.Debug("handleQuerySessionParams(): session_id='%s', to_uid=%s, final ToUid is %d", sidStr, toUidStr, clientReq.ToUid)

	return &clientReq, RET_OK, MSG_OK
}

func (o *APIHandler)isUserInSession(userId int64, sessionId string) (bool, error) {
	uidList, err := o.queryUsersBySessionId(sessionId)
	if err != nil {
		return false, err
	}

	includes := false
	for _, xUid := range uidList {
		if userId == xUid {
			includes = true
			break	
		}
	}

	return includes, nil
}

// 是否官方助手账号
func isHelperAccount(userId int64) bool {
	ret := false

/*	g_mutex.Lock()
	for _, account := range g_helper_accounts {
		if account.UserId == userId {
			ret = true
			break
		}
	}
	g_mutex.Unlock()
*/	
	return ret
}





