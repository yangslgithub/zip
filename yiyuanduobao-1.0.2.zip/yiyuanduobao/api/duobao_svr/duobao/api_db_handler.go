package duobao

import (
	"strconv"
	"strings"
	"time"
	"errors"
	//"strings"
	"database/sql"
	//"errors"
	"fmt"
	"github.com/alecthomas/log4go"
	//"github.com/coopernurse/gorp"
	_ "github.com/go-sql-driver/mysql"
	//"crypto/md5"
	//"log"
	//"net/http"
	//"net/url"
	//"math/rand"
	//"strconv"
	//"strings"
	//"sync"
	//"time"
)

// 通过id获取用户信息
func (o *APIHandler) GetUsrInfoById(userID int64) (*UserInfoDb, error) {
	dbMap, tableName := o.GetUserDBMap()
	log4go.Debug("GetUsrInfoById() called userID:%d", userID)

	sqlQuery := fmt.Sprintf(`SELECT user_id, recommend_uid, part_code, nick_name, gender, avatar, mobile, openid, reg_device, user_ip, addr_default_code, 
		addr_delivery_code, plateform_reg, user_type, gold, created_at FROM %s WHERE user_id = ? limit 1`, tableName)
	var UserInfo UserInfoDb
	err := dbMap.SelectOne(&UserInfo, sqlQuery, userID)		
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Warn("GetUsrInfoById(): can't find user info of userID [ %d ]", userID)
			return nil, err			
		}else{
			log4go.Error("GetUsrInfoById(%d): query db error [ %s ]", userID, err)
			return nil, err			
		}
	}
	return &UserInfo, nil		
}

// 
func (o *APIHandler) queryUserLiteInfoById(userID int64) (*UserRespLite, error) {
	dbMap, tableName := o.GetUserDBMap()
	log4go.Debug("queryUserLiteInfoById() called userID:%d", userID)

	sqlQuery := fmt.Sprintf(`SELECT user_id, nick_name, gender, avatar FROM %s WHERE user_id = ? limit 1`, tableName)
	var UserInfo UserInfoDb
	err := dbMap.SelectOne(&UserInfo, sqlQuery, userID)		
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Warn("queryUserLiteInfoById(): can't find user info of userID [ %d ]", userID)
			return nil, err			
		}else{
			log4go.Error("queryUserLiteInfoById(%d): query db error [ %s ]", userID, err)
			return nil, err			
		}
	}
	userLite := UserRespLite {
		UserId: UserInfo.UserId, 
		Nickname: UserInfo.Nickname,
		Gender: UserInfo.Gender,
		Avatar: UserInfo.Avatar,
	}
	return &userLite, nil		
}

// 通过id列表获取用户列表信息
func (o *APIHandler) GetUsrInfoByIdList(userIDList []int64) ([]UserInfoDb, error) {
	if len(userIDList) <= 0 {
		log4go.Error("GetUsrInfoByIdList() len(userIDList) <= 0!")
		return nil, nil
	}
	dbMap, tableName := o.GetUserDBMap()
	inSQL := Int64List2InSQL(userIDList)
	log4go.Debug("GetUsrInfoByIdList() userIDList = [%s]", inSQL)

	sqlQuery := fmt.Sprintf(`SELECT user_id, part_code, nick_name, gender, avatar, mobile, openid, reg_device, user_ip, city, addr_default_code, 
		addr_delivery_code, plateform_reg, user_type, created_at FROM %s WHERE user_id IN (%s)`, tableName, inSQL)
	var UserInfoList []UserInfoDb
	_, err := dbMap.Select(&UserInfoList, sqlQuery)
	if err != nil {
		log4go.Error("GetUsrInfoByIdList() error:  %s", err)
		return nil, err
	}
	return UserInfoList, nil		
}

func (o *APIHandler) InsertUserToDB(usrInfo UserInfoDb) error {	
	dbMap, _ := o.GetUserDBMap()
	log4go.Debug("insertUserToDB() Mobile:%s", usrInfo.Mobile)		
	
	err := dbMap.Insert(&usrInfo)
	if err != nil {
		log4go.Error("insertUserToDB err [%s] ", err)
	}
	return err	
}

// 通过id设置用户信息
func (o *APIHandler) SetUsrInfoById(userId int64, nickName string, avatar string) (error) {
	dbMap, tableName := o.GetUserDBMap()
	log4go.Debug("SetUsrInfoById() called userId:%d", userId)

	// 更改
	sqlCommand := fmt.Sprintf("UPDATE %s SET nick_name=?, avatar=? WHERE user_id=?", tableName)	
	_, err := dbMap.Exec(sqlCommand, nickName, avatar, userId)
	if err != nil {
		log4go.Error("SetUsrInfoById(): update User info error [ %s ]", err)
		return err
	}		
	return nil
}

func (o *APIHandler) queryUserIdByToken(userToken string) (int64,error) {
	tokenDbMap, tableName := o.GetUserTokenDBMap(userToken)
	// 查询Token
	tokenQuery := fmt.Sprintf("SELECT user_id from %s where cur_token=?", tableName)
	value, err := tokenDbMap.SelectNullInt(tokenQuery, userToken)
	if err != nil {
		log4go.Warn("Can't find user by token: %s, err: %s", userToken, err)
		return -1, err
	} else {
		if value.Valid {
			return value.Int64, nil 
		} else {
			log4go.Warn("Can't find user by token: %s", userToken)
			return -1, nil
		}
	}
}

func (o *APIHandler) queryTokenByUserId(UserId int64) (string,error) {
	tokenDbMap, tableName := o.GetUserTokenDBMap("")
	// 查询Token
	var UserToken UserTokenInfo
	tokenQuery := fmt.Sprintf("SELECT cur_token from %s where user_id=?", tableName)
	err := tokenDbMap.SelectOne(&UserToken, tokenQuery, UserId)
	if err != nil {
		log4go.Warn("Can't find token by user_id: %s, err: %s", UserId, err)
		return "", err
	} else {
		return UserToken.CurToken, err
	}
}


// 获取单个商品信息
func (o *APIHandler) GetGoodsInfoByIdDb(goodsId int64) (*GoodsInfoDb, error) {
	dbMap, tableName := o.GetGoodsDBMap()
	log4go.Debug("GetGoodsInfoByIdDb() ...... goodsId:%d", goodsId)

	sqlQuery := fmt.Sprintf(`SELECT goods_id, price, category_id, brand_id, cid_list, title, sub_title,
		keywords, image_url, description, created_at FROM %s WHERE goods_id=?`, tableName)
	var goods GoodsInfoDb
	err := dbMap.SelectOne(&goods, sqlQuery, goodsId)
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Warn("GetGoodsInfoByIdDb(): can't find goods by goodsId [%d]", goodsId)
			return nil, nil
		}else {
			log4go.Error("GetGoodsInfoByIdDb(): query db error [ %s ]", err)
			return nil, err
		}
	}	
	return &goods, nil		
}

// 获取商品详细信息
func (o *APIHandler) GetGoodsDataByIdDb(goodsId int64) ([]GoodsMediaDb, error) {
	dbMap, tableName := o.GetGoodsDataDBMap()	
	log4go.Debug("GetGoodsDataByIdDb() goodsId = %d", goodsId)

	sqlQuery := fmt.Sprintf(`SELECT content_id, goods_id, type, priority, content, created_at 
		FROM %s WHERE goods_id = %d ORDER BY priority ASC `, tableName, goodsId)
	var goodsData []GoodsMediaDb
	_, err := dbMap.Select(&goodsData, sqlQuery)
	if err != nil {
		log4go.Error("GetGoodsDataByIdDb() error:  %s", err)
		return nil, err
	}
	return goodsData, nil		
}

// 获取商品信息(通过id批量)
func (o *APIHandler) GetGoodsInfoByIdsDb(goodsIds []int64) ([]GoodsInfoDb, error) {
	if len(goodsIds) <= 0 {
		log4go.Error("GetGoodsInfoByIdsDb() ......len(goodsIds) <= 0")
		return nil, errors.New("len(goodsIds)==0")
	}
	
	dbMap, tableName := o.GetGoodsDBMap()
	log4go.Debug("GetGoodsInfoByIdsDb() ......")
	
	inSQL := Int64List2InSQL(goodsIds)
	log4go.Debug("GetGoodsInfoByIdsDb() goodsIds = [%s]", inSQL)

	sqlQuery := fmt.Sprintf(`SELECT goods_id, price, category_id, brand_id, cid_list, title, sub_title,
		keywords, image_url, description, created_at FROM %s WHERE goods_id in (%s)`, tableName, inSQL)
	var goodsList []GoodsInfoDb
	_, err := dbMap.Select(&goodsList, sqlQuery)
	if err != nil {
		log4go.Error("GetGoodsInfoByIdsDb() error:  %s", err)
		return nil, err
	}
	return goodsList, nil		
}

// 获取首页banner信息
func (o *APIHandler) GetBannerListDb() ([]BannerConfDb, error) {
	dbMap, tableName := o.GetBannerDBMap()
	log4go.Debug("GetBannerList() ......")

	sqlQuery := fmt.Sprintf(`SELECT id, image_url, ref_url FROM %s `, tableName)
	var bannerList []BannerConfDb
	_, err := dbMap.Select(&bannerList, sqlQuery)
	if err != nil {
		log4go.Error("GetBannerList() error:  %s", err)
		return nil, err
	}
	return bannerList, nil		
}

// 获取首页商品夺宝信息
func (o *APIHandler) GetIndexDuobaoListDb() ([]DuobaoInfoDb, error) {
	dbMap, tableName := o.GetDuobaoDBMap()
	log4go.Debug("GetIndexDuobaoListDb() ......")

	// 选择正在进行中的夺宝活动
	sqlQuery := fmt.Sprintf(`SELECT period, active_status, goods_id, title, price, need_total, joined_num, 
		remain_num, buy_unit, show_tag, created_at FROM %s WHERE active_status=1`, tableName)
	var duobaoList []DuobaoInfoDb
	_, err := dbMap.Select(&duobaoList, sqlQuery)
	if err != nil {
		log4go.Error("GetIndexDuobaoListDb() error:  %s", err)
		return nil, err
	}
	
	return duobaoList, nil		
}

// 获取首页中奖通知列表
func (o *APIHandler) GetIndexLuckyListDb() ([]DuobaoInfoDb, error) {
	dbMap, tableName := o.GetDuobaoDBMap()
	log4go.Debug("GetIndexLuckyListDb() ......")

	// 选择已经揭晓的夺宝，并按最新揭晓时间排序
	sqlQuery := fmt.Sprintf(`SELECT period, goods_id, title, lucky_no, lucky_guy FROM %s 
		WHERE active_status=3  ORDER BY publish_at DESC LIMIT 20`, tableName)
	var duobaoList []DuobaoInfoDb
	_, err := dbMap.Select(&duobaoList, sqlQuery)
	if err != nil {
		log4go.Error("GetIndexDuobaoListDb() error:  %s", err)
		return nil, err
	}	
	return duobaoList, nil		
}

// 根据期号id获取商品夺宝信息
func (o *APIHandler) GetDuobaoInfoByPeriodDb(period int64) (*DuobaoInfoDb, error) {
	log4go.Debug("GetDuobaoInfoByPeriodDb() ......period=%d", period)
	if period <= 0 {
		return nil, errors.New(fmt.Sprintf("parameter period is error!"))
	}
	
	dbMap, tableName := o.GetDuobaoDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT period, active_status, goods_id, title, price, need_total, joined_num, 
		remain_num, buy_unit, lucky_no, lucky_guy, ssc_period_no, show_tag, created_at, publish_at FROM %s WHERE period=?`, tableName)
	var duobao DuobaoInfoDb
	err := dbMap.SelectOne(&duobao, sqlQuery, period)
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Warn("GetDuobaoInfoByPeriodDb(): can't find duobao by period [%d]", period)
			return nil, nil
		}else {
			log4go.Error("GetDuobaoInfoByPeriodDb(): query db error [ %s ]", err)
			return nil, err
		}
	}
	return &duobao, nil		
}

// 期号id批量获取商品夺宝信息
func (o *APIHandler) GetDuobaoInfoByPeriodListDb(periodList []int64) ([]DuobaoInfoDb, error) {
	log4go.Debug("GetDuobaoInfoByPeriodListDb() ...... len(periodList): %d", len(periodList))
	
	if len(periodList) <= 0 {
		log4go.Error("GetDuobaoInfoByPeriodListDb(): len(periodList) <= 0")
		return nil, nil
	}

	inSQL := Int64List2InSQL(periodList)
	log4go.Debug("GetDuobaoInfoByPeriodListDb() periodList = [%s]", inSQL)
	
	dbMap, tableName := o.GetDuobaoDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT period, active_status, goods_id, title, price, need_total, joined_num, 
		remain_num, buy_unit, lucky_no, lucky_guy, show_tag, ssc_period_no, created_at, publish_at FROM %s WHERE period IN (%s)`, tableName, inSQL)
	var duobaos []DuobaoInfoDb
	_, err := dbMap.Select(&duobaos, sqlQuery)
	if err != nil {
		log4go.Error("GetDuobaoInfoByPeriodListDb(): query db error [ %s ]", err)
		return nil, err
	}	
	return duobaos, nil		
}


// 根据商品id获取商品夺宝信息
func (o *APIHandler) GetDuobaoListByGoodsIdDb(goodsId int64, status int, lastId int64, pageSize int) ([]DuobaoInfoDb, error) {
	log4go.Debug("GetDuobaoListByGoodsIdDb() ......goodsId:%d, status:%d, lastId=%d", goodsId, status, lastId)
	if goodsId <= 0 {
		return nil, errors.New(fmt.Sprintf("parameter goodsId is error!"))
	}
	
	dbMap, tableName := o.GetDuobaoDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT period, active_status, goods_id, title, price, need_total, joined_num, remain_num, buy_unit,
		lucky_no, lucky_guy, ssc_period_no, show_tag, created_at, publish_at FROM %s WHERE goods_id=? AND active_status=?`, tableName)

	if lastId > 0 {
		sqlQuery += fmt.Sprintf(" AND period < %d", lastId)
	}		
	sqlQuery += fmt.Sprintf(" ORDER BY created_at DESC LIMIT %d ", pageSize)		
		
	var duobaoList []DuobaoInfoDb
	_, err := dbMap.Select(&duobaoList, sqlQuery, goodsId, status)
	if err != nil {
		log4go.Error("GetDuobaoListByGoodsIdDb() error:  %s", err)
		return nil, err
	}	
	return duobaoList, nil		
}

// 根据全站最后N单夺宝订单信息 
func (o *APIHandler) GetNLastestDuobaoRecordsDb(fetchNum int) ([]JoinedRecord, error) {
	log4go.Debug("GetNLastestDuobaoRecordsDb() ......fetchNum=%d", fetchNum)	
	
	dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT a.order_no, a.goods_id, a.user_id, a.period, a.buy_total, a.created_at, b.nick_name, b.user_ip
					FROM %s a, idb_users b WHERE a.user_id=b.user_id AND a.status>0 ORDER BY created_at DESC `, tableName)
	if fetchNum	<= 0 {
		fetchNum = 50
	}	
	sqlQuery = sqlQuery + fmt.Sprintf(" LIMIT %d", fetchNum)	
							
	var records []JoinedRecord
	_, err := dbMap.Select(&records, sqlQuery)
	if err != nil {
		log4go.Error("GetNLastestDuobaoRecordsDb() error:  %s", err)
		return nil, err
	}	
	return records, nil		
}

// 某期夺宝参与所有记录
func (o *APIHandler) GetUserDuobaoRecordsDb(period int64) ([]JoinedRecord, error) {
	log4go.Debug("GetUserDuobaoRecordsDb() ......period=%d", period)	
	
	dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT a.user_id, a.buy_total, a.created_at, b.nick_name, b.user_ip
		FROM %s a, idb_users b WHERE a.period=%d AND a.user_id=b.user_id ORDER BY a.created_at DESC `, tableName, period)	
							
	var joinedList []JoinedRecord
	_, err := dbMap.Select(&joinedList, sqlQuery)
	if err != nil {
		log4go.Error("GetUserDuobaoRecordsDb() error:  %s", err)
		return nil, err
	}	
	return joinedList, nil		
}

// 获取一页的某期夺宝参与记录
func (o *APIHandler) GetOnePageUserDuobaoRecords(period int64, lastOrderNo string, pageSize int64) ([]JoinedRecord, error) {
	log4go.Debug("GetOnePageUserDuobaoRecords() ......period=%d, lastOrderNo=%s", period, lastOrderNo)	
	
	dbMap, tableName := o.GetSubOrderDBMap()	
//	sqlQuery := fmt.Sprintf(`SELECT a.user_id, a.buy_total, a.created_at, b.nick_name, a.order_no, b.user_ip
//		FROM %s a, idb_users b WHERE a.period=%d AND a.user_id=b.user_id ORDER BY a.created_at DESC `, tableName, period)	
	sqlQuery := fmt.Sprintf(`SELECT a.user_id, a.buy_total, a.created_at, b.nick_name, a.order_no, b.user_ip, b.city, b.avatar 
		FROM %s a, idb_users b WHERE a.period=%d AND a.status > 0 `, tableName, period)
	if len(lastOrderNo) > 0 {
		sqlQuery += fmt.Sprintf(" AND a.order_no < %s", lastOrderNo)
	}		
	sqlQuery += fmt.Sprintf(" AND a.user_id=b.user_id ORDER BY a.created_at DESC LIMIT %d ", pageSize)
							
	var joinedList []JoinedRecord
	_, err := dbMap.Select(&joinedList, sqlQuery)
	if err != nil {
		log4go.Error("GetOnePageUserDuobaoRecords() error:  %s", err)
		return nil, err
	}	
	return joinedList, nil		
}

// 某期夺宝中奖信息(中奖者、订单 昵称 用户id 参与人次 揭晓时间 夺宝时间)
func (o *APIHandler) GetLuckyInfoByPeriodDb(period int64) (*JoinedRecord, error) {
	log4go.Debug("GetLuckyInfoByPeriodDb() ......period=%d", period)
	
	duobao, err := o.GetDuobaoInfoByPeriodDb(period)
	if err != nil {
		log4go.Error("GetLuckyInfoByPeriodDb() GetDuobaoInfoByPeriodDb error: %s", err)
		return nil, err
	}		
	
	// 不是已揭晓状态
	if duobao.Status != 3 {
		return nil, nil
	}
	
	dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT a.order_no, a.user_id, a.buy_total, a.created_at, b.nick_name, b.user_ip, b.city, b.avatar  
		FROM %s a, idb_users b WHERE a.period=%d AND a.user_id=b.user_id AND a.user_id=%d AND a.status>0  
		ORDER BY a.created_at DESC `, tableName, period, duobao.LuckyGuy)	
							
	var records []JoinedRecord
	_, err = dbMap.Select(&records, sqlQuery)
	if err != nil {
		log4go.Error("GetLuckyInfoByPeriodDb(): query db error [ %s ]", err)
		return nil, err
	}
	if len(records) <= 0 {
		log4go.Warn("GetLuckyInfoByPeriodDb(): query db EMPTY user: %d period: %d", duobao.LuckyGuy, period)
		return nil, err		
	}
	
	totalNum := 0
	for 	_, rec := range records {
		totalNum = totalNum + rec.BuyTotal
	}

	retInfo := JoinedRecord {
		BuyTotal: totalNum,
		UserId: records[0].UserId,
		NickName: records[0].NickName,
		AvatarPath: records[0].AvatarPath,
		LastIp: records[0].LastIp,
		City: records[0].City,
	}
	
	return &retInfo, nil		
}


// 夺宝中奖信息(根据期号列表)
func (o *APIHandler) GetLuckyInfoByPeriodListDb(periods []int64) ([]JoinedRecord, error) {	
	log4go.Debug("GetLuckyInfoByPeriodListDb() len(periods)=%d", len(periods))
	if len(periods) <= 0 {
		return nil, errors.New("param invalid")
	}
	
	duobaos, err := o.GetDuobaoInfoByPeriodListDb(periods)
	if err != nil {
		log4go.Error("GetLuckyInfoByPeriodListDb() GetDuobaoInfoByPeriodListDb error: %s", err)
		return nil, err
	}		
	
	var retRecordes []JoinedRecord
	for _, duobao := range duobaos {
	
		// 不是已揭晓状态
		if duobao.Status != 3 || duobao.LuckyGuy==0 {
			continue
		}
		
		dbMap, tableName := o.GetSubOrderDBMap()	
		sqlQuery := fmt.Sprintf(`SELECT a.order_no, a.period, a.user_id, a.buy_total, a.created_at, b.nick_name, b.user_ip, b.city, b.avatar  
			FROM %s a, idb_users b WHERE a.period=%d AND a.user_id=b.user_id AND a.user_id=%d AND a.status>0  
			ORDER BY a.created_at DESC `, tableName, duobao.Period, duobao.LuckyGuy)	
								
		var records []JoinedRecord
		_, err = dbMap.Select(&records, sqlQuery)
		if err != nil {
			log4go.Error("GetLuckyInfoByPeriodListDb(): query db error [ %s ]", err)
			return nil, err
		}
		if len(records) <= 0 {
			//log4go.Warn("GetLuckyInfoByPeriodListDb(): query db EMPTY user: %d period: %d", duobao.LuckyGuy, duobao.Period)
			continue	
		}
		
		totalNum := 0
		for 	_, rec := range records {
			totalNum = totalNum + rec.BuyTotal
		}
	
		retInfo := JoinedRecord {
			Period: records[0].Period,
			BuyTotal: totalNum,
			UserId: records[0].UserId,
			NickName: records[0].NickName,
			AvatarPath: records[0].AvatarPath,
			LastIp: records[0].LastIp,
			City: records[0].City,
		}
		retRecordes = append(retRecordes, retInfo)
	}
	return retRecordes, nil		
}


// 某人某期夺宝参与记录
func (o *APIHandler) GetSomeoneDuobaoRecordsDb(userId int64, period int64) ([]JoinedRecord, error) {
	log4go.Debug("GetSomeoneDuobaoRecordsDb() ......userId=%d, period=%d", userId, period)	
	
	dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT a.user_id, a.buy_total, a.created_at, b.nick_name, b.user_ip
		FROM %s a, idb_users b WHERE a.period=%d AND a.user_id=%d AND a.user_id=b.user_id ORDER BY a.created_at DESC `, tableName, period, userId)	
							
	var joinedList []JoinedRecord
	_, err := dbMap.Select(&joinedList, sqlQuery)
	if err != nil {
		log4go.Error("GetSomeoneDuobaoRecordsDb() error:  %s", err)
		return nil, err
	}	
	return joinedList, nil		
}

// 获取最新揭晓夺宝列表
func (o *APIHandler) GetOnePageNewlyPublishListDb(lastTimeStamp int64, pageSize int) ([]DuobaoInfoDb, error) {
	dbMap, tableName := o.GetDuobaoDBMap()
	log4go.Debug("GetIndexDuobaoListDb() ......lastTimeStamp:%d", lastTimeStamp)

	var timeCondStr string
	if lastTimeStamp > 0 {
		timeCondStr = fmt.Sprintf(" AND publish_at < %d", lastTimeStamp)
	}

	sqlQuery := fmt.Sprintf(`SELECT period, active_status, goods_id, title, price, need_total, joined_num, lucky_no, lucky_guy, 
		remain_num, buy_unit, show_tag, created_at, publish_at 
		FROM %s WHERE active_status>1 %s ORDER BY publish_at DESC LIMIT %d `, tableName, timeCondStr, pageSize)
		
	log4go.Debug("sqlQuery: %s", sqlQuery)
	
	var duobaoList []DuobaoInfoDb
	_, err := dbMap.Select(&duobaoList, sqlQuery)
	if err != nil {
		log4go.Error("GetIndexDuobaoListDb() error:  %s", err)
		return nil, err
	}	
	return duobaoList, nil		
}

// 根据商品id获取当前商品最新一期夺宝信息
func (o *APIHandler) GetLatestDuobaoByGoodsIdDb(goodsId int64) (*DuobaoInfoDb, error) {
	log4go.Debug("GetLatestDuobaoByPeriodDb() ......goodsId=%d", goodsId)
	if goodsId <= 0 {
		log4go.Error("GetLatestDuobaoByPeriodDb() parameter goodsId is invalid!")
		return nil, errors.New(fmt.Sprintf("parameter goodsId is error!"))
	}

	dbMap, tableName := o.GetDuobaoDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT period, active_status, goods_id, title, price, need_total, joined_num, 
		remain_num, buy_unit, lucky_no, lucky_guy, ssc_period_no, show_tag, created_at, publish_at 
		FROM %s WHERE goods_id=? ORDER BY created_at DESC LIMIT 1`, tableName)
	var duobao DuobaoInfoDb
	err := dbMap.SelectOne(&duobao, sqlQuery, goodsId)
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Warn("GetLatestDuobaoByPeriodDb(): can't find duobao by goodsId [%d]", goodsId)
			return nil, nil
		}else {
			log4go.Error("GetLatestDuobaoByPeriodDb(): query db error [ %s ]", err)
			return nil, err
		}
	}
	return &duobao, nil		
}


// 获取某期第一单信息
func (o *APIHandler) GetFirstOrderFromPeroidDb(period int64) (*SubOrderDb, error) {
	log4go.Debug("GetFirstOrderFromPeroidDb() ......")
	
	dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT order_no, user_id, buy_total, created_at 
		FROM %s WHERE period=%d AND status>0 ORDER BY created_at ASC LIMIT 1 `, tableName, period)	
							
	var order SubOrderDb
	err := dbMap.SelectOne(&order, sqlQuery)		
	if err != nil {
		log4go.Error("GetFirstOrderFromPeroidDb: query db error [ %s ]", err)
		return nil, err				
	}
	return &order, nil
}


// 获取清单列表
func (o *APIHandler) GetCartListDb(userId int64) ([]CartInfo, error) {
	dbMap, tableName := o.GetCartDBMap()
	log4go.Debug("GetCartListDb() ......")
	
	sqlQuery := fmt.Sprintf(`SELECT a.user_id, a.period, a.created_at, a.buy_total, b.active_status,
		 		b.goods_id, b.title, b.need_total, b.joined_num, b.remain_num, b.buy_unit 
				FROM %s a, idb_duobao b WHERE user_id = ? AND a.period=b.period ORDER BY a.created_at DESC `, tableName)
	var cartList []CartInfo
	_, err := dbMap.Select(&cartList, sqlQuery, userId)
	if err != nil {
		log4go.Error("GetCartListDb() error:  %s", err)
		return nil, err
	}	
	
	mapId2Goods := make(map[int64]GoodsInfoDb)
	var goodsIdList []int64
	for _, cart := range cartList {
		goodsIdList = append(goodsIdList, cart.GoodsId)
	}
	goodsInfos, _ := o.GetGoodsInfoByIdsDb(goodsIdList)
	for _, goods := range goodsInfos {
		mapId2Goods[goods.GoodsId] = goods
	}
	
	for i, _ := range cartList {
		cartList[i].ImageUrl = mapId2Goods[cartList[i].GoodsId].ImageUrl
	}
		
	return cartList, nil		
}

// 添加到清单
func (o *APIHandler) InsertCartDb(userId int64, period int64, buyTotal int64) (int, error) {
	dbMap, tableName := o.GetCartDBMap()
	log4go.Debug("InsertCartDb() ...... userId: %d, period: %d, buy_total: %d", userId, period, buyTotal)
	
	sqlQuery := fmt.Sprintf("select count(1) from %s where user_id=? and period=?", tableName)
	//读取数据库,查询数据是否存在 
	count, _ := dbMap.SelectInt(sqlQuery, userId, period)	
	if count > 0 { // 清单已存在，再点添加就添加人次
		sqlCommand := fmt.Sprintf("UPDATE %s SET buy_total=buy_total+%d WHERE user_id=? and period=?", tableName, buyTotal)
		_, err := dbMap.Exec(sqlCommand, userId, period)
		if err != nil {
			log4go.Error("InsertCartDb(): 1 error [ %s ]", err)
			return -1, err
		}		
	} else {		  // 清单不存在，直接插入
		nowUnix := time.Now().Unix()
		sqlCommand := fmt.Sprintf(`INSERT INTO %s (user_id, period, buy_total, created_at) VALUES(?, ?, ?, ?)`, tableName)
		sqlRet, err := dbMap.Exec(sqlCommand, userId, period, buyTotal, nowUnix)
		if err != nil {
			log4go.Error("InsertCartDb(userId=%d, period=%d) error: %s", userId, period, err)
			return -1, err
		}
	
		if affected, _ := sqlRet.RowsAffected(); affected <= 0 {
			log4go.Warn("InsertCartDb(userId=%d, period=%d) rows affected is %d", userId, period, affected)
			return 0, nil
		} 				
	}	
	return 1, nil	
}

// 从清单中删除
func (o *APIHandler) DeleteFromCartDb(userId int64, periodList string) (bool, error) {
	dbMap, tableName := o.GetCartDBMap()
	log4go.Debug("DeleteFromCartDb() ...... userId: %d, periodList: %s", userId, periodList)
	sqlCommand := fmt.Sprintf(`DELETE FROM %s WHERE user_id=? AND period IN (%s) `, tableName, periodList)
	_, err := dbMap.Exec(sqlCommand, userId)
	if err != nil {
		log4go.Error("DeleteFromCartDb(userId=%d, periodList=%s) error: %s", userId, periodList, err)
		return false, err
	}	
	return true, nil	
}

// 夺宝结束将夺宝活动从清单中删除
func (o *APIHandler) DeleteFromCartWhenOverDb(period int64) (error) {
	dbMap, tableName := o.GetCartDBMap()
	log4go.Debug("DeleteFromCartWhenOverDb() ...... period: %d", period)
	sqlCommand := fmt.Sprintf(`DELETE FROM %s WHERE period=%d `, tableName, period)
	_, err := dbMap.Exec(sqlCommand)
	if err != nil {
		log4go.Error("DeleteFromCartWhenOverDb(period=%d) error: %s", period, err)
		return err
	}	
	return nil	
}

// 获取某期某用户下单号码
func (o *APIHandler) GetAllBuyCodeFromPeroidDb(userId int64, period int64) (int, []OwnerAllCode, error) {
	log4go.Debug("GetAllBuyCodeFromPeroidDb() ......")
	
	// 用户参与的子单
	dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT order_no, user_id, buy_total, created_at 
		FROM %s WHERE period=%d AND user_id=%d AND status>0 ORDER BY created_at DESC `, tableName, period, userId)	
							
	var joinedList []JoinedRecord
	mapNo2Info := make(map[string]JoinedRecord)
	_, err := dbMap.Select(&joinedList, sqlQuery)
	if err != nil {
		log4go.Error("GetAllBuyCodeFromPeroidDb() 1 error:  %s", err)
		return -1, nil, err
	}	
	
	// 没有参与记录
	if len(joinedList) <= 0 {
		log4go.Error("GetAllBuyCodeFromPeroidDb() USER NOT JOINED!")
		return -1, nil, nil		
	}
	
	var orderList []string
	totalNum := int(0)
	for _, item := range joinedList {
		no := fmt.Sprintf("'%s'", item.OrderNo)
		orderList = append(orderList, no)
		mapNo2Info[item.OrderNo] = item
		totalNum = totalNum + item.BuyTotal
	}
	inSQL := strings.Join(orderList, ",")
	
	// 查询子单详情 in(%s) 
	detailDbMap, DetailTableName := o.GetOrderDetailDBMap()	
	sqlQuery = fmt.Sprintf(`SELECT order_no, user_id, all_code, buy_total  
		FROM %s WHERE order_no in (%s) ORDER BY order_no DESC `, DetailTableName, inSQL)	
	log4go.Debug("sqlQuery() 2: %s", sqlQuery)						
	var detailList []OrderDetailDb
	_, err = detailDbMap.Select(&detailList, sqlQuery)
	if err != nil {
		log4go.Error("GetAllBuyCodeFromPeroidDb() 2 error:  %s", err)
		return -1, nil, err
	}	
	
	var ownerCodes []OwnerAllCode
	for _, detail := range detailList {
		timeStr := transUnixTime2MilDateString(mapNo2Info[detail.OrderNo].CreatedAt)
		item := OwnerAllCode{Time: timeStr, Total: detail.CodeTotal, Code: detail.AllCode}
		ownerCodes = append(ownerCodes, item)
	}
		
	return totalNum, ownerCodes, nil		
}

// 根据中奖号查询用户id
func (o *APIHandler) GetUserIdByLuckyCodeDb(luckCode string, period int64) (int64, error) {
	log4go.Debug("GetUserIdByLuckyCodeDb() period: %d, luckCode: %s", period, luckCode)
	
	// 查询子单详情 in(%s) -- 注意格式错误
	DbMap, TableName := o.GetOrderDetailDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT order_no, user_id 
		FROM %s WHERE period=? AND all_code like '%%%s%%' `, TableName, luckCode)
	log4go.Debug("GetUserIdByLuckyCodeDb, sqlQuery=%s", sqlQuery)	
							
	var detailList OrderDetailDb
	err := DbMap.SelectOne(&detailList, sqlQuery, period)		
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Warn("GetUserIdByLuckyCodeDb(): can't find user of period: %d, luckCode: %s", period, luckCode)
			return 0, err			
		}else{
			log4go.Error("GetUserIdByLuckyCodeDb: query db error [ %s ]", err)
			return 0, err			
		}
	}
		
	return detailList.UserId, nil		
}

// 检查下单是否有效(购买数量检查)
func (o *APIHandler) CheckOrderValid(req UploadOrderReq, mapInfo map[int64]DuobaoInfoDb) (string) {
	log4go.Debug("CheckOrderValid() ......")
	
	for _, r := range req.List {
		// 购买数量已不足
		if mapInfo[r.Period].RemainNum < r.BuyTotal {
			return mapInfo[r.Period].Title
		}	
	}		
	return ""		
}

// 查询主订单信息，by订单号
func (o *APIHandler) GetMainOrderInfoDb(orderNo string) (*SumOrderDb, error) {
	log4go.Debug("GetMainOrderInfoDb() orderNo: %s", orderNo)
	
	DbMap, TableName := o.GetOrdersDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT order_no, ping_order_id, user_id, amount, gold, rest_gold, status, created_at 
		FROM %s WHERE order_no=%s `, TableName, orderNo)
	log4go.Debug("GetUserIdByLuckyCodeDb, sqlQuery=%s", sqlQuery)	
							
	var info SumOrderDb
	err := DbMap.SelectOne(&info, sqlQuery)		
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Warn("GetMainOrderInfoDb(): can't find info of orderNo: %s", orderNo)
			return nil, err			
		}else{
			log4go.Error("GetMainOrderInfoDb: query db error [ %s ]", err)
			return nil, err			
		}
	}		
	return &info, nil		
}

// 添加主订单
func (o *APIHandler) InsertOrderDb(reqs UploadOrderReq, userId int64) (*InsertOrderResp, error) {
	dbMap, tableName := o.GetOrdersDBMap()
	log4go.Debug("InsertMainOrderDb() ...... userId: %d, Amount: %d", userId, reqs.Amount)
	nowUnix := time.Now().Unix()
	sqlCommand := fmt.Sprintf(`INSERT INTO %s (order_no, user_id, amount, gold, status, created_at) VALUES(?, ?, ?, ?, ?, ?)`, tableName)
	
	userIdStr := fmt.Sprintf("%010d", userId) 			 // uid 10位长度字符，不够，0补齐
	orderNo := fmt.Sprintf("%d%s", nowUnix, userIdStr[6:]) // 系统时间+uid后四位，共14位
	nowTimeStr := fmt.Sprintf("%13d", time.Now().UnixNano() / int64(time.Millisecond))
	nowTime, _ := strconv.ParseInt(nowTimeStr, 10, 64)
	log4go.Debug("nowTimeStr:%s, nowTime:%d", nowTimeStr, nowTime)
	
	var resp InsertOrderResp
	sqlRet, err := dbMap.Exec(sqlCommand, orderNo, userId, reqs.Amount, reqs.Gold*100, 0, nowTime)
	if err != nil {
		log4go.Error("InsertMainOrderDb error: %s", err)
		return nil, err
	}

	if affected, _ := sqlRet.RowsAffected(); affected <= 0 {
		log4go.Warn("InsertCartDb rows affected is %d", affected)
		return nil, errors.New("affected <= 0")
	} 	
	log4go.Debug("InsertMainOrderDb() main orderNo:%s", orderNo) 
	mapSubOrderInfo := make(map[int64]string)
	
	for _, order := range reqs.List {
		// 插入子订单表
		subOrderNo, err := o.InsertSubOrderDb(order, userId, orderNo, nowTime)
		if err != nil {
			return nil, err
		}
		// 插入子订单详细 支付才分配号码
		o.InsertOrderDetailDb(order, subOrderNo, userId)
		mapSubOrderInfo[order.Period] = subOrderNo // peroid -> sub_order_no
	}
	resp.InsertTime = nowTime
	resp.MainOrderNo = orderNo
	resp.mapSubOrder = mapSubOrderInfo
	return &resp, nil	
}

// 插入子订单信息 
func (o *APIHandler) InsertSubOrderDb(orderIn SingleOrder, userId int64, mainOrderNo string, time int64) (string, error) {	
	dbMap, tableName := o.GetSubOrderDBMap()
		
	periodStr := fmt.Sprintf("%011d", orderIn.Period) 			  
	orderNo := fmt.Sprintf("%s%s", mainOrderNo, periodStr) // 主订单号(14位)+期号(11位)
	log4go.Debug("InsertSubOrderDb() Period:%d, BuyTotal:%d, orderNo:%s", orderIn.Period, orderIn.BuyTotal, orderNo)	

	sqlCommand := fmt.Sprintf(`INSERT INTO %s (order_no, main_order_no, goods_id, user_id, period, buy_total, amount, status, created_at) 
		VALUES(%s, %s, %d, %d, %d, %d, %d, %d, %d)`, tableName, orderNo, mainOrderNo, orderIn.GoodsId, userId, orderIn.Period, orderIn.BuyTotal, orderIn.SubTotal, 0, time)
	//log4go.Debug("InsertSubOrderDb() sqlCommand=%s", sqlCommand)
	sqlRet, err := dbMap.Exec(sqlCommand)
	if err != nil {
		log4go.Error("InsertSubOrderDb error: %s", err)
		return "", err
	}
	if affected, _ := sqlRet.RowsAffected(); affected <= 0 {
		log4go.Warn("InsertSubOrderDb rows affected is %d", affected)
		return "", nil
	} 		
	return orderNo, err	
}


// 插入子订单详细信息 
func (o *APIHandler) InsertOrderDetailDb(orderIn SingleOrder, subOrderNo string, userId int64) (error) {	
	dbMap, tableName := o.GetOrderDetailDBMap()
	log4go.Debug("InsertOrderDetailDb() subOrderNo:%s, userId:%d", subOrderNo, userId)	

	sqlCommand := fmt.Sprintf(`INSERT INTO %s (order_no, user_id, period, buy_total) 
		VALUES(%s, %d, %d, %d)`, tableName, subOrderNo, userId, orderIn.Period, orderIn.BuyTotal)
	//log4go.Debug("InsertOrderDetailDb() sqlCommand=%s", sqlCommand)
	sqlRet, err := dbMap.Exec(sqlCommand)
	if err != nil {
		log4go.Error("InsertOrderDetailDb error: %s", err)
		return err
	}
	if affected, _ := sqlRet.RowsAffected(); affected <= 0 {
		log4go.Warn("InsertOrderDetailDb rows affected is %d", affected)
		return nil
	} 		
	return err	
}


// 设置订单已付款
func (o *APIHandler) SetOrderPayedDb(orderNo string) error {
	log4go.Debug("SetOrderPayedDb() ...... orderNo: %s", orderNo)
	if len(orderNo) <= 10 {
		return errors.New("orderNo is Invalid")
	}
	
	// 主订单
	dbmap, tableName := o.GetOrdersDBMap()
	sqlCommand := fmt.Sprintf("UPDATE %s SET status = 1 WHERE order_no=%s", tableName, orderNo)
	log4go.Debug("sqlCommand 1 : %s", sqlCommand)
	_, err := dbmap.Exec(sqlCommand)
	if err != nil {
		log4go.Error("SetOrderPayedDb(): 1 error [ %s ]", err)
		return err
	}
	// 子订单
	dbmapSub, tableNameSub := o.GetSubOrderDBMap()
	sqlCommand = fmt.Sprintf("UPDATE %s SET status = 1 WHERE main_order_no=%s", tableNameSub, orderNo)
	log4go.Debug("sqlCommand 2 : %s", sqlCommand)
	_, err = dbmapSub.Exec(sqlCommand)
	if err != nil {
		log4go.Error("SetOrderPayedDb(): 2 error [ %s ]", err)
		return err
	}		
	return nil	
}

// 设置订单需退款
func (o *APIHandler) SetOrderNeedRefoundDb(orderNo string) error {
	log4go.Debug("SetOrderNeedRefoundDb() ...... orderNo: %s", orderNo)
	if len(orderNo) <= 10 {
		return errors.New("orderNo is Invalid")
	}
	
	// 主订单
	dbmap, tableName := o.GetOrdersDBMap()
	sqlCommand := fmt.Sprintf("UPDATE %s SET status = -1 WHERE order_no=%s", tableName, orderNo)
	log4go.Debug("sqlCommand 1 : %s", sqlCommand)
	_, err := dbmap.Exec(sqlCommand)
	if err != nil {
		log4go.Error("SetOrderNeedRefoundDb(): 1 error [ %s ]", err)
		return err
	}
	// 子订单
	dbmapSub, tableNameSub := o.GetSubOrderDBMap()
	sqlCommand = fmt.Sprintf("UPDATE %s SET status = -1 WHERE main_order_no=%s", tableNameSub, orderNo)
	log4go.Debug("SetOrderNeedRefoundDb 2 : %s", sqlCommand)
	_, err = dbmapSub.Exec(sqlCommand)
	if err != nil {
		log4go.Error("SetOrderNeedRefoundDb(): 2 error [ %s ]", err)
		return err
	}		
	return nil	
}

// 设置主订单ping++的支付id
func (o *APIHandler) SetOrderPingOrderIdDb(orderNo string, pingOrderId string) error {
	log4go.Debug("SetOrderPingOrderIdDb() ...... orderNo: %s, pingOrderId=%s", orderNo, pingOrderId)
	if len(pingOrderId) <= 10 {
		return errors.New("pingOrderId is Invalid")
	}
	
	// 主订单
	dbmap, tableName := o.GetOrdersDBMap()
	sqlCommand := fmt.Sprintf("UPDATE %s SET ping_order_id = ? WHERE order_no=%s", tableName, orderNo)
	log4go.Debug("SetOrderPingOrderIdDb 1 : %s", sqlCommand)
	_, err := dbmap.Exec(sqlCommand, pingOrderId)
	if err != nil {
		log4go.Error("SetOrderPingOrderIdDb(): 1 error [ %s ]", err)
		return err
	}
	
	return nil	
}


// 获取某用户全部参与夺宝列表
func (o *APIHandler) GetMyDuobaoRecordsDb(userId int64, lastTimeStamp int64, pageSize int) ([]MyJoinedInfoDb, error) {
	
	/*dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT a.order_no, a.buy_total, a.created_at, b.publish_at, b.period, b.active_status, b.goods_id, b.title, 
		b.image_url, b.lucky_guy, b.show_tag, b.need_total, b.joined_num, b.remain_num, b.buy_unit, a.status 
		FROM %s a, idb_duobao b WHERE a.user_id=%d AND a.period=b.period AND a.status>0 `, tableName, userId)	
							
	if lastTimeStamp > 0 {
		sqlQuery += fmt.Sprintf(" AND a.created_at < %d", lastTimeStamp)
	}		
	sqlQuery += fmt.Sprintf(" ORDER BY a.created_at DESC LIMIT %d ", pageSize)				
	
	var joinedList []MyJoinedInfoDb
	_, err := dbMap.Select(&joinedList, sqlQuery)
	if err != nil {
		log4go.Error("GetMyDuobaoRecordsDb() error:  %s", err)
		return nil, err
	}	*/

	var timeCondStr string
	if lastTimeStamp > 0 {
		timeCondStr = fmt.Sprintf(" AND created_at < %d", lastTimeStamp)
	}
	dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`select t.goods_id, t.period, sum(t.buy_total) as buy_total, d.title, d.image_url, d.active_status, 
		d.lucky_guy, d.show_tag, d.need_total, d.joined_num, d.remain_num, d.buy_unit, t.created_at  
	    from (select * from %s where user_id=%d and status>0 %s order by created_at desc) as t, idb_duobao d 
		where t.period=d.period  group by t.period order by t.created_at desc `, tableName, userId, timeCondStr)	
								
	sqlQuery += fmt.Sprintf(" LIMIT %d ", pageSize)					
	
	var joinedList []MyJoinedInfoDb
	_, err := dbMap.Select(&joinedList, sqlQuery)
	if err != nil {
		log4go.Error("GetMyDuobaoRecordsDb() error:  %s", err)
		return nil, err
	}	
	
	return joinedList, nil		
}


// 获取支付后的子单详细记录
func (o *APIHandler) GetChargeRespSubOrderInfoDb(mainOrderNo string) (int, []ChargeSubOrderResp, error) {

	log4go.Debug("GetChargeRespSubOrderInfoDb() mainOrderNo: %s", mainOrderNo)
	dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT a.order_no, a.buy_total, a.status, b.period, b.goods_id, b.title  
		FROM %s a, idb_duobao b WHERE a.period=b.period AND a.main_order_no=%s `, tableName, mainOrderNo)	
									
	var orderList []ChargeSubOrderResp
	_, err := dbMap.Select(&orderList, sqlQuery)
	if err != nil {
		log4go.Error("GetChargeRespSubOrderInfoDb() error:  %s", err)
		return -1, nil, err
	}	

	var orderNoList []string
	totalNum := int(0)
	for _, item := range orderList {
		no := fmt.Sprintf("'%s'", item.SubOrderNo)
		orderNoList = append(orderNoList, no)
		totalNum = totalNum + item.BuyTotal
	}
	inSQL := strings.Join(orderNoList, ",")
	
	// 查询子单详情 in(%s) 
	detailDbMap, DetailTableName := o.GetOrderDetailDBMap()	
	sqlQuery = fmt.Sprintf(`SELECT order_no, user_id, all_code, buy_total  
		FROM %s WHERE order_no in (%s) ORDER BY order_no DESC `, DetailTableName, inSQL)	
	log4go.Debug("sqlQuery() 2: %s", sqlQuery)						
	var detailList []OrderDetailDb
	_, err = detailDbMap.Select(&detailList, sqlQuery)
	if err != nil {
		log4go.Error("GetAllBuyCodeFromPeroidDb() 2 error:  %s", err)
		return -1, nil, err
	}
	
	mapNo2Detail := make(map[string]OrderDetailDb)
	for _, detail := range detailList {
		mapNo2Detail[detail.OrderNo] = detail
	}
	
	for idx, order := range orderList {
		codeList := mapNo2Detail[order.SubOrderNo].AllCode
		codeArray := strings.Split(codeList, ",")		
		//codeList = strings.Replace(codeList, `,`, ` `, -1)
		orderList[idx].CodeList = codeArray
	}
	
	return totalNum, orderList, nil		
}

// 获取子单详细记录（通过主单号）
func (o *APIHandler) GetSubOrderInfoByMainOrderDb(mainOrderNo string) ([]ChargeSubOrderResp, error) {

	log4go.Debug("GetSubOrderInfoByMainOrderDb() mainOrderNo: %s", mainOrderNo)
	dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT a.order_no, a.buy_total, a.status, b.period, b.goods_id, b.title  
		FROM %s a, idb_duobao b WHERE a.period=b.period AND a.main_order_no=%s `, tableName, mainOrderNo)	
									
	var orderList []ChargeSubOrderResp
	_, err := dbMap.Select(&orderList, sqlQuery)
	if err != nil {
		log4go.Error("GetChargeRespSubOrderInfoDb() error:  %s", err)
		return nil, err
	}	
	
	return orderList, nil		
}

// 获取某用户全部中奖夺宝列表
func (o *APIHandler) GetMyAllLuckyRecordsDb(userId int64, lastTimeStamp int64, pageSize int) ([]MyJoinedInfoDb, error) {
	
	/*dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT a.order_no, a.buy_total, a.created_at, b.publish_at, b.period, b.active_status, b.goods_id, b.title, 
		b.image_url, b.lucky_guy, b.show_tag, b.need_total, b.joined_num, b.remain_num, b.buy_unit, a.status, b.lucky_no FROM %s a, idb_duobao b 
		WHERE a.user_id=%d AND a.user_id=b.lucky_guy AND a.status>0 AND a.period=b.period AND b.active_status=3 `, tableName, userId)	

	if lastTimeStamp > 0 {
		sqlQuery += fmt.Sprintf(" AND a.created_at < %d", lastTimeStamp)
	}		
	sqlQuery += fmt.Sprintf(" ORDER BY a.created_at DESC LIMIT %d ", pageSize)				
								
	var luckyList []MyJoinedInfoDb
	_, err := dbMap.Select(&luckyList, sqlQuery)
	if err != nil {
		log4go.Error("GetMyAllLuckyRecordsDb() error:  %s", err)
		return nil, err
	}*/	
	
	var timeCondStr string
	if lastTimeStamp > 0 {
		timeCondStr = fmt.Sprintf(" AND created_at < %d", lastTimeStamp)
	}
	dbMap, tableName := o.GetSubOrderDBMap()	
	sqlQuery := fmt.Sprintf(`select t.goods_id, t.period, sum(t.buy_total) as buy_total, d.title, d.image_url, d.active_status, 
		d.lucky_guy, d.show_tag, d.need_total, d.joined_num, d.remain_num, d.buy_unit, d.lucky_no, d.publish_at, t.created_at  
	    from (select * from %s where user_id=%d and status>0 %s order by created_at desc) as t, idb_duobao d 
		where t.period=d.period and t.user_id=d.lucky_guy and d.active_status=3 group by t.period order by t.created_at desc `, tableName, userId, timeCondStr)	
								
	sqlQuery += fmt.Sprintf(" LIMIT %d ", pageSize)					
	
	var luckyList []MyJoinedInfoDb
	_, err := dbMap.Select(&luckyList, sqlQuery)
	if err != nil {
		log4go.Error("GetMyDuobaoRecordsDb() error:  %s", err)
		return nil, err
	}			
	return luckyList, nil		
}

// 获取某用户地址信息列表
func (o *APIHandler) GetUserAddrListDb(userId int64) ([]AddrListDb, error) {
	
	dbMap, tableName := o.GetAddrListDBMap()	
	sqlQuery := fmt.Sprintf(`SELECT user_id, nick_name, mobile, code, address, is_default FROM %s 
		WHERE user_id=? AND enable=1 ORDER BY created_at DESC `, tableName)	
							
	var addrList []AddrListDb
	_, err := dbMap.Select(&addrList, sqlQuery, userId)
	if err != nil {
		log4go.Error("GetUserAddrListDb() error:  %s", err)
		return nil, err
	}	
	return addrList, nil		
}

// 新增用户收货地址
func (o *APIHandler) InsertAddrDb(req UserAddrInfoResp, userId int64) (int, error) {
	dbMap, tableName := o.GetAddrListDBMap()
	log4go.Debug("InsertAddrDb() ...... userId: %d", userId)
	nowUnix := time.Now().Unix()
	sqlCommand := fmt.Sprintf(`INSERT INTO %s (user_id, nick_name, mobile, address, is_default, created_at) VALUES(?, ?, ?, ?, ?, ?)`, tableName)
	
	sqlRet, err := dbMap.Exec(sqlCommand, userId, req.Nickname, req.Mobile, req.Address, req.IsDefault, nowUnix)
	if err != nil {
		log4go.Error("InsertAddrDb error: %s", err)
		return -1, err
	}

	if affected, _ := sqlRet.RowsAffected(); affected <= 0 {
		log4go.Warn("InsertAddrDb rows affected is %d", affected)
		return 0, nil
	} 	
	Id, _ := sqlRet.LastInsertId()
	
	// 默认地址，则其他地址非默认
	if req.IsDefault == 1 {
		sqlCommand = fmt.Sprintf("UPDATE %s SET is_default=0 WHERE user_id=? AND code!=?", tableName)	
		_, err := dbMap.Exec(sqlCommand, userId, Id)
		if err != nil {
			log4go.Error("ModifyAddrDb(): update User is_default  error [ %s ]", err)
			return 1, err
		}		
	}	
	
	return 1, nil	
}

// 删除用户收货地址
func (o *APIHandler) DelAddrDb(code int64, userId int64) (error) {
	dbMap, tableName := o.GetAddrListDBMap()
	log4go.Debug("DelAddrDb() ...... code:%d, userId: %d", code, userId)
		
	// 更改
	sqlCommand := fmt.Sprintf("UPDATE %s SET enable=0 WHERE user_id=? AND code=?", tableName)	
	_, err := dbMap.Exec(sqlCommand, userId, code)
	if err != nil {
		log4go.Error("DelAddrDb(): update User addr enable=0 error [ %s ]", err)
		return err
	}		
	return nil
}

// 更新用户收货地址
func (o *APIHandler) ModifyAddrDb(addrInfo UserAddrInfoResp, userId int64) (error) {
	dbMap, tableName := o.GetAddrListDBMap()
	log4go.Debug("ModifyAddrDb() ...... userId: %d", userId)
		
	// 更改
	sqlCommand := fmt.Sprintf("UPDATE %s SET nick_name=?,address=?,mobile=?,is_default=? WHERE user_id=? AND code=?", tableName)	
	_, err := dbMap.Exec(sqlCommand, addrInfo.Nickname, addrInfo.Address, addrInfo.Mobile, addrInfo.IsDefault, userId, addrInfo.Code)
	if err != nil {
		log4go.Error("ModifyAddrDb(): update User addr  error [ %s ]", err)
		return err
	}	
	
	// 默认地址，则其他地址非默认
	if addrInfo.IsDefault == 1 {
		sqlCommand = fmt.Sprintf("UPDATE %s SET is_default=0 WHERE user_id=? AND code!=?", tableName)	
		_, err := dbMap.Exec(sqlCommand, userId, addrInfo.Code)
		if err != nil {
			log4go.Error("ModifyAddrDb(): update User is_default  error [ %s ]", err)
			return err
		}		
	}
		
	return nil
}

func (o *APIHandler) mobileExistsInDB(mobile string) bool {
	dbmap, tableName := o.GetUserDBMap()
	mobileQuery := fmt.Sprintf("select count(1) from %s where mobile = ? ", tableName)

	//读取数据库,查询数据是否存在 mobile
	count, _ := dbmap.SelectInt(mobileQuery, mobile)
	return count > 0
}

func (o *APIHandler)updateUserToken(user_id int64) (string,error) {
	tokenDbMap, tableName2 := o.GetUserTokenDBMap("")

	// 查询Token
	tokenQuery := fmt.Sprintf("SELECT cur_token, token_updated_at from %s where user_id=?", tableName2)
	var tokenInfo UserTokenInfo
	err := tokenDbMap.SelectOne(&tokenInfo, tokenQuery, user_id)
	tokenUpdateFlag := 0	
	if err != nil {
		tokenUpdateFlag  = 1
		log4go.Warn("Can't find token info by user_id: %d, err: %s", user_id, err)
	} else {
		nowUx := time.Now().Unix()
		if nowUx - tokenInfo.TokenUpdatedAt > int64(o.sc.TokenLifeTime) {
			tokenUpdateFlag = 2
			log4go.Warn("User [%d] token should update at %d, now=%d", user_id, tokenInfo.TokenUpdatedAt, nowUx)
		}
	}

	newToken := tokenInfo.CurToken
	if tokenUpdateFlag == 1 {
		// Insert
		newToken = genUserToken(user_id)
		log4go.Info("BeforeInsert: new token for user [%d] is %s", user_id, newToken)
		var tokenInfo UserTokenInfo

		tokenInfo.UserId = user_id
		tokenInfo.CurToken = newToken
		tokenInfo.TokenUpdatedAt = time.Now().Unix()
		sqlCommand := fmt.Sprintf("Insert into %s(user_id, cur_token, token_updated_at) values(?, ?, ?)", tableName2)
		_, err = tokenDbMap.Exec(sqlCommand, 
			user_id, newToken, time.Now().Unix())
		if err != nil {
			log4go.Error("Insert new token error: %s", err)
			return "", err
		}
	} else if(tokenUpdateFlag == 2) {
		// Update
		newToken = genUserToken(user_id)
		log4go.Info("BeforeUpdate: new token for user [%d] is %s", user_id, newToken)	
		sqlCommand := fmt.Sprintf("Update %s set cur_token=?, token_updated_at=? where user_id=?", tableName2)
		tokenDbMap.Exec(sqlCommand, 
			newToken, time.Now().Unix(), user_id)
	}

	return newToken, nil
}

func (o *APIHandler) CreateDuobaoDb(goodsId int64, needTotal int, buyUnit int ) (int64, error) {
	
	log4go.Debug("CreateDuobaoDb() ...... GoodsId: %d", goodsId)
	nowUnix := time.Now().Unix()
	
	// 期号 1+xx月xx日+四位当前已开期数
	curDateStr := time.Now().Format("20060102")
	periodNum, err := o.GetPeriodLauchNumFromDateDb(curDateStr)
	if err != nil {
		log4go.Error("CreateDuobaoDb() GetPeriodLauchNumFromDateDb error: %s", err)
		return 0, err
	}
	periodNo := fmt.Sprintf("1%s%04d", curDateStr[4:], periodNum+1)
	period, _ := strconv.ParseInt(periodNo, 10, 64)
	log4go.Debug("CreateDuobaoDb() ...... period: %d", period)
	
	goodsInfo, err := o.GetGoodsInfoByIdDb(goodsId)
	if err != nil {
		log4go.Error("CreateDuobaoDb() GetGoodsInfoByIdDb error: %s", err)
		return 0, err
	}	
	
	dbMap, tableName := o.GetDuobaoDBMap()
	sqlCommand := fmt.Sprintf(`INSERT INTO %s (period, active_status, goods_id, title, image_url, price, need_total, 
		remain_num, buy_unit, show_tag, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, tableName)
	
	sqlRet, err := dbMap.Exec( sqlCommand, period, 0, goodsId, goodsInfo.Title, 
		goodsInfo.ImageUrl, goodsInfo.Price, needTotal, needTotal, buyUnit, "", nowUnix )
	if err != nil {
		log4go.Error("Insert duobao Db error: %s", err)
		return -1, err
	}

	if affected, _ := sqlRet.RowsAffected(); affected <= 0 {
		log4go.Warn("InsertAddrDb rows affected is %d", affected)
		return 0, nil
	} 	
	
	return period, nil	
}

// 获取当天已经开了几期
/*func (o *APIHandler) GetPeriodLauchNumFromDateDb(date string) (int, error) {
	log4go.Debug("GetPeriodLauchNumFromDateDb() ...... date: %s", date)
	
	tm, err := time.ParseInLocation("20060102", date, time.Local)
	if err != nil {
		log4go.Error("GetPeriodLauchNumFromDateDb(): ParseInLocation error [ %s ]", err)
	}
	todayUnix := tm.Unix()
	dbmap, tableName := o.GetDuobaoLauchDBMap()
	sqlQuery := fmt.Sprintf("select count(1) from %s where created_at >= %d and created_at <= %d ", tableName, todayUnix, todayUnix+86400)
	log4go.Debug("sqlQuery: %s", sqlQuery)
	count, err := dbmap.SelectInt(sqlQuery)
	if err != nil {
		log4go.Error("GetPeriodLauchNumFromDateDb(): query error [ %s ]", err)
		return -1, err
	}	
	return int(count), nil
}
*/
// 获取当天已经开了几期
func (o *APIHandler) GetPeriodLauchNumFromDateDb(date string) (int, error) {
	log4go.Debug("GetPeriodLauchNumFromDateDb() ...... date: %s", date)

	dbMap, tableName := o.GetPeriodOfDayDBMap()
	sqlQuery := fmt.Sprintf("SELECT max_period FROM %s WHERE date_str=?", tableName)
	var maxPeriod int
	err := dbMap.SelectOne(&maxPeriod, sqlQuery, date)
	if err != nil {
		if err == sql.ErrNoRows {
			maxPeriod = 0		
		}else{
			log4go.Error("GetPeriodLauchNumFromDateDb(%s): query db error [ %s ]", date, err)
			return 0, err			
		}
	}	

	// 将数据库的max_period字段加1（如果没有则增加一行)
	sqlCommand := fmt.Sprintf("INSERT INTO %s(date_str, max_period) VALUES(?, ?) ON DUPLICATE KEY UPDATE max_period=max_period+1", tableName)
	_, err = dbMap.Exec(sqlCommand, date, 1)
	if err != nil {
		log4go.Error("GetPeriodLauchNumFromDateDb(%s): update max_peroid failed [ %s ]", date, err)
		return 0, err			
	}		

	return maxPeriod, nil
}


func (o *APIHandler) InsertDuobaoLauchDb(period int64, createdAt int64) (int, error) {
	log4go.Debug("InsertDuobaoLauchDb() ...... period: %s", period)
	dbmap, tableName := o.GetDuobaoLauchDBMap()
	sqlCommand := fmt.Sprintf(`INSERT INTO %s (period, created_at) VALUES(?, ?)`, tableName)	
	sqlRet, err := dbmap.Exec(sqlCommand, period, createdAt)
	if err != nil {
		log4go.Error("InsertDuobaoLauchDb error: %s", err)
		return -1, err
	}

	if affected, _ := sqlRet.RowsAffected(); affected <= 0 {
		log4go.Warn("InsertDuobaoLauchDb rows affected is %d", affected)
		return 0, nil
	} 
	return 1, nil
}

func (o *APIHandler) LauchOneDuobaoDb(period int64) (error) {
	log4go.Debug("LauchOneDuobaoDb() ...... period: %d", period)
	
	duobao, err := o.GetDuobaoInfoByPeriodDb(period)
	if err != nil {
		log4go.Error("GetDuobaoInfoByPeriodDb error: %s", err)
		return err
	}
	if duobao.Status != 0 { // 非初始化状态，不能启动夺宝
		log4go.Error("LauchOneDuobaoDb error: %s", err)
		return errors.New("duobao has started!")		
	}
	
	dbmap, tableName := o.GetDuobaoDBMap()
	sqlCommand := fmt.Sprintf("UPDATE %s SET active_status = 1 WHERE period=?", tableName)
	
	_, err = dbmap.Exec(sqlCommand, period)
	if err != nil {
		log4go.Error("LauchOneDuobaoDb(): error [ %s ]", err)
		return err
	}	

	nowUnix := time.Now().Unix()
	affect, err := o.InsertDuobaoLauchDb(period, nowUnix)
	if affect != 1 {
		log4go.Error("LauchOneDuobaoDb() InsertDuobaoLauchDb db ERROR: %s!", err)
		return err			
	}	
	
	return nil
}

// 对某期夺宝活动改成正在揭晓状态
func (o *APIHandler) SetOneDuobaoCountdownDb(period int64) error {
	log4go.Debug("SetOneDuobaoCountdownDb() ...... period: %s", period)
	dbmap, tableName := o.GetDuobaoDBMap()
	sqlCommand := fmt.Sprintf("UPDATE %s SET active_status = 2 WHERE period=?", tableName)
	
	_, err := dbmap.Exec(sqlCommand, period)
	if err != nil {
		log4go.Error("SetOneDuobaoCountdownDb(): error [ %s ]", err)
		return err
	}	
	return nil	
}

// 设置某期夺宝活动揭晓时间和关联的时时彩期号
func (o *APIHandler) SetOneDuobaoPubTimeDb(period int64, pubTime int64, sscPeriodNo string) error {
	log4go.Debug("SetOneDuobaoPubTimeDb() ...... period: %s, pubTime:%d", period, pubTime)
	dbmap, tableName := o.GetDuobaoDBMap()
	sqlCommand := fmt.Sprintf("UPDATE %s SET publish_at = ?, ssc_period_no = ? WHERE period=?", tableName)
	
	_, err := dbmap.Exec(sqlCommand, pubTime, sscPeriodNo, period)
	if err != nil {
		log4go.Error("SetOneDuobaoPubTimeDb(): error [ %s ]", err)
		return err
	}	
	return nil	
}

// 设置某期夺宝活动的中奖号和用户,并置状态为已揭晓
func (o *APIHandler) SetLuckInfo2DuobaoDb(period int64, userId int64, luckyNo string) error {
	log4go.Debug("SetLuckInfo2DuobaoDb() ...... period: %s, userId:%d, luckyNo:%s", period, userId, luckyNo)
	nowUnix := time.Now().Unix() // 重新写入揭晓时间
	dbmap, tableName := o.GetDuobaoDBMap()
	sqlCommand := fmt.Sprintf("UPDATE %s SET lucky_no=?, lucky_guy=?, active_status=3, publish_at=? WHERE period=?", tableName)
	
	_, err := dbmap.Exec(sqlCommand, luckyNo, userId, nowUnix, period)
	if err != nil {
		log4go.Error("SetLuckInfo2DuobaoDb(): error [ %s ]", err)
		return err
	}	
	return nil	
}

// 获取可以揭晓的夺宝活动
func (o *APIHandler) GetCanPubDuobaoPeriodsDb() ([]int64, error) {
	log4go.Debug("GetCanPubDuobaoPeriodsDb() ......")
	var periodNoList []int64
	nowUnix := time.Now().Unix()
	
	dbMap, tableName := o.GetDuobaoDBMap()	
	// 在倒计时状态，并且到了公布时间的
	sqlQuery := fmt.Sprintf(`SELECT period, active_status, created_at FROM %s WHERE active_status=2 AND publish_at < %d AND publish_at!=0 `, tableName, nowUnix)
	var duobaoList []DuobaoInfoDb
	_, err := dbMap.Select(&duobaoList, sqlQuery)
	if err != nil {
		log4go.Error("GetCanPubDuobaoPeriodsDb() error:  %s", err)
		return nil, err
	}	
	
	for _, duobao := range duobaoList {
		periodNoList = append(periodNoList, duobao.Period)
	}	
	return periodNoList, nil	
}

// 揭晓的夺宝活动
func (o *APIHandler) PublishDuobaosDb(periodNoList []int64) error {
	log4go.Debug("PublishDuobaosDb() ......")
	
	if len(periodNoList) <= 0 {
		log4go.Debug("PublishDuobaosDb() len(periodNoList) <= 0")
		return nil		
	}
			
	// 要揭晓的夺宝信息
	Duobaos, err := o.GetDuobaoInfoByPeriodListDb(periodNoList)
	if err != nil {
		log4go.Error("GetCanPubDuobaoPeriodsDb() error:  %s", err)
		return err
	}	
	
	var periods []int64
	var sscPeriodNos []string
	mapDb2Ssc := make(map[int64]string)
	for _, duobao := range Duobaos {
		mapDb2Ssc[duobao.Period] = duobao.SscPeriodNo
		sscPeriodNos = append(sscPeriodNos, duobao.SscPeriodNo)
		
		periods = append(periods, duobao.Period)
	}
		
	// 找到关联的时时彩的中奖期号和中奖号码
	mapNo2OpenCode := make(map[string]string)
	sscInfos, _ := o.GetSscInfoByPeriodListDb(sscPeriodNos)
	for _, ssc := range sscInfos {
		mapNo2OpenCode[ssc.PeriodNo] = ssc.OpenCode
	}
	
	mapPeriod2SumValue, _ := o.GetLatestJoinedByPeriodListDB(periods)		
	log4go.Debug("PublishDuobaosDb() len(mapPeriod2SumValue):%d", len(mapPeriod2SumValue))
	
	var sscOpenCode int64
	nowUnix := time.Now().Unix()
	
	// 计算中奖号码
	for _, db := range Duobaos {
		log4go.Debug("PublishDuobaosDb() nowUnix:%d, PublishAt:%d", nowUnix, db.PublishAt)
		if nowUnix < db.PublishAt { // 没到开奖时间
			continue
		}
		sscOpenCodeStr := mapNo2OpenCode[db.SscPeriodNo]
		log4go.Debug("PublishDuobaosDb() SscPeriodNo:%s, sscOpenCodeStr:%s", db.SscPeriodNo, sscOpenCodeStr)
		
		if len(sscOpenCodeStr) == 0 { // 时时彩开奖号还没开奖
			if (db.PublishAt != 0) && (nowUnix - db.PublishAt > 1800) { // 半小时还未开奖，默认
				sscOpenCode = int64(88888)
				log4go.Debug("PublishDuobaosDb() nowUnix - db.PublishAt > 1800 DEFAULT 88888")
			} else {
				continue; // 暂时不开奖
			}
			
		} else {
			sscOpenCode, _ = strconv.ParseInt(sscOpenCodeStr, 10, 64)
		}
		joinTimeSum := mapPeriod2SumValue[db.Period]
		// 得到幸运号
		luckNo := (joinTimeSum + sscOpenCode)%int64(db.NeedTotal) + int64(10000001)
		luckNoStr := fmt.Sprintf("%d", luckNo)
		log4go.Debug("joinTimeSum:%d, sscOpenCode:%d, NeedTotal:%d", joinTimeSum, sscOpenCode, db.NeedTotal)
		log4go.Debug("luckNoStr:%s, Period:%d", luckNoStr, db.Period)

		// 找到幸运用户，写入夺宝表
		uid, _ := o.GetUserIdByLuckyCodeDb(luckNoStr, db.Period)
		o.SetLuckInfo2DuobaoDb(db.Period, uid, luckNoStr)		
	}	
	return  nil	
}


func (o *APIHandler) StartNewDuobaoPeriod(oldPeriod int64) error {
	log4go.Debug("StartNewDuobaoPeriod() ...... oldPeriod: %d", oldPeriod)
	
	duobao, err := o.GetDuobaoInfoByPeriodDb(oldPeriod)
	if err != nil {
		log4go.Error("StartNewDuobaoPeriod() GetDuobaoInfoByPeriodDb ERROR: %s!", err)
		return err			
	}
	
	// 下期被废除
	if duobao.Status == 9 {
		log4go.Error("StartNewDuobaoPeriod() Status NOT ALLOWED TO BE CONTINUE Status: %d", duobao.Status)
		return errors.New("Status NOT ALLOWED TO BE CONTINUE")		
	}
	
	// 创建新的夺宝活动
	period, err := o.CreateDuobaoDb(duobao.GoodsId, duobao.NeedTotal, duobao.BuyUnit)
	if period <= 0 {
		log4go.Error("StartNewDuobaoPeriod() CreateDuobaoDb ERROR!")
		return err		
	}
	// 启动新的夺宝活动
	err = o.LauchOneDuobaoDb(period)
	if err != nil {
		log4go.Error("StartNewDuobaoPeriod() LauchOneDuobaoDb ERROR!")
		return err		
	}	
	// 初始化活动号码池
	o.InitOneDuobaoCodePoolDb(period, duobao.NeedTotal)
	return nil
}

// 获取数据库时时彩中奖信息(根据期号列表)
func (o *APIHandler) GetSscInfoByPeriodListDb(periodList []string) ([]CqsscDb, error) {
	dbMap, tableName := o.GetCqsscDBMap()
	log4go.Debug("GetSscInfoByPeriodListDb() ......len(periodList)=%d", len(periodList))
	if len(periodList) <=0 {
		log4go.Error("GetSscInfoByPeriodListDb() len(periodList)")
		return nil, nil
	}
	
	inSQL := strings.Join(periodList, ",")

	sqlQuery := fmt.Sprintf(`SELECT period_no, open_code, opened_at FROM %s WHERE period_no IN (%s) `, tableName, inSQL)
	var sscList []CqsscDb
	_, err := dbMap.Select(&sscList, sqlQuery)
	if err != nil {
		log4go.Error("GetSscInfoByPeriodListDb() error:  %s", err)
		return nil, err
	}	
	return sscList, nil		
}

// 获取数据库时时彩中奖信息(根据期号)
func (o *APIHandler) GetSscInfoByPeriodDb(periodStr string) (*CqsscDb, error) {
	dbMap, tableName := o.GetCqsscDBMap()
	log4go.Debug("GetSscInfoByPeriodDb() ......periodStr=%s", periodStr)
	if len(periodStr) <=0 {
		log4go.Error("GetSscInfoByPeriodDb() len(periodStr)==0")
		return nil, nil
	}
	
	sqlQuery := fmt.Sprintf(`SELECT period_no, open_code, opened_at FROM %s WHERE period_no = ? `, tableName)
	var sscInfo CqsscDb
	err := dbMap.SelectOne(&sscInfo, sqlQuery, periodStr)
	if err != nil {
		log4go.Error("GetSscInfoByPeriodDb() error:  %s", err)
		return nil, err
	}	
	return &sscInfo, nil		
}

// 插入时时彩中奖信息
func (o *APIHandler) InsertSscOpenInfoDb(periodNo string, openCode string, openedAt int64) (error) {
	dbmap, tableName := o.GetCqsscDBMap()
	log4go.Debug("InsertSscOpenInfoDb() ......periodNo:%s, openCode=%s", periodNo, openCode)

	if len(periodNo) == 0 || len(openCode) == 0 {
		return errors.New("InsertSscOpenInfoDb() param is NULL")
	}
	sqlCommand := fmt.Sprintf(`INSERT INTO %s (period_no, open_code, opened_at) VALUES (?, ?, ?)`, tableName)	
	sqlRet, err := dbmap.Exec(sqlCommand, periodNo, openCode, openedAt)
	if err != nil {
		log4go.Error("InsertSscOpenInfoDb error: %s", err)
		return err
	}
	if affected, _ := sqlRet.RowsAffected(); affected <= 0 {
		log4go.Warn("InsertSscOpenInfoDb rows affected is %d", affected)
		return nil
	} 	
	
	return nil		
}

func (o *APIHandler) CalcNTimeValueSummarry(valueList []int64) int64 {
	summary := int64(0)
	for _, value := range valueList {
		timeStr := transUnixTime2CalcValue(value)
		stampVaue, _ := strconv.ParseInt(timeStr, 10, 64)
		summary = summary + stampVaue		
	}	
	return summary
}


// 初始化某期夺宝号码池-注意性能
func (o *APIHandler) InitOneDuobaoCodePoolDb(period int64, needTotal int) (int, error) {
	log4go.Debug("InitOneDuobaoCodePoolDb() ...... period: %d, needTotal=%d", period, needTotal)
	dbmap, tableName := o.GetCodePoolDBMap()
	
	var valuesStrArr []string
	for i:=1; i<=needTotal; i++ {
		codeStr := fmt.Sprintf("%d", 10000000+i)
		itemStr := fmt.Sprintf(`(%d, %s)`, period, codeStr)
		valuesStrArr = append(valuesStrArr, itemStr)
	}
	
	valuesStr := strings.Join(valuesStrArr, ",")
	
	sqlCommand := fmt.Sprintf(`INSERT INTO %s (period, code) VALUES %s`, tableName, valuesStr)	
	sqlRet, err := dbmap.Exec(sqlCommand)
	if err != nil {
		log4go.Error("InitOneDuobaoCodePoolDb error: %s", err)
		return -1, err
	}
	if affected, _ := sqlRet.RowsAffected(); affected <= 0 {
		log4go.Warn("InitOneDuobaoCodePoolDb rows affected is %d", affected)
		return 0, nil
	} 
	return needTotal, nil
}

// 从某期夺宝号码池分配号码(随机) 返回剩余量,负数表示号码池不够分配  使用事务
func (o *APIHandler) AssignCodeFromPoolDb(period int64, buyTotal int) (int, []string, error) {
	log4go.Debug("AssignCodeFromPoolDb() ...... period: %d, BuyTotal=%d", period, buyTotal)
	var retCodeArr []string
	
	dbmap, tableName := o.GetCodePoolDBMap()	
	sqlQuery := fmt.Sprintf("select count(1) from %s where period = ? AND is_assigned=0 ", tableName)
	count, err := dbmap.SelectInt(sqlQuery, period)
	log4go.Debug("AssignCodeFromPoolDb() count=%d", count)
	if err != nil {
		log4go.Error("AssignCodeFromPoolDb 111 error: %s", err)
		return -1, retCodeArr, err		
	}
	if buyTotal > int(count) {
		log4go.Error("Not enough code to be assign!")
		return int(count)-buyTotal, retCodeArr, nil
	}
	// 随机获取购买数量的记录
	sqlQuery = fmt.Sprintf(`SELECT period, code FROM %s WHERE period=? AND is_assigned=0 ORDER BY RAND() LIMIT %d `, tableName, buyTotal)
	var List []CodePoolDb
	_, err = dbmap.Select(&List, sqlQuery, period)	
	if err != nil {
		log4go.Error("AssignCodeFromPoolDb 222 error: %s", err)
		return -1, retCodeArr, err		
	}	
	// 获得分配号码	
	for _, item := range List {
		retCodeArr = append(retCodeArr, item.Code)
	}
	// 从号码池中删除已分配的号码
	inSql := strings.Join(retCodeArr, ",")	
	sqlCommand := fmt.Sprintf(`UPDATE %s SET is_assigned=1 WHERE period=%d AND code IN (%s) `, tableName, period, inSql)
	_, err = dbmap.Exec(sqlCommand)
	if err != nil {
		log4go.Error("AssignCodeFromPoolDb Update is_assigned error: %s", err)
		return -1, retCodeArr, err
	}
	
	return int(count)-buyTotal, retCodeArr, nil
}

// 分配号码写入子单详细 返回参数: bool-是否分配完毕; []string-分配失败的子单号列表
func (o *APIHandler) FillCode2OrderDetailDb(mapOrders map[string]ChargeSubOrder) (bool, []string, error) {
	log4go.Debug("FillCode2OrderDetailDb() ...... param lenth:%d", len(mapOrders))
	
	bAssignOver := false
	var failOrderList []string
	var err error
	for k, v := range mapOrders { // key值是子单号
		
		if k == "order_summary" {
			continue
		}
	
		remain, codeList, err := o.AssignCodeFromPoolDb(v.Period, v.BuyTotal)
		log4go.Debug("remain=%d", remain)
		if err != nil {
			log4go.Error("FillCode2OrderDetailDb 1 orderNO:%s ERROR: %s", k, err)	
			failOrderList = append(failOrderList, k)	
		} else if remain < 0 {
			log4go.Error("FillCode2OrderDetailDb 2 orderNO:%s ERROR: %s", k, err)	
			failOrderList = append(failOrderList, k)				
		} else {
			codeListStr := strings.Join(codeList, ",")
			// 写入子单详细
			o.UpdateCode2OrderDetailDb(k, codeListStr)
			o.UpdateDuobaoRemainDb(v.Period)	
			if remain==0 {
				bAssignOver = true
				// 已购买完毕，更改夺宝状态，产生信息夺宝活动
				go o.SetStatus2NewlyPublishDb(v.Period)
				
				// 插入 截止该商品最后夺宝时间最后50条全站参与记录
				go o.InsertLatestJoinedRecordImpl(v.Period)	
				
				// 开始新一期夺宝
				go o.StartNewDuobaoPeriod(v.Period)
				
				// 已购买完毕，该期活动从用户清单中删除
				go o.DeleteFromCartWhenOverDb(v.Period)	
			} 
		}
		// 删除清单记录
		periodStr := fmt.Sprintf("%d", v.Period)
		go o.DeleteFromCartDb(v.UserId, periodStr)		
	}
	return bAssignOver, failOrderList, err
}

// 写入子单详细号码
func (o *APIHandler) UpdateCode2OrderDetailDb(orderNo string, codeList string) (error) {
	dbMap, tableName := o.GetOrderDetailDBMap()
	log4go.Debug("UpdateCode2OrderDetailDb() called orderNo:%s, codeList:%s", orderNo, codeList)

	// 更改
	sqlCommand := fmt.Sprintf("UPDATE %s SET all_code=? WHERE order_no=?", tableName)	
	_, err := dbMap.Exec(sqlCommand, codeList, orderNo)
	if err != nil {
		log4go.Error("UpdateCode2OrderDetailDb error [ %s ]", err)
		return err
	}		
	return nil
}


// 更新夺宝剩余人次
func (o *APIHandler) UpdateDuobaoRemainDb(period int64) (error) {
	log4go.Debug("UpdateDuobaoRemainDb() period:%d", period)
	dbmap, tableName := o.GetCodePoolDBMap()	
	sqlQuery := fmt.Sprintf("select count(1) from %s where period = ? AND is_assigned=0 ", tableName)
	remainNum, err := dbmap.SelectInt(sqlQuery, period)
	log4go.Debug("UpdateDuobaoRemainDb() remainNum=%d", remainNum)
	if err != nil {
		log4go.Error("UpdateDuobaoRemainDb 111 error: %s", err)
		return err		
	}
	
	sqlQuery = fmt.Sprintf("select count(1) from %s where period = ? AND is_assigned=1 ", tableName)
	joinedNum, err := dbmap.SelectInt(sqlQuery, period)
	log4go.Debug("UpdateDuobaoRemainDb() joinedNum=%d", joinedNum)
	if err != nil {
		log4go.Error("UpdateDuobaoRemainDb 222 error: %s", err)
		return err		
	}	

	dbmapDb, tableNameDb := o.GetDuobaoDBMap()
	// 更改
	sqlCommand := fmt.Sprintf("UPDATE %s SET remain_num=?, joined_num=? WHERE period=?", tableNameDb)	
	_, err = dbmapDb.Exec(sqlCommand, remainNum, joinedNum, period)
	if err != nil {
		log4go.Error("UpdateDuobaoRemainDb error [ %s ]", err)
		return err
	}		
	return nil
}

// 购买完毕，设置夺宝状态为正在揭晓
func (o *APIHandler) SetStatus2NewlyPublishDb(period int64) (error) {
	log4go.Debug("SetStatus2NewlyPublishDb() ...... period = %d", period)

	dbmapDb, tableNameDb := o.GetDuobaoDBMap()
	// 获取最近期时时彩的期号和开奖时间
	nowUnix := time.Now().Unix()
	_, sscPeriod, _, openAt := o.GetCqsscPeriod(nowUnix)
	log4go.Debug("SetStatus2NewlyPublishDb() sscPeriod = %s, openAt=%d", sscPeriod, openAt)
	// 更改
	sqlCommand := fmt.Sprintf("UPDATE %s SET active_status=2, publish_at=?, ssc_period_no=? WHERE period=?", tableNameDb)	
	_, err := dbmapDb.Exec(sqlCommand, openAt+240/*加4分钟后揭晓*/, sscPeriod, period)
	if err != nil {
		log4go.Error("UpdateDuobaoRemainDb error [ %s ]", err)
		return err
	}	
	return nil		
}

// 插入全站最新的参与记录
func (o *APIHandler) InsertLatestJoinedRecordToDB(period int64, joinInfo JoinedRecord) error {	
	dbMap, _ := o.GetPubLastestDBMap()
	//log4go.Debug("InsertLatestJoinedRecordToDB() Period:%d, OrderNo:%s", period, joinInfo.OrderNo)		
	joinInfo.Period = period
	timeValueStr := transUnixTime2CalcValue(joinInfo.CreatedAt)
	timeValue, _ := strconv.ParseInt(timeValueStr, 10, 64)
	if timeValue > 0 {
		joinInfo.TimeValue = timeValue
	}	
	err := dbMap.Insert(&joinInfo)
	if err != nil {
		log4go.Error("InsertLatestJoinedRecordToDB err [%s] ", err)
	}
	return err	
}

// 插入关联某期夺宝全站最新的参与记录
func (o *APIHandler) InsertLatestJoinedRecordBatch(period int64, joinInfo []JoinedRecord) error {	
	log4go.Debug("InsertLatestJoinedRecordBatch() period=%d, len(joinInfo):%d", period, len(joinInfo))
	if len(joinInfo) <= 0 {
		log4go.Error("InsertLatestJoinedRecordBatch len(joinInfo) <= 0 ")
		return nil
	}
	for _, info := range joinInfo {
		err := o.InsertLatestJoinedRecordToDB(period, info)
		if err != nil {
			return err
		}
	}
	return nil	
}

// 插入关联某期夺宝全站最新的参与记录
func (o *APIHandler) InsertLatestJoinedRecordImpl(period int64) error {	
	log4go.Debug("InsertLatestJoinedRecordImpl()......")
	joinedRecds, _ := o.GetNLastestDuobaoRecordsDb(DUOBAO_NEWLY_LAST_JOIN_NUM)
	o.InsertLatestJoinedRecordBatch(period, joinedRecds)	
	return nil	
}

// 获取已揭晓夺宝活动的全站最新的参与记录
func (o *APIHandler) GetLatestJoinedByPeriodDB(period int64) ([]JoinedRecord, error) {	
	log4go.Debug("GetLatestJoinedByPeriodDB() period:%d", period)
	dbmap, tableName := o.GetPubLastestDBMap()
	sqlQuery := fmt.Sprintf(`SELECT user_id, goods_id, period, buy_total, created_at, nick_name, user_ip 
		FROM %s WHERE period=? ORDER BY created_at DESC `, tableName)
	var List []JoinedRecord
	_, err := dbmap.Select(&List, sqlQuery, period)	
	if err != nil {
		log4go.Error("AssignCodeFromPoolDb 222 error: %s", err)
		return nil, err		
	}	
	return List, nil	
}

// 获取已揭晓夺宝活动的全站最新的参与记录的时间和，批量
func (o *APIHandler) GetLatestJoinedByPeriodListDB(periods []int64) (map[int64]int64, error) {	
	log4go.Debug("GetLatestJoinedByPeriodListDB() len(periods):%d", len(periods))
	
	type PeriodTimeSum struct {
		Period 	   int64  `db:"period"`
		SumValue   int64  `db:"sum_value"`
	}	
	
	inSQL := Int64List2InSQL(periods)	
	dbmap, tableName := o.GetPubLastestDBMap()
	sqlQuery := fmt.Sprintf(`select period, sum(time_value) as sum_value  
		from %s where period in(%s) group by period `, tableName, inSQL)
		
	var List []PeriodTimeSum
	_, err := dbmap.Select(&List, sqlQuery)	
	if err != nil {
		log4go.Error("GetLatestJoinedByPeriodListDB error: %s", err)
		return nil, err		
	}	
	
	mapPeriod2SumValue := make(map[int64]int64)
	for _, item := range List {
		mapPeriod2SumValue[item.Period]=item.SumValue
	}
	return mapPeriod2SumValue, nil		
}


func (o *APIHandler) SetLatestJoinedTimeValueDB() (error) {	
	log4go.Debug("SetLatestJoinedTimeValueDB() ")
	dbmap, tableName := o.GetPubLastestDBMap()
	sqlQuery := fmt.Sprintf(`SELECT order_no, user_id, goods_id, period, created_at  
		FROM %s ORDER BY created_at DESC `, tableName)
	var List []JoinedRecord
	_, err := dbmap.Select(&List, sqlQuery)	
	if err != nil {
		log4go.Error("SetLatestJoinedTimeValueDB 222 error: %s", err)
		return err		
	}	
	
	log4go.Debug("SetLatestJoinedTimeValueDB() len(List)=%d", len(List))
	
	for _, join := range List {	
		timeStr := transUnixTime2CalcValue(join.CreatedAt)
		timeValue, _ := strconv.ParseInt(timeStr, 10, 64)
		log4go.Debug("SetLatestJoinedTimeValueDB() timeValue=%d, OrderNo=%s", timeValue, join.OrderNo)
		sqlCommand := fmt.Sprintf("UPDATE %s SET time_value=? WHERE order_no=?", tableName)	
		_, err = dbmap.Exec(sqlCommand, timeValue, join.OrderNo)
		if err != nil {
			log4go.Error("SetUsrInfoById(): update User info error [ %s ]", err)
			return err
		}				
	}		
	return nil	
}


// 插入退款
func (o *APIHandler) InsertRefundToDB(refundInfo RefundDb) error {	
	dbMap, _ := o.GetRefundDBMap()
	log4go.Debug("InsertRefundToDB() PayId:%d", refundInfo.PayId)		

	if len(refundInfo.PayId) <= 0 {
		log4go.Debug("InsertRefundToDB() len(refundInfo.PayId) <= 0")
		return errors.New("len(refundInfo.PayId) <= 0")
	}
		
	err := dbMap.Insert(&refundInfo)
	if err != nil {
		log4go.Error("InsertRefundToDB err [%s] ", err)
	}
	return err	
}

// 插入获取金币记录
func (o *APIHandler) InsertGoldRecordToDB(record GoldRecordDb) error {	

	dbMap, _ := o.GetGoldRecordDBMap()
	log4go.Debug("InsertGoldRecordToDB() UserId:%d, ParamId:%d, OrderNo:%s", record.UserId, record.ParamId, record.OrderNo)		

	if record.UserId <= 0 || len(record.OrderNo) <= 0 {
		log4go.Debug("InsertGoldRecordToDB() record.UserId <= 0")
		return errors.New("insert info error")
	}
		
	err := dbMap.Insert(&record)
	if err != nil {
		log4go.Error("InsertGoldRecordToDB err [%s] ", err)
		return err
	}
	
	// 更改金币数
	dbMapUser, tableUser := o.GetUserDBMap()
	sqlCommand := fmt.Sprintf("UPDATE %s SET gold=gold+? WHERE user_id=?", tableUser)	
	_, err = dbMapUser.Exec(sqlCommand, record.Gold, record.UserId)
	if err != nil {
		log4go.Error("InsertGoldRecordToDB(): update User(%d) gold(%d) error [ %s ]", record.UserId, record.Gold, err)
		return err
	}		
	return nil	
}

// 用户获取金币
func (o *APIHandler) SetChargeUserGetGoldDb(orderNo string, amount int) error {	
	
	log4go.Debug("SetChargeUserGetGoldDb() orderNo:%s, %d, amount:%d", orderNo, len(orderNo), amount)
	// 主订单查到下单用户
	orderInfo, err := o.GetMainOrderInfoDb(orderNo)
	if err != nil {
		log4go.Error("SetUserGetGoldDb(): GetMainOrderInfoDb error [ %s ]", err)
		return err
	}			
	// 获取用户信息(找推荐人)
	userInfo, err := o.GetUsrInfoById(orderInfo.UserId)
	if err != nil {
		log4go.Error("SetUserGetGoldDb(): GetUsrInfoById error [ %s ]", err)
		return err
	}
	
	// 没有推荐人, 不处理
	if userInfo.ReUid <= 0 {
		log4go.Info("SetUserGetGoldDb(): %d has no recommand uid", orderInfo.UserId)
		return nil
	}
	
	// 推荐人得相应金币
	nowUnix := time.Now().Unix()
	
	// 金币是单位为分，支付额为元
	gold := orderInfo.Amount*8
	log4go.Debug("gold:%f", gold)
	
	var record GoldRecordDb
	record.UserId = userInfo.ReUid
	record.OpType = "charge"         // 通过下线玩夺宝得到
	record.ParamId = userInfo.UserId
	record.Gold = int(gold)				// 8% 
	record.OrderNo = orderNo
	record.CreatedAt = nowUnix
			
	o.InsertGoldRecordToDB(record)
	return nil
}

// 支付完成抵扣金币处理
func (o *APIHandler) DeductUserGoldWhenPayed(mapSubOrder map[string]ChargeSubOrder, mainOrderNo string) error {	
	log4go.Debug("DeductUserGoldWhenPayed() ......")
	userId := int64(0)
	gold := 0
	for k, v := range mapSubOrder {
		if k == "order_summary" {
			gold = v.Gold
			userId = v.UserId
			break;
		}
	}
	return o.DeductUserGoldDb(userId, gold, mainOrderNo)
}


// 支付完成抵扣金币 DB
func (o *APIHandler) DeductUserGoldDb(userId int64, gold int, mainOrderNo string) error {	
		
	log4go.Debug("DeductUserGoldDb() gold:%d, userId:%d, mainOrderNo:%s", gold, userId, mainOrderNo)
	if userId == 0 || gold <= 0 {
		log4go.Debug("DeductUserGoldDb() gold:%d, userId:%d RETURN", gold, userId)
		return nil
	}
	
	userInfo, err := o.GetUsrInfoById(userId)
	if err != nil {
		log4go.Error("DeductUserGoldDb(): GetUsrInfoById error [ %s ]", err)
		return err
	}
	
	if userInfo.Gold <= 0 || gold > userInfo.Gold {
		log4go.Error("DeductUserGoldDb(): GetUsrInfoById error [ %s ]", err)
		return errors.New("bigger than source")	
	}
	
	// 新的金币额
	goldNum := userInfo.Gold - gold*100
	
	dbMap, tableName := o.GetUserDBMap()
	// 更改
	sqlCommand := fmt.Sprintf("UPDATE %s SET gold=? WHERE user_id=?", tableName)	
	_, err = dbMap.Exec(sqlCommand, goldNum, userId)
	if err != nil {
		log4go.Error("DeductUserGoldDb(): update User info error [ %s ]", err)
		return err
	}
	
	// 更改主订单剩余的金币额
	dbMapOrder, tableOrder := o.GetOrdersDBMap()
	sqlCommand = fmt.Sprintf("UPDATE %s SET rest_gold=%d WHERE order_no=%s", tableOrder, goldNum, mainOrderNo)	
	_, err = dbMapOrder.Exec(sqlCommand)
	if err != nil {
		log4go.Error("DeductUserGoldDb(): update main order rest_gold error [ %s ]", err)
		return err
	}		

	return nil
}


// 插入第三方合作提成明细表 DB
func (o *APIHandler) InsertCommissionDb(mainOrderNo string) error {	
		
	log4go.Debug("InsertCommissionDb() mainOrderNo:%s", mainOrderNo)
	// 主订单查到下单用户
	orderInfo, err := o.GetMainOrderInfoDb(mainOrderNo)
	if err != nil {
		log4go.Error("InsertCommissionDb(): GetMainOrderInfoDb error [ %s ]", err)
		return err
	}
	
	// 用户信息
	userInfo, err := o.GetUsrInfoById(orderInfo.UserId)
	if err != nil {
		log4go.Error("InsertCommissionDb(): GetUsrInfoById error [ %s ]", err)
		return err
	}
	
	if len(userInfo.PartCode) < 0 {
		log4go.Info("InsertCommissionDb(): user PartCode NOT exist!")
		return nil		
	}

	// 获取商品名称
	subOrders, err := o.GetSubOrderInfoByMainOrderDb(mainOrderNo)
	if err != nil {
		log4go.Error("InsertCommissionDb(): GetSubOrderInfoByMainOrderDb error [ %s ]", err)
		return err
	}
	
	var goodsNames []string
	for _, subOrder := range subOrders {
		name := subOrder.GoodsName
		if len(subOrder.GoodsName) > 10 {
			name = subOrder.GoodsName[:10]
		}		
		goodsNames = append(goodsNames, name)
	}
	goodsList := strings.Join(goodsNames, ";")
	
	// 获取分成比例
	partner, err := o.GetPartnerInfoDB(userInfo.PartCode)
	if err != nil {
		log4go.Error("InsertCommissionDb(): GetPartnerInfoDB error [ %s ]", err)
		return err
	}	
	// 插入记录	
	var commission CommissionDb
	commission.PartCode = userInfo.PartCode
	commission.OrderNo = mainOrderNo
	commission.UserId = userInfo.UserId
	commission.NickName = userInfo.Nickname
	commission.GoodsName = goodsList
	commission.Amount = int(orderInfo.Amount)
	commission.Commission = int(orderInfo.Amount)*(int)(partner.Proportion*100)
	commission.CreatedAt = orderInfo.CreatedAt / 1000
	
	dbMap, _ := o.GetCommissionDBMap()
	err = dbMap.Insert(&commission)
	if err != nil {
		log4go.Error("InsertCommissionDb err [%s] ", err)
	}		
	return nil
}


// 抵扣金币直接购买成功 返回主单号
func (o *APIHandler) OrderCompleteWithoutPay(reqs UploadOrderReq, userId int64, mapPid2Duobao map[int64]DuobaoInfoDb) (string, error) {	
	log4go.Debug("OrderCompleteWithoutPay() gold:%d, userId:%d", reqs.Gold, userId)
	
	// 下单信息填入数据库	 
	resp, err := o.InsertOrderDb(reqs, userId)
	if err != nil {
		log4go.Error("OrderCompleteWithoutPay() InsertOrderDb db ERROR!")
		return "", err	
	}	
	
	// 设置订单支付状态
	err = o.SetOrderPayedDb(resp.MainOrderNo)
	if err != nil {
		log4go.Error("OrderCompleteWithoutPay() SetOrderPayedDb db ERROR!")
		return "", err
	}
	
	map2SubOrders := make(map[string]ChargeSubOrder) // key 是子订单号	
	for _, order := range reqs.List {
		subOrderNo := resp.mapSubOrder[order.Period]
		chargeSubOrder := ChargeSubOrder{
			UserId: userId,
			OrderNo: subOrderNo,
			Period: order.Period,
			GoodsId: mapPid2Duobao[order.Period].GoodsId, 
			BuyUnit: mapPid2Duobao[order.Period].BuyUnit,
			BuyTotal: order.BuyTotal,
			SubTotal: order.SubTotal,
		}			
		map2SubOrders[subOrderNo] = chargeSubOrder
	}
		
	// 	分配号码及分配完毕后处理
	bFinish, failOrderList, err := o.FillCode2OrderDetailDb(map2SubOrders)
	log4go.Debug("OrderCompleteWithoutPay() bFinish: %d, len(fail):%d", bFinish, len(failOrderList))
	if err != nil {
		log4go.Debug("OrderCompleteWithoutPay() FillCode2OrderDetailDb err:%s", err)
		return "", err
	}
	
	// 抵扣金币
	err = o.DeductUserGoldDb(userId, reqs.Gold, resp.MainOrderNo)
	if err != nil {
		log4go.Debug("OrderCompleteWithoutPay() FillCode2OrderDetailDb err:%s", err)
		return "", err
	}
	return resp.MainOrderNo, nil	
}

// 获取用户金币的获取明细
func (o *APIHandler) GetUserGetGoldDetailDB(userId int64, lastTimeStamp int64, pageSize int) ([]GoldRecordDb, error) {	
	log4go.Debug("GetUserGetGoldDetailDB() userId:%d, lastTimeStamp:%d", userId, lastTimeStamp)
		
	var timeCondStr string
	if lastTimeStamp > 0 {
		timeCondStr = fmt.Sprintf(" AND created_at < %d", lastTimeStamp)
	}

	dbMap, tableName := o.GetGoldRecordDBMap()	
	sqlQuery := fmt.Sprintf(`select id, user_id, op_type, param_id, gold, order_no, created_at 
		from %s where user_id=%d %s order by created_at desc `, tableName, userId, timeCondStr)								
	sqlQuery += fmt.Sprintf(" LIMIT %d ", pageSize)					
	
	var records []GoldRecordDb
	_, err := dbMap.Select(&records, sqlQuery)
	if err != nil {
		log4go.Error("GetUserGetGoldDetailDB() error:  %s", err)
		return nil, err
	}			
	return records, nil	
}

// 获取用户金币的使用明细
func (o *APIHandler) GetUserUsedGoldMainOrderDB(userId int64, lastTimeStamp int64, pageSize int) ([]SumOrderDb, error) {	
	log4go.Debug("GetUserUsedGoldDetailDB() userId:%d, lastTimeStamp:%d", userId, lastTimeStamp)
		
	var timeCondStr string
	if lastTimeStamp > 0 {
		timeCondStr = fmt.Sprintf(" AND created_at < %d", lastTimeStamp)
	}

	dbMap, tableName := o.GetOrdersDBMap()	
	sqlQuery := fmt.Sprintf(`select order_no, user_id, amount, gold, rest_gold, status, created_at 
		from %s where user_id=%d %s AND status>0 AND gold>0 order by created_at desc `, tableName, userId, timeCondStr)								
	sqlQuery += fmt.Sprintf(" LIMIT %d ", pageSize)					
	
	var records []SumOrderDb
	_, err := dbMap.Select(&records, sqlQuery)
	if err != nil {
		log4go.Error("GetUserUsedGoldDetailDB() error:  %s", err)
		return nil, err
	}			
	return records, nil	
}


// 获取用户的消息列表
func (o *APIHandler) GetUserMessageListDB(userId int64, msgType string, lastId int64, pageSize int) ([]NotifyMsgDb, error) {	
	log4go.Debug("GetUserMessageDB() userId:%d, lastId:%d", userId, lastId)
		
	var CondStr string
	if lastId > 0 {
		CondStr = fmt.Sprintf(" AND id < %d", lastId)
	}

	dbMap, tableName := o.GetMessageDBMap()	
	sqlQuery := fmt.Sprintf(`select id, user_id, content, status, msg_type, is_del, created_at 
		from %s where is_del=0 AND (msg_type='toall' or (user_id=%d AND msg_type='%s')) %s order by id desc `, tableName, userId, msgType, CondStr)								
	sqlQuery += fmt.Sprintf(" LIMIT %d ", pageSize)	
	log4go.Debug("sqlQuery: %s", sqlQuery)
	
	var records []NotifyMsgDb
	_, err := dbMap.Select(&records, sqlQuery)
	if err != nil {
		log4go.Error("GetUserMessageDB() error:  %s", err)
		return nil, err
	}
	
	var ids []int64
	for _, record := range records {
		ids = append(ids, record.Id)
	}
	inSQL := Int64List2InSQL(ids)
	
	// 更改为已读
	sqlCommand := fmt.Sprintf("UPDATE %s SET status=1 WHERE id in (%s)", tableName, inSQL)	
	_, err = dbMap.Exec(sqlCommand)
	if err != nil {
		log4go.Error("GetUserMessageDB(): update status readed error [ %s ]", err)
		return nil, err
	}					
	return records, nil	
}

// 获取用户的未读消息条数
func (o *APIHandler) GetUnReadedMessageNumDB(userId int64) (int, error) {	
	log4go.Debug("GetUnReadedMessageNumDB() userId:%d", userId)

	dbMap, tableName := o.GetMessageDBMap()	
	sqlQuery := fmt.Sprintf(`select count(1) from %s where user_id=? 
		and status=0 and is_del=0 and (msg_type='sys' || msg_type='toall') `, tableName)
	//读取数据库,查询数据是否存在 
	count, err := dbMap.SelectInt(sqlQuery, userId)
	if err != nil {
		log4go.Error("GetUnReadedMessageNumDB() error:  %s", err)
		return -1, err
	}		
	return int(count), nil	
}

// 获取合作方信息
func (o *APIHandler) GetPartnerInfoDB(partCode string) (*PartnerDb, error) {	
	log4go.Debug("GetPartnerDBMap() partCode:%s", partCode)
	
	dbMap, tableName := o.GetPartnerDBMap()	
	sqlQuery := fmt.Sprintf(`select part_code, name, proportion, created_at from %s where part_code=? `, tableName)								
	
	var partner PartnerDb
	err := dbMap.SelectOne(&partner, sqlQuery, partCode)
	if err != nil {
		log4go.Error("GetPartnerDBMap() error:  %s", err)
		return nil, err
	}			
	return &partner, nil	
}