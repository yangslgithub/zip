package duobao

import (
	"time"
)

type Server struct {
	Ip   string
	Port uint
}

//服务配置定义
type ServerConfig struct {
	Serverport        string
	ApiHost         string
	WebPubUrl		string 
	Timeout           time.Duration
	DBServer       string
	Redis             []Server
	RedisPoolcnt      int
	MySqlPoolCnt      int
	WaringEmailList   []string //耗时超过水位时告警的email列表
	WaringHighwater   int64
	ErrorHighwater    int64         //周期内某个函数错误数水位
	SendEmailInterval time.Duration //发送邮件间隔,单位(分钟)
	Env               string        //当前运行环境
	TokenLifeTime	  int64  // Token有效期时间（单位:秒)
	SmsProvider		  string
	TradeBtnVisible	  int  // 交易按钮是否显示
	TradeSiteUrl	  string // 交易平台URL
	ShareUrlPrefix	  string // 分享url前缀部分
	AllowedTradeDevices string // 允许使用交易平台的设备id列表,逗号分隔
	SecondhandVisible int  // 二手交易话题Tab是否显示
	NoCheckImUserIdList string // 私聊接收人Id白名单
	HelperGreetingMsg string // 一起飞和用户打招呼的欢迎信息
	TestingAppVer string // 测试中的App版本号
	S2SReqQboxTokenUrl string // 内部请求qbox token的URL
	BannerIncludeSameCity int // 广告位是否要包括同城飞友
}

type ReqHeader struct {
	Header CommonHeaders  `json: "header"`
}

type CommonHeaders struct {
	UserToken	string  // `json: "user_token"`
	DeviceId	string  // `json: "device_id"`
	AppVer		string  // `json: "app_ver"`
	Os			string  // `json: "os"`
	OsVersion	string  // `json: "os_version"`
	Screen		string  // `json: "screen"`
	Network		string 
	Channel		string  // 渠道标识，安卓版本需要传递
	ListVer		string  
}