package duobao

import (
	"database/sql"
	"fmt"
	"github.com/alecthomas/log4go"
	"github.com/coopernurse/gorp"
	"strings"
	//"time"
)

type ImSessionUsersDb struct {
	SessionId string `db:"session_id"`
	UserId int64 `db:"user_id"`
	MaxFetchMsgId int64 `db:"max_fetch_msgid"`
	MaxSaveMsgId int64 `db:"max_save_msgid"`
}

type ImSessionSummaryDb struct {
	SessionId string `db:"session_id"`
	CreatedAt int64 `db:"created_at"`
	MsgCount int64 `db:"msg_count"`
	LastMsgId int64 `db:"last_msg_id"`
	LastMsgTs int64 `db:"last_msg_ts"`
}

type ImSessionMessageDb struct {
	SessionId string `db:"session_id"`
	FromUid int64 `db:"from_uid"`
	MsgId int64 `db:"msg_id"`
	MsgContent string `db:"msg_content"`
	MsgType string `db:"msg_type"`
	MsgTs int64 `db:"msg_ts"`
}

type MyMessageInfoDb struct {
	Id int64 `db:"id"`
	UserId int64 `db:"user_id"`
	CreatedAt int64 `db:"created_at"`
	Content string `db:"content"`
	Status int `db:"status"`
	MsgType string `db:"msg_type"`
	Uuid string `db:"uuid"`
}

/**
 * 获取ihp_t_imsession_users的db操作对象
 */
func (o *APIHandler) GetSessionUsersDbMap(inDbMap *gorp.DbMap) (*gorp.DbMap, string) {
	tableName := "idb_imsession_users" 
	dbmap := inDbMap
	if dbmap == nil {
		dbmap = &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	}
	dbmap.AddTableWithName(ImSessionUsersDb{}, tableName)
	return dbmap, tableName
}

/**
* 获取 idb_imsession_summary DbMap对象
*/
func (o *APIHandler) GetSessionSummaryDbMap(inDbMap *gorp.DbMap) (*gorp.DbMap, string) {
	tableName := "idb_imsession_summary" 
	dbmap := inDbMap
	if dbmap == nil {
		dbmap = &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	}
	dbmap.AddTableWithName(ImSessionSummaryDb{}, tableName)
	return dbmap, tableName
}

/**
* idb_imsession_messages
*/
func (o *APIHandler) GetSessionMessagesDbMap(inDbMap *gorp.DbMap) (*gorp.DbMap, string) {
	tableName := "idb_imsession_messages" 
	dbmap := inDbMap
	if dbmap == nil {
		dbmap = &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	}
	dbmap.AddTableWithName(ImSessionMessageDb{}, tableName)
	return dbmap, tableName
}

/**
* idb_message
*/
func (o *APIHandler) GetMyMessagesDbMap(inDbMap *gorp.DbMap) (*gorp.DbMap, string) {
	tableName := "idb_message" 
	dbmap := inDbMap
	if dbmap == nil {
		dbmap = &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	}
	dbmap.AddTableWithName(ImSessionMessageDb{}, tableName)
	return dbmap, tableName
}

func (o *APIHandler)queryUsersBySessionId(sessionId string) ([]int64, error){
	dbMap, tableName := o.GetSessionUsersDbMap(nil)

	sqlQuery := fmt.Sprintf(`SELECT user_id FROM %s WHERE session_id=?`, tableName)
	//读取数据库,查询userId列表
	var userIds []int64 
	_, err := dbMap.Select(&userIds, sqlQuery, sessionId)
	if err != nil {
		log4go.Error("queryUsersBySessionId(): query users  error [ %s ]",  err)			
		return nil, err
	}

	return userIds, nil
}

func (o *APIHandler)updateUserMaxFetchMsgId(sessionId string, userId int64, maxMsgId int64) error {
	dbMap, tableName := o.GetSessionUsersDbMap(nil)

	sqlCmd := fmt.Sprintf(`UPDATE %s SET max_fetch_msgid=? WHERE session_id=? AND user_id=? and max_fetch_msgid < ?`, tableName)

	_, err := dbMap.Exec(sqlCmd, maxMsgId, sessionId, userId, maxMsgId)
	if err != nil {
		log4go.Error("updateUserMaxFetchMsgId(): update db error [ %s ]",  err)			
		return err
	}
	return nil
}

func (o *APIHandler)queryOtherUsersBySessionId(sessionId string, meUid int64) ([]int64, error){
	dbMap, tableName := o.GetSessionUsersDbMap(nil)

	sqlQuery := fmt.Sprintf(`SELECT user_id FROM %s WHERE session_id=? and user_id != ?`, tableName)
	//读取数据库,查询userId列表
	var userIds []int64 
	_, err := dbMap.Select(&userIds, sqlQuery, sessionId, meUid)
	if err != nil {
		log4go.Error("queryOtherUsersBySessionId(): query other users error [ %s ]",  err)			
		return nil, err
	}

	return userIds, nil
}

func (o *APIHandler)querySessionByFromAndToUser(fromUid, toUid int64) (string, error){
	sessions, err := o.querySessionsOfOneUser(fromUid)
	if err != nil {
		return "", err
	}

	var matchedSession *ImSessionUsersDb 
	for _, sInfo := range sessions {
		if sInfo.UserId == toUid {
			matchedSession = &sInfo
			break
		}
	}

	if matchedSession != nil {
		usersCnt := 0
		for _, sInfo := range sessions {
			if sInfo.SessionId == matchedSession.SessionId {
				usersCnt++
			}
		}

		if usersCnt < 3 {
			return matchedSession.SessionId, nil
		}else{
			log4go.Warn("querySessionByFromAndToUser(): find %d users in matched session '%s'", usersCnt, matchedSession.SessionId)
		}
	}

	log4go.Warn("querySessionByFromAndToUser(): cant find session by to-user [%d]", toUid)
	return "", nil
}

func (o *APIHandler)querySessionsOfOneUser(fromUid int64) ([]ImSessionUsersDb, error){
	dbMap, tableName := o.GetSessionUsersDbMap(nil)

	sqlQuery := fmt.Sprintf(`SELECT session_id FROM %s WHERE user_id=?`, tableName)
	//读取数据库,查询userId列表
	var sessionIds []string 
	_, err := dbMap.Select(&sessionIds, sqlQuery, fromUid)
	if err != nil {
		log4go.Error("querySessionsOfOneUser(): query sessionId list error [ %s ]",  err)			
		return nil, err
	}
	if len(sessionIds) == 0 {
		log4go.Warn("querySessionsOfOneUser(): cant find session by from-user [%d]", fromUid)
		return nil, nil
	}

	quotedSids := make([]string, 0, len(sessionIds))
	for _, sid := range sessionIds {
		quotedSid := "'" + sid + "'"
		quotedSids = append(quotedSids, quotedSid)
	}
	inSql := strings.Join(quotedSids, ",")
	sqlQuery = fmt.Sprintf("SELECT * FROM %s WHERE session_id IN (%s) AND user_id != ? ORDER BY max_save_msgid DESC", tableName, inSql)
	//log4go.Debug("querySessionsOfOneUser(): sqlQuery is [ %s ]", sqlQuery)
	var sessions []ImSessionUsersDb
	_, err = dbMap.Select(&sessions, sqlQuery, fromUid)
	if err != nil {
		log4go.Error("querySessionsOfOneUser(): query userId list error [ %s ]",  err)			
		return nil, err
	}	

	return sessions, nil	
}

func (o *APIHandler)getSessionLastMsg(sessionId string) (*ImSessionMessageDb, error){
	dbMap, tableName := o.GetSessionMessagesDbMap(nil)

	sqlQuery := fmt.Sprintf("SELECT * FROM %s WHERE session_id = ? ORDER BY msg_ts DESC LIMIT 1", tableName)
	var aMsg ImSessionMessageDb
	err := dbMap.SelectOne(&aMsg, sqlQuery, sessionId)
	if err != nil {
		if err != sql.ErrNoRows {
			log4go.Error("getSessionLastMsg(): query session by '%s' failed: %s", sessionId, err)
			return nil, err
		}else{
			log4go.Debug("getSessionLastMsg(): Can't find msg by sessionId [%s]", sessionId)
			return nil, nil
		}
	}	

	return &aMsg, nil
}

func (o *APIHandler)queryMyUnreadMsgNumInOneSession(meUid int64, sessionId string) (int64, error){
	dbMap, tableName := o.GetMyMessagesDbMap(nil)

	sqlQuery := fmt.Sprintf("SELECT count(1) FROM %s WHERE user_id=? AND uuid=? AND status = 0", tableName)
	count, err := dbMap.SelectInt(sqlQuery, meUid, sessionId)
	if err != nil {
		log4go.Error("queryMyUnreadMsgNumInOneSession(): query unread_num error [ %s ], meUid=%d, sessionId='%s'", err, meUid, sessionId)
		return 0, err		
	}
	return count, nil
}

func (o *APIHandler)queryMultiMsgReadedStatus(msgIdList []int64) (map[int64]int, error){
	dbMap, tableName := o.GetMyMessagesDbMap(nil)

	inSql := Int64List2InSQL(msgIdList)

	sqlQuery := fmt.Sprintf("SELECT id, status FROM %s WHERE id IN (%s)", tableName, inSql)
	var msgs []MyMessageInfoDb
	_, err := dbMap.Select(&msgs, sqlQuery)
	if err != nil {
		log4go.Error("queryMultiMsgReadedStatus(): query read status error [ %s ]", err)
		return nil, err		
	}
	retMap := make(map[int64]int)
	for _, msg := range msgs {
		retMap[msg.Id] = msg.Status
	}

	return retMap, nil
}

func (o *APIHandler)queryMsgReadedStatus(msgId int64) (int, error){
	dbMap, tableName := o.GetMyMessagesDbMap(nil)

	sqlQuery := fmt.Sprintf("SELECT status FROM %s WHERE id = ?", tableName)
	status, err := dbMap.SelectNullInt(sqlQuery, msgId)
	if err != nil {
		log4go.Error("queryMsgReadedStatus(): query msg [%d] readed status error [ %s ]", msgId, err)
		return 0, err		
	}
	if !status.Valid {
		return 0, nil
	}
	return int(status.Int64), nil
}

func (o *APIHandler)saveImMsgToMyMsg(clientReq *sendMsgClientReq, sessionId string, fromUid int64, nowUnix int64, tranx *gorp.Transaction) (int64, error) {
	myMsg := MyMessageInfoDb {
		UserId: clientReq.ToUid,
		CreatedAt: nowUnix,
		Content: fmt.Sprintf("%x ->", fromUid + 123),
		MsgType: "im_chat",
		Uuid: sessionId,		
	}

	err := tranx.Insert(&myMsg)
	if err != nil {
		log4go.Error("saveImMsgToMyMsg(): insert sending IM message [%d]:[%s] failed, error [ %s ]", 
			clientReq.ToUid, clientReq.MsgContent, err)
		return -1, err
	}
	return myMsg.Id, nil
}

func (o *APIHandler)saveImMsgToSession(clientReq *sendMsgClientReq, sessionId string, fromUid, msgId int64, 
	nowUnix int64, tranx *gorp.Transaction) (error) {

	myMsg := ImSessionMessageDb {
		SessionId: sessionId, 
		FromUid: fromUid,
		MsgId: msgId,
		MsgContent: clientReq.MsgContent,
		MsgType: clientReq.MsgType,
		MsgTs: nowUnix,		
	}

	err := tranx.Insert(&myMsg)
	if err != nil {
		log4go.Error("saveImMsgToSession(): insert sending IM message [%d]:[%s] failed, error [ %s ]", 
			fromUid, clientReq.MsgContent, err)
		return  err
	}
	return nil
}

func (o *APIHandler)saveNewImSession(sessionId string, fromUid, toUid int64, curMsgId int64,
		tranx *gorp.Transaction) error {
	sessionUsers := ImSessionUsersDb {
		SessionId: sessionId, 
		UserId: fromUid, 
		MaxFetchMsgId: 0,
		MaxSaveMsgId: curMsgId,
	}
	err := tranx.Insert(&sessionUsers)
	if err != nil {
		log4go.Error("saveNewImSession(): insert (%s, %d) failed, error is [%s]", sessionId, fromUid, err)
		return err
	}

	sessionUsers = ImSessionUsersDb {
		SessionId: sessionId, 
		UserId: toUid, 
		MaxFetchMsgId: 0,
		MaxSaveMsgId: curMsgId,
	}
	err = tranx.Insert(&sessionUsers)
	if err != nil {
		log4go.Error("saveNewImSession(): insert (%s, %d) failed, error is [%s]", sessionId, toUid, err)
		return err
	}

	return nil
}

func (o *APIHandler)updateImSessionMaxMsgId(sessionId string, fromUid, toUid int64, curMsgId int64,
		tranx *gorp.Transaction) error {
	log4go.Debug("updateImSessionMaxMsgId() called, sessionId='%s', fromUid=%d, toUid=%d, curMsgId=%d",
		sessionId, fromUid, toUid, curMsgId)

	tableName := "idb_imsession_users"

	sqlCommand := fmt.Sprintf("UPDATE %s SET max_save_msgid=? WHERE session_id=? AND user_id=?", tableName)
	sqlRet, err := tranx.Exec(sqlCommand, curMsgId, sessionId, fromUid)
	if err != nil {
		log4go.Error("updateImSessionMaxMsgId() update db error: %s, session='%s', uid=%d", err, sessionId, fromUid)
		return err
	}
	if rowsAffected, _ := sqlRet.RowsAffected(); rowsAffected < 1 {
		log4go.Warn("updateImSessionMaxMsgId(): rowsAffected is %d where sessionId='%s' and user_id=%d", rowsAffected, sessionId, fromUid)
	}
	sqlCommand = fmt.Sprintf("UPDATE %s SET max_save_msgid=? WHERE session_id=? AND user_id=?", tableName)
	sqlRet, err = tranx.Exec(sqlCommand, curMsgId, sessionId, toUid)
	if err != nil {
		log4go.Error("updateImSessionMaxMsgId() update db error: %s, session='%s', uid=%d", err, sessionId, toUid)
		return err
	}
	if rowsAffected, _ := sqlRet.RowsAffected(); rowsAffected < 1 {
		log4go.Warn("updateImSessionMaxMsgId(): rowsAffected is %d where sessionId='%s' and user_id=%d", rowsAffected, sessionId, fromUid)
	}
	return nil
}

func (o *APIHandler)updateSessionSummary(sessionId string, lastMsgId int64, nowUnix int64, tranx *gorp.Transaction) error {
	//dbMap, tableName := o.GetSessionSummaryDbMap(nil)
	tableName := "idb_imsession_summary"

	sqlCommand := fmt.Sprintf(`INSERT INTO %s(session_id, created_at, msg_count, last_msg_id, last_msg_ts) VALUES(?, ?, 1, ?, ?)
		 ON DUPLICATE KEY UPDATE msg_count=msg_count+1, last_msg_id=?, last_msg_ts=?`, tableName)
	_, err := tranx.Exec(sqlCommand, sessionId, nowUnix, lastMsgId, nowUnix, lastMsgId, nowUnix)
	if err != nil {
		log4go.Error("updateSessionSummary() update db error: %s", err)
	}
	return err
}

func (o *APIHandler)isValidSessionId(sessionId string) (bool, error) {
	dbMap, tableName := o.GetSessionSummaryDbMap(nil)

	sqlCommand := fmt.Sprintf(`SELECT count(1) FROM %s WHERE session_id=?`, tableName)
	cnt, err := dbMap.SelectInt(sqlCommand, sessionId)
	if err != nil {
		log4go.Error("isValidSessionId() query db error: %s", err)
		return false, err
	}
	return cnt > 0, nil
}

func (o *APIHandler)loadSessionMessages(sessionId string, fromMsgId int64, afterward bool, pageSize int) ([]ImSessionMessageDb, error){
	log4go.Debug("Try to load session '%s' messages, fromMsgId=%d", sessionId, fromMsgId)

	shouldReverse := false // 对返回的列表是否要做顺序颠倒处理

	dbMap, tableName := o.GetSessionMessagesDbMap(nil)
	sqlQuery := fmt.Sprintf("SELECT from_uid, msg_id, msg_type, msg_content, msg_ts FROM %s WHERE session_id=? ORDER BY msg_ts DESC limit %d",
			tableName, pageSize)
	if fromMsgId > 0 {
		if afterward {
			sqlQuery = fmt.Sprintf(`SELECT from_uid, msg_id, msg_type, msg_content, msg_ts 
				FROM %s WHERE session_id=? AND msg_id > %d ORDER BY msg_ts asc limit %d `,
				tableName, fromMsgId, pageSize)
			//shouldReverse = true
		}else{
			sqlQuery = fmt.Sprintf(`SELECT from_uid, msg_id, msg_type, msg_content, msg_ts 
				FROM (SELECT * FROM %s WHERE session_id=? AND msg_id < %d ORDER BY msg_ts desc limit %d) t order by msg_ts asc;`,
				tableName, fromMsgId, pageSize)
		}
	}

	log4go.Debug("loadSessionMessages(): try to execute SQL [ %s ] ...", sqlQuery)
	var msgs []ImSessionMessageDb
	_, err := dbMap.Select(&msgs, sqlQuery, sessionId)
	if err != nil {
		log4go.Error("loadSessionMessages(): load messages error [ %s ]", err)
		return nil, err
	}
	log4go.Debug("Total loaded %d messages from db, shouldReverse=%t", len(msgs), shouldReverse)

	/*if shouldReverse {
		for idx := 0; idx < len(msgs)/2; idx++ {
			msgs[idx], msgs[len(msgs)-1-idx] = msgs[len(msgs)-1-idx], msgs[idx]
		}		
	}*/

	return msgs, nil
}

// 查询msgIds列表的消息是否为已读；查询完成后将这些消息都置为已读
func (o *APIHandler)queryAndSetMsgStatus(msgIds []int64, meUid int64, sessionId string, clientMaxMsgId int64) (map[int64]int, error) {
	maxMsgId := int64(-1)
	for _, msgId := range msgIds {
		if maxMsgId < msgId {
			maxMsgId = msgId
		}
	}
	if maxMsgId < clientMaxMsgId {
		maxMsgId = clientMaxMsgId
	}

	log4go.Debug("queryAndSetMsgStatus() called, meUid=%d, sessionId='%s', maxMsgId=%d", meUid, sessionId, maxMsgId)

	dbMap, tableName := o.GetMyMessagesDbMap(nil)	

	sqlCommand := fmt.Sprintf("UPDATE %s SET status=1 WHERE user_id=? AND uuid=? AND id <= ?", tableName)
	sqlRet, err := dbMap.Exec(sqlCommand, meUid, sessionId, maxMsgId)
	if err != nil {
		log4go.Error("queryAndSetMsgStatus(): update msgs status error [ %s ]", err)
		return nil, err		
	}
	if affected, _ := sqlRet.RowsAffected(); affected <= 0 {
		log4go.Warn("queryAndSetMsgStatus(): update msgs status affected row is %d, sessionId='%s', meUid=%d, maxMsgId=%d", 
			affected, sessionId, meUid, maxMsgId)		
	}

	msgId2status := make(map[int64]int)
	if len(msgIds) == 0 {
		return msgId2status, nil
	}

	inSql := Int64List2InSQL(msgIds)
	sqlQuery := fmt.Sprintf("SELECT id, status FROM %s WHERE user_id=? AND id IN (%s)", 
		tableName, inSql)
	var myMsgs []MyMessageInfoDb
	_, err = dbMap.Select(&myMsgs, sqlQuery, meUid)
	if err != nil {
		log4go.Error("queryAndSetMsgStatus(): load msgs status error [ %s ]", err)
		return nil, err
	}

	//msgId2status := make(map[int64]int)
	for _, mInfo := range myMsgs {
		msgId2status[mInfo.Id] = mInfo.Status
	}

	return msgId2status, nil	
}
