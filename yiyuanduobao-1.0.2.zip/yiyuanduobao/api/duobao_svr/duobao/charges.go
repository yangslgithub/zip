package duobao

import (
	"strconv"
	"encoding/base64"
	"fmt"
	"io/ioutil"
	"bytes"
	"strings"
	"net/http"
	"time"
	"encoding/json"
	//"errors"
	//"strings"
	//"fmt"
	//"bytes"
	//"encoding/json"
	//"io/ioutil"
	//"strconv"
	//"fmt"
	"github.com/alecthomas/log4go"
	//"net/http"
	"github.com/pingplusplus/pingpp-go/pingpp"
	"github.com/pingplusplus/pingpp-go/pingpp/charge"
)

/*支付相关数据类型*/
type (
	// 支付请求数据类型
	ChargeParams struct {
		Order_no    string                 `json:"order_no"`
		//App         App                    `json:"app"`
		Channel     string                 `json:"channel"`
		Amount      uint64                 `json:"amount"`
		Currency    string                 `json:"currency"`
		Client_ip   string                 `json:"client_ip"`
		Subject     string                 `json:"subject"`
		Body        string                 `json:"body"`
		Extra       map[string]interface{} `json:"extra,omitempty"`
		Metadata    map[string]interface{} `json:"metadata,omitempty"`
		Time_expire uint64                 `json:"time_expire,omitempty"`
		Description string                 `json:"description,omitempty"`
	}
	// 列表查询请求参数
	ListParams struct {
		Start, End string
		Limit      int
		//Filters    Filters
		Single bool
	}
	// Charge列表查询请求 数据类型
	ChargeListParams struct {
		ListParams
		Created int64
	}
	
	// 数据列表元数据类型
	ListMeta struct {
		Object string `json:"object"`
		More   bool   `json:"has_more"`
		URL    string `json:"url"`
	}

	// Charge数据类型
	ChargeInfo struct {
		ID              string                 `json:"id"`
		Object          string                 `json:"object"`
		Created         int64                  `json:"created"`
		Livemode        bool                   `json:"livemode"`
		Paid            bool                   `json:"paid"`
		Refunded        bool                   `json:"refunded"`
		App             string                 `json:"app"`
		Channel         string                 `json:"channel"`
		Order_no        string                 `json:"order_no"`
		Client_ip       string                 `json:"client_ip"`
		Amount          uint64                 `json:"amount"`
		Amount_settle   uint64                 `json:"amount_settle"`
		Currency        string                 `json:"currency"`
		Subject         string                 `json:"subject"`
		Body            string                 `json:"body"`
		Extra           map[string]interface{} `json:"extra"`
		Time_paid       uint64                 `json:"time_paid"`
		Time_expire     uint64                 `json:"time_expire"`
		Time_settle     uint64                 `json:"time_settle"`
		Transaction_no  string                 `json:"transaction_no"`
		Refunds         *RefundList            `json:"refunds"`
		Amount_refunded uint64                 `json:"amount_refunded"`
		Failure_code    string                 `json:"failure_code"`
		Failure_msg     string                 `json:"failure_msg"`
		Metadata        map[string]interface{} `json:"metadata"`
		Credential      map[string]interface{} `json:"credential"`
		Description     string                 `json:"description"`
	}

	// Charge列表数据类型
	ChargeList struct {
		ListMeta
		Values []*ChargeInfo `json:"data"`
	}
)

/*退款数据类型*/
type (
	// 退款请求数据类型
	RefundParams struct {
		Amount      uint64                 `json:"amount,omitempty"`
		Description string                 `json:"description"`
		Metadata    map[string]interface{} `json:"metadata,omitempty"`
	}

	// 退款查询请求的数据类型
	RefundListParams struct {
		ListParams
		Charge string
	}

	// 付款退款数据类型
	Refund struct {
		ID           string                 `json:"id"`
		Object       string                 `json:"object"`
		Order_no     string                 `json:"order_no"`
		Amount       uint64                 `json:"amount"`
		Succeed      bool                   `json:"succeed"`
		Status       string                 `json:"status"`
		Created      uint64                 `json:"created"`
		Time_succeed uint64                 `json:"time_succeed"`
		Description  string                 `json:"description"`
		Failure_code string                 `json:"failure_code"`
		Failure_msg  string                 `json:"failure_msg"`
		Metadata     map[string]interface{} `json:"metadata"`
		Charge_id    string                 `json:"charge"`
	}
	// 付款查询结果列表数据类型
	RefundList struct {
		ListMeta
		Values []*Refund `json:"data"`
	}
)

/*webhooks 相关数据类型*/
type (

	// webhooks 反馈数据类型
	Event struct {
		Id               string `json:"id"`
		Created          int64  `json:"created"`
		Livemode         bool   `json:"livemode"`
		Type             string `json:"type"`
		//Data             Data   `json:"data"`
		Object           string `json:"object"`
		Pending_webhooks int    `json:"pending_webhooks"`
		Request          string `json:"request"`
	}

	// webhooks 列表查询数据类型
	EventListParams struct {
		ListParams
		Created int64
	}

	// webhooks 列表数据类型
	EventList struct {
		ListMeta
		Values []*Event `json:"data"`
	}

	//webhooks 汇总数据
	Summary struct {
		Acct_id           string `json:"acct_id,omitempty"`
		App_id            string `json:"app_id.omitempty"`
		Acct_display_name string `json:"acct_display_name"`
		App_display_name  string `json:"app_display_name"`
		Summary_from      uint64 `json:"summary_from"`
		Summary_to        uint64 `json:"summary_to"`
		Charges_amount    uint64 `json:"charges_amount"`
		Charges_count     uint64 `json:"charges_count"`
	}
)


func (o *APIHandler) PostCharge(param ChargeParams) (*ChargeInfo, error) {
	
	log4go.Debug("PostCharge() orderNo: %s", param.Order_no)	
	pingpp.Key = CHARGE_LIVE_SECRET_KEY
	// rsa私钥签名
	pingpp.AccountPrivateKey = g_rsa_private_key
	
	nowUnix := time.Now().Unix()
	
	params := &pingpp.ChargeParams{
	    Order_no:  param.Order_no,
	    App:       pingpp.App{Id: CHARGE_TEST_APP_ID},
	    Channel:   param.Channel,
	    Amount:    param.Amount,
	    Currency:  "cny",
	    Client_ip: "127.0.0.1",
	    Subject:   param.Subject,
	    Body:      param.Body,
		Time_expire: uint64(nowUnix+1800),
		Metadata:  param.Metadata,
		Extra: param.Extra,
	 }
	
	//获得的第一个参数即是 Charge 对象
	ch, err := charge.New(params)
	if err != nil {
		log4go.Error("PostCharge Error: %s", err)
		return nil, err
	}
	
	chStr := formatJson(ch)
	chargeResp := new(ChargeInfo)
	err = json.Unmarshal([]byte(chStr), &chargeResp)
	log4go.Debug("PostCharge() chStr: %s", chStr)	
	if err != nil {
		return nil, err
	}
		
	return chargeResp, nil
}


// 支付网络回调
func (o *APIHandler) ChargeWebhooks(w http.ResponseWriter, r *http.Request, headers *CommonHeaders, sequence uint64) string {
	if strings.ToUpper(r.Method) == "POST" {
		buf := new(bytes.Buffer)
		buf.ReadFrom(r.Body)

		//示例 - 签名在头部信息的 x-pingplusplus-signature 字段
		//signed := `BX5sToHUzPSJvAfXqhtJicsuPjt3yvq804PguzLnMruCSvZ4C7xYS4trdg1blJPh26eeK/P2QfCCHpWKedsRS3bPKkjAvugnMKs+3Zs1k+PshAiZsET4sWPGNnf1E89Kh7/2XMa1mgbXtHt7zPNC4kamTqUL/QmEVI8LJNq7C9P3LR03kK2szJDhPzkWPgRyY2YpD2eq1aCJm0bkX9mBWTZdSYFhKt3vuM1Qjp5PWXk0tN5h9dNFqpisihK7XboB81poER2SmnZ8PIslzWu2iULM7VWxmEDA70JKBJFweqLCFBHRszA8Nt3AXF0z5qe61oH1oSUmtPwNhdQQ2G5X3g==`
		signed := r.Header.Get("X-Pingplusplus-Signature")
		log4go.Debug("ChargeWebhooks() signed: %s", signed)	

		//示例 - 待验签的数据
		//data := `{"id":"evt_eYa58Wd44Glerl8AgfYfd1sL","created":1434368075,"livemode":true,"type":"charge.succeeded","data":{"object":{"id":"ch_bq9IHKnn6GnLzsS0swOujr4x","object":"charge","created":1434368069,"livemode":true,"paid":true,"refunded":false,"app":"app_vcPcqDeS88ixrPlu","channel":"wx","order_no":"2015d019f7cf6c0d","client_ip":"140.227.22.72","amount":100,"amount_settle":0,"currency":"cny","subject":"An Apple","body":"A Big Red Apple","extra":{},"time_paid":1434368074,"time_expire":1434455469,"time_settle":null,"transaction_no":"1014400031201506150354653857","refunds":{"object":"list","url":"/v1/charges/ch_bq9IHKnn6GnLzsS0swOujr4x/refunds","has_more":false,"data":[]},"amount_refunded":0,"failure_code":null,"failure_msg":null,"metadata":{},"credential":{},"description":null}},"object":"event","pending_webhooks":0,"request":"iar_Xc2SGjrbdmT0eeKWeCsvLhbL"}`
		data := buf.String()
		// 请从 https://dashboard.pingxx.com 获取「Ping++ 公钥」
		publicKey, err := ioutil.ReadFile("./pingpp_rsa_public_key.pem")
		if err != nil {
			log4go.Error("read pingpp_rsa_public_key failure: %v", err)
		}
		
		log4go.Debug("ChargeWebhooks() buf.String: %s", data)	

		//base64解码再验证
		decodeStr, _ := base64.StdEncoding.DecodeString(signed)
		errs := pingpp.Verify([]byte(data), publicKey, decodeStr)
		if errs != nil {
			//fmt.Println(errs)
			log4go.Error("ChargeWebhooks() pingpp.Verify ERROR: %s", errs)	
			return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ) 
		} else {
			//fmt.Println("success")
			log4go.Debug("ChargeWebhooks() success!!")
		}

		webhook, err := pingpp.ParseWebhooks(buf.Bytes())
		//fmt.Println(webhook.Type)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			fmt.Fprintf(w, "fail")
			log4go.Error("ChargeWebhooks() ParseWebhooks ERROR: %s", err)	
			return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )
		}

		if webhook.Type == "charge.succeeded" {			
			w.WriteHeader(http.StatusOK)
			
			// TODO 交易成功，更改订单状态，分配号码		
			// 更改订单状态
			nowUnix := time.Now().Unix()

			OrderNo := formatJson(webhook.Data.Object["order_no"]) // 主单号
			OrderNo = strings.Replace(OrderNo, `"`, "", -1)
			payId := formatJson(webhook.Data.Object["id"])         // 支付id
			payId = strings.Replace(payId, `"`, "", -1)
			payChannel := formatJson(webhook.Data.Object["channel"]) // 支付渠道
			payChannel = strings.Replace(payChannel, `"`, "", -1)
			amountStr := formatJson(webhook.Data.Object["amount"])   // 支付金额
			amount, _ := strconv.ParseInt(amountStr, 10, 64)
			
			log4go.Debug("ChargeWebhooks() OrderNo=%s, payId:%s, payChannel:%s, amountStr:%s", OrderNo, payId, payChannel, amountStr)
			err := o.SetOrderPayedDb(OrderNo)
			if err == nil {
				// 分配号码		
				dataStr := formatJson(webhook.Data.Object["metadata"])
				mapOrders := new(map[string]ChargeSubOrder)
				err = json.Unmarshal([]byte(dataStr), &mapOrders)
				if err != nil {
					log4go.Debug("ChargeWebhooks() json.Unmarshal err:%s", err)
				}
				bFinish, failOrderList, err := o.FillCode2OrderDetailDb(*mapOrders)
				log4go.Debug("ChargeWebhooks() bFinish: %d, len(fail):%d", bFinish, len(failOrderList))
				if err != nil {
					log4go.Debug("ChargeWebhooks() err:%s", err)
				}
				
				// 分配号码出现问题，写入退款表
				if len(failOrderList) > 0 {
					refundInfo := RefundDb{
						PayId: payId, 
						MainOrderNo: OrderNo,
						Status: 0,
						Amount: int(amount),
						PayChannel: payChannel,
						CreatedAt: nowUnix,
					} 
					o.InsertRefundToDB(refundInfo)
					// 更改订单状态为需退款
					o.SetOrderNeedRefoundDb(OrderNo)
				} else {
					// 推荐人获得金币
					go o.SetChargeUserGetGoldDb(OrderNo, int(amount))
					// 扣掉金币
					go o.DeductUserGoldWhenPayed(*mapOrders, OrderNo)
					// 插入合作方提成明细
					go o.InsertCommissionDb(OrderNo)
				}
			}		
		} else if webhook.Type == "refund.succeeded" {
			// TODO your code for refund
			w.WriteHeader(http.StatusOK)
		} else {
			w.WriteHeader(http.StatusInternalServerError)
		}
	}
	return formatJson( ResponseInfo{ Code: RET_OK, Msg: "OK" } )
}