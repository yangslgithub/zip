package duobao

import (
	"crypto/md5"
	"errors"
	"strings"
	"database/sql"
	"fmt"
	"bytes"
	"encoding/json"
	"io/ioutil"
	"strconv"
	//"fmt"
	"github.com/alecthomas/log4go"
	//"github.com/coopernurse/gorp"
	"net/http"
	"time"
	//"math/rand"
)


func (o *APIHandler) GetUsrInfo(r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {
	userInfo, err := o.GetUsrInfoById(1)
	if err != nil {
		log4go.Debug("GetUsrInfo() query db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), err
	}	
	log4go.Debug("GetUsrInfo() Nickname:%s", userInfo.Nickname)	

	var result ResponseInfo

	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = userInfo
	return formatJson(result),nil
}


func (o *APIHandler) GetIndexInfo(r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {	
	log4go.Debug("GetIndexInfo() ...... ")
	
	// banner 列表
	bannerList, err := o.GetBannerListDb()
	if err != nil {
		log4go.Error("GetIndexInfo() GetBannerListDb query db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), err
	}	
	
	var bannerResp []BannerResp
	for _, banner := range bannerList {
		item := BannerResp{ Id: banner.Id, Image:banner.ImageUrl, RefUrl:banner.RefUrl, } 
		bannerResp = append(bannerResp, item)
	}	
	
	// 夺宝商品列表
	duobaoList, err := o.GetIndexDuobaoListDb()
	if err != nil {
		log4go.Error("GetIndexInfo() GetIndexDuobaoListDb query db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), err
	}	
	log4go.Debug("GetIndexInfo() len(duobaoList): %d", len(duobaoList))
	
	mapId2Goods := make(map[int64]GoodsInfoDb)
	if len(duobaoList) > 0 {
		var ids []int64
		for _, duobao := range duobaoList {
			ids = append(ids, duobao.GoodsId)
		}
		goodsList, _:= o.GetGoodsInfoByIdsDb(ids)
		for _, good := range goodsList {
			mapId2Goods[good.GoodsId] = good
			log4go.Debug("GetIndexInfo() imageurl:%s", mapId2Goods[good.GoodsId].ImageUrl)
		}			
	}

	var GoodsResp []GoodsSummaryResp
	for _, duobao := range duobaoList {
		item := GoodsSummaryResp{ 
								Status: duobao.Status,
								Period:	duobao.Period,
								PublishTime: transUnixTime2DateString(duobao.PublishAt),
								GoodsId: duobao.GoodsId,
								GoodsName: duobao.Title,
								GoodsDesc: mapId2Goods[duobao.GoodsId].Description,
								BuyUnit: duobao.BuyUnit,
								TotalTimes: duobao.NeedTotal,
								RemainingTimes: duobao.RemainNum,
								CoverImage: mapId2Goods[duobao.GoodsId].ImageUrl,
								Thumbnails: nil,
								ShowTag: duobao.ShowTag,
							} 
		GoodsResp = append(GoodsResp, item)
	}
		
	// 中奖消息列表
	luckyList, err := o.GetIndexLuckyListDb()
	if err != nil {
		log4go.Error("GetIndexInfo() GetIndexLuckyListDb query db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), err
	}	
	var luckyIds []int64
	for _, lucky := range luckyList {
		luckyIds = append(luckyIds, lucky.LuckyGuy)
	}
	users, _ := o.GetUsrInfoByIdList(luckyIds)
	mapId2User := make(map[int64]UserInfoDb)
	for _, user := range users {
		mapId2User[user.UserId] = user
	}	
	
	var LuckyResp []IndexLuckyResp
	for _, lucky := range luckyList {
		item := IndexLuckyResp{
					UserId: lucky.LuckyGuy+DUOBAO_USER_ID_BASE, 
					Nickname: mapId2User[lucky.LuckyGuy].Nickname, 
					GoodsName: lucky.Title, 
					Period: 	lucky.Period,}
		LuckyResp = append(LuckyResp, item)
	}
	 
	cartGoodsNum := 0
	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid > 0 {	
		cartInfos, _ := o.GetCartListDb(meUid)		
		if cartInfos != nil {
			cartGoodsNum = len(cartInfos)
		} 
	}
	
	var result ResponseInfo

	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = IndexRespInfo{CartGoodsNum: cartGoodsNum,  BannerList:bannerResp, LuckyList: LuckyResp, GoodsList: GoodsResp,}
	return formatJson(result),nil
}


func (o *APIHandler) GetGoodsSumImageByMedia(medias []GoodsMediaDb) ([]Thumbnail) {
	if medias == nil {
		return nil
	}
	if len(medias) <= 0 {
		return nil
	} 
	var tumbnails []Thumbnail
	for _, media := range medias {
		if media.MediaType == "sum_img" {
			tumbnail := Thumbnail{BigPic: media.Content,}
			tumbnails = append(tumbnails, tumbnail)
		}
	}
	return tumbnails
}

func (o *APIHandler) GetShowTagsString(buyUnit int) string {

	switch buyUnit {
		case 10:
			return "十元专区"
		case 5:
			return "五元专区"			
	}
	return ""
}

func (o *APIHandler) GetGoodsDetailImageByMedia(medias []GoodsMediaDb) (*GoodsDetail) {
	if medias==nil || len(medias) <= 0 {
		return nil
	} 
	var details GoodsDetail
	var goodImgs []GoodsImage
	for _, media := range medias {
		if media.MediaType == "detail_img" {
			img := GoodsImage { ImageUrl: media.Content, }
			goodImgs = append(goodImgs, img)
		}
	}
	details = GoodsDetail{ GoodsImages: goodImgs,}
	return &details
}


func (o *APIHandler) GetActivityDetail(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetActivityDetail() ...... ")
	
	periodStr := SafeParams(r, "period") 
	if len(periodStr) == 0 {
		log4go.Warn("GetActivityDetail(): period param is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )			
	}
	
	period, err := strconv.ParseInt(periodStr, 10, 64)
	if err != nil {
		log4go.Warn("GetActivityDetail(): period param is err! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	
	log4go.Debug("GetActivityDetail() periodStr:%s, period=%d ", periodStr, period)
		
	// 此期夺宝信息	
	duobao, err := o.GetDuobaoInfoByPeriodDb(period)
	if err != nil || duobao == nil  {
		log4go.Warn("GetActivityDetail(): GetDuobaoInfoByPeriodDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	// 商品信息
	goodsDb, err := o.GetGoodsInfoByIdDb(duobao.GoodsId)
	if err != nil {
		log4go.Warn("GetActivityDetail(): GetGoodsInfoByIdDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	// 商品图文详细
	goodsMedia, err := o.GetGoodsDataByIdDb(duobao.GoodsId)
	if err != nil || goodsMedia==nil {
		log4go.Warn("GetActivityDetail(): GetGoodsDataByIdDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	newPeriod := int64(0)
	newDuobao, _ := o.GetLatestDuobaoByGoodsIdDb(duobao.GoodsId)
	if newDuobao != nil {
		newPeriod = newDuobao.Period
	}
	
	// 该期第一单
	var startTime string
	subOrderInfo, err := o.GetFirstOrderFromPeroidDb(duobao.Period)
	startTime = transUnixTime2DateString(duobao.CreatedAt)
	if subOrderInfo != nil {
		startTime = transUnixTime2MilDateString(subOrderInfo.CreatedAt)
	}
	
	nowUnix := time.Now().Unix()
	// 详情返回总结构
	var dataResp ActivityDetailRespInfo // GoodsDetailRespInfo
	{
		dataResp.Status = duobao.Status
		dataResp.Period = duobao.Period
		dataResp.NextPeriod = newPeriod
		dataResp.Tips = ""
		dataResp.StartTime = startTime // 第一个下单时间
		if duobao.Status == 2 { // 正在揭晓，倒计
			dataResp.PubCountDown = duobao.PublishAt - nowUnix
		}	
		dataResp.PublishTime = transUnixTime2DateString(duobao.PublishAt) 
		
		var goodsSummary GoodsSummaryResp
		goodsSummary = GoodsSummaryResp {
			GoodsId: goodsDb.GoodsId,
			GoodsName: goodsDb.Title,
			GoodsDesc: goodsDb.Description,
			TotalTimes: duobao.NeedTotal,
			RemainingTimes: duobao.RemainNum,
			BuyUnit: duobao.BuyUnit,
			CoverImage: goodsDb.ImageUrl,
			Thumbnails: o.GetGoodsSumImageByMedia(goodsMedia),
			ShowTag: o.GetShowTagsString(duobao.BuyUnit),
			
		}
		dataResp.Goods = goodsSummary
	}
	
	// 夺宝参与记录(未揭晓)
	var retRecords []DuobaoRecord
	//if duobao.Status != 3 { // 未揭晓也可能有人参与购买
	records, _ := o.GetOnePageUserDuobaoRecords(period, "", DUOBAO_RECORD_PAGE_SIZE) // GetUserDuobaoRecordsDb(duobao.Period)	
	for _, record := range records {
		item := DuobaoRecord {
					Time: transUnixTime2MilDateString(record.CreatedAt), 
					Total: record.BuyTotal, 
					Owner: OwnerInfo { 
						UserId: record.UserId+DUOBAO_USER_ID_BASE, 
						Nickname: record.NickName,
						AvatarPath: record.AvatarPath, 
						LastIP: record.LastIp,
						City: record.City,
					},
				 }
		retRecords = append(retRecords, item)
	}
	retPageToken := ""
	if len(records) > 0 && len(records) == DUOBAO_RECORD_PAGE_SIZE {
		lastOrderNo := records[len(records) - 1].OrderNo
		retPageToken = GenPageTokenByString(lastOrderNo, true)
	}	
	log4go.Debug("GetActivityDetail() retPageToken:%s ", retPageToken)	
	retDuobaoRecordsResp := OnePageDuobaoRecords{ Items: retRecords, NextPageToken: retPageToken }
	dataResp.Records = retDuobaoRecordsResp
	//}
		
	// 幸运用户信息(已揭晓状态)
	var luckyInfo DuobaoLuckyInfo
	if duobao.Status == DUOBAO_STATUS_PUBLISHED {
		Info, _ := o.GetLuckyInfoByPeriodDb(duobao.Period)
		if Info != nil {
			luckyInfo = DuobaoLuckyInfo{ 
							LuckyCode: duobao.LuckyNo, 
							CodeTotal: Info.BuyTotal, 
							Owner: OwnerInfo{
								UserId: Info.UserId+DUOBAO_USER_ID_BASE,
								Nickname: Info.NickName,
								AvatarPath: Info.AvatarPath,
								City: Info.City,
								LastIP: Info.LastIp,
							}, 
						}
		}
		dataResp.LuckyInfo = luckyInfo
	}	
	
	// 我参与夺宝信息(此期我参与过)
	var myJoinedInfo MyJoinedInfo
	meUid := int64(-1)
	if len(headers.UserToken) > 0 {
		meUid, err = o.queryUserIdByToken(headers.UserToken)
		if meUid > 0 {
			joinTotal, ownerAllCode, err :=o.GetAllBuyCodeFromPeroidDb(meUid, period)
			var codeList string
			if ( err == nil && len(ownerAllCode) > 0 ) {
				if len(ownerAllCode[0].Code) >= 8 {
					if len(ownerAllCode[0].Code) >= 17 {
						codeList1 := ownerAllCode[0].Code[:17]
						codeList = strings.Replace(codeList1, ",", " ", -1)
					} else {
						codeList = ownerAllCode[0].Code
					}					
				}		
				myJoinedInfo = MyJoinedInfo{ 
									UserId: meUid+DUOBAO_USER_ID_BASE,
									CodeTotal: joinTotal,
									CodeList: codeList,
				}
			}
		}
		dataResp.JoinedInfo = myJoinedInfo
	}		
	 
	var result ResponseInfo

	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = dataResp
	return formatJson(result)
}

// 商品详情列表(图片列表)
func (o *APIHandler) GetGoodsDetail(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetGoodsDetail() ...... ")
	
	gidStr := SafeParams(r, "gid")
	if len(gidStr) == 0 {
		log4go.Warn("GetGoodsDetail(): gid param is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )			
	}
	
	gid, err := strconv.ParseInt(gidStr, 10, 64)
	if err != nil {
		log4go.Warn("GetGoodsDetail(): gid param is err! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	
	// 商品图文详细
	goodsMedia, err := o.GetGoodsDataByIdDb(gid)
	if err != nil {
		log4go.Warn("GetGoodsDetail(): GetGoodsDataByIdDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	// 详情返回总结构
	var dataResp GoodsDetailRespInfo
	{
		detail := o.GetGoodsDetailImageByMedia(goodsMedia)
		dataResp.DescList = detail.GoodsImages
	}

	return formatJson(ResponseInfo { Code: RET_OK, Msg: MSG_OK, Data: dataResp })	
}

// 往期揭晓
func (o *APIHandler) GetPrevActivityResults(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetPrevActivityResults() ...... ")
	
	periodStr := SafeParams(r, "period")
	if len(periodStr) == 0 {
		log4go.Warn("GetPrevActivityResults(): period param is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )			
	}
	
	period, err := strconv.ParseInt(periodStr, 10, 64)
	if err != nil {
		log4go.Warn("GetPrevActivityResults(): period param is err! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	
	lastId := int64(-1)
	pageToken := SafeParams(r, "next_page_token")
	lastIdStr, _ := ParsePageTokenByString(pageToken)
	lastId, _ = strconv.ParseInt(lastIdStr, 10, 64)
	log4go.Debug("GetPrevActivityResults() pageToken:%s, lastId=%d ", pageToken, lastId)
		
	// 此期夺宝信息	
	duobao, err := o.GetDuobaoInfoByPeriodDb(period)
	if err != nil || duobao == nil  {
		log4go.Warn("GetPrevActivityResults(): GetDuobaoInfoByPeriodDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	// 往期揭晓夺宝
	var retPreRecords []PreDuobaoRecord
	oldDuobaoList, err := o.GetDuobaoListByGoodsIdDb(duobao.GoodsId, DUOBAO_STATUS_PUBLISHED, lastId, DUOBAO_RECORD_PAGE_SIZE)
	var uidList []int64 // 往期夺宝中奖用户id列表
	for _, old := range oldDuobaoList {
		uidList = append(uidList, old.LuckyGuy) 
	} 
	usrInfos, _ := o.GetUsrInfoByIdList(uidList)
	mapId2User := make(map[int64]UserInfoDb)
	for _, usrInfo := range usrInfos {
		mapId2User[usrInfo.UserId] = usrInfo
	}
	
	for _, oldDuobao := range oldDuobaoList {
		joinTotal, _, _ :=o.GetAllBuyCodeFromPeroidDb(oldDuobao.LuckyGuy, oldDuobao.Period)
		log4go.Debug("joinTotal: %d", joinTotal)
		PubTm := time.Unix(oldDuobao.PublishAt, 0)	
		PubTimeStr := PubTm.Format("2006-01-02 15:04:05")
		item := PreDuobaoRecord {
				Period: oldDuobao.Period,
				PublishTm: PubTimeStr,
				Total: joinTotal, // 中奖用户本次参与x人次 
				LuckyCode: oldDuobao.LuckyNo,				
				//JoinTime: int64(0), // 待填充 (界面暂未用)
				Owner: OwnerInfo{ 
					UserId: oldDuobao.LuckyGuy+DUOBAO_USER_ID_BASE, 
					Nickname: mapId2User[oldDuobao.LuckyGuy].Nickname,
					Gender: mapId2User[oldDuobao.LuckyGuy].Gender,
					AvatarPath: mapId2User[oldDuobao.LuckyGuy].Avatar,
					City: mapId2User[oldDuobao.LuckyGuy].City,
					LastIP: mapId2User[oldDuobao.LuckyGuy].LastIP,
				},					
		}
		retPreRecords = append(retPreRecords, item)
	}
	
	retPageToken := ""
	if len(oldDuobaoList) > 0 && len(oldDuobaoList) == DUOBAO_RECORD_PAGE_SIZE {
		lastPeriodId := oldDuobaoList[len(oldDuobaoList) - 1].Period
		lastPeriodIdStr := fmt.Sprintf("%d", lastPeriodId)
		retPageToken = GenPageTokenByString(lastPeriodIdStr, true)
	}	
	log4go.Debug("GetPrevActivityResults() retPageToken:%s ", retPageToken)	

	return formatJson(ResponseInfo { Code: RET_OK, Msg: MSG_OK, Data: PreDuobaoRecords{ Items: retPreRecords, NextPageToken: retPageToken} })	
}

// 获取计算详情
func (o *APIHandler) GetCalcResults(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetCalcResults() ...... ")
	
	periodStr := SafeParams(r, "period")
	if len(periodStr) == 0 {
		log4go.Warn("GetCalcResults(): period param is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )			
	}
	
	period, err := strconv.ParseInt(periodStr, 10, 64)
	if err != nil {
		log4go.Warn("GetCalcResults(): period param is err! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	log4go.Debug("GetCalcResults() period=%d ", period)
		
	// 此期夺宝信息	
	duobao, err := o.GetDuobaoInfoByPeriodDb(period)
	if err != nil || duobao == nil  {
		log4go.Warn("GetCalcResults(): GetDuobaoInfoByPeriodDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	

	// 已揭晓，显示全站最新N个夺宝参加记录	
	joinList := make([]DuobaoResultRecord, 0, 0)
	latestNRecords, _ := o.GetLatestJoinedByPeriodDB(period) // 该期最近50条全站夺宝记录
		
	// 得到这些商品名
	/*var goodsIdList []int64
	for _, re := range latestNRecords {
		goodsIdList = append(goodsIdList, re.GoodsId)
	}
	goodsList, _ := o.GetGoodsInfoByIdsDb(goodsIdList)
	mapId2Goods := make(map[int64]GoodsInfoDb)
	for _, goods := range goodsList {
		mapId2Goods[goods.GoodsId] = goods
	}*/
	sumValue := int64(0)
	for _, record := range latestNRecords {
		timeStr	:= transUnixTime2MilDateString(record.CreatedAt)
		timeVal := transUnixTime2CalcValue(record.CreatedAt)	
		item := DuobaoResultRecord {
					UserId: record.UserId+DUOBAO_USER_ID_BASE,
					Time: timeStr,
					TimeValue: timeVal,
					Nickname: record.NickName,
				 }
		joinList = append(joinList, item)
		value, _ := strconv.ParseInt(timeVal, 10, 64)
		sumValue = sumValue + value
	}	
	
	sscInfo, _ := o.GetSscInfoByPeriodDb(duobao.SscPeriodNo)
	valueB := int64(88888)
	if sscInfo != nil {
		valueB, _ = strconv.ParseInt(sscInfo.OpenCode, 10, 64) 
	}
	
	retInfo := DuobaoResultRecords {
					Status: duobao.Status,
					ValueA: sumValue,
					ValueB: valueB, 				//老时时彩揭晓号码 
					SscPeriod: duobao.SscPeriodNo,	    //老时时彩揭晓期号 
					LuckyCode: duobao.LuckyNo,
					List: joinList,
	}
	type CalcResultInfo struct {
		CalcInfo DuobaoResultRecords  `json:"calc_result"`
	}
	retCalcResult := CalcResultInfo{ CalcInfo: retInfo, }

	return formatJson(ResponseInfo { Code: RET_OK, Msg: MSG_OK, Data: retCalcResult })		
}

// 获取最新该商品的夺宝期号
func (o *APIHandler) GetLatestDuobaoPeriod(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetLatestDuobaoPeriod() ...... ")
	
	goodsIdStr := SafeParams(r, "goods_id")
	if len(goodsIdStr) == 0 {
		log4go.Warn("GetLatestDuobaoPeriod(): goods_id param is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )			
	}
	
	goodsId, err := strconv.ParseInt(goodsIdStr, 10, 64)
	if err != nil {
		log4go.Warn("GetLatestDuobaoPeriod(): goods_id param is err! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	
	newPeriod := int64(0)
	newDuobao, _ := o.GetLatestDuobaoByGoodsIdDb(goodsId)
	if newDuobao != nil {
		newPeriod = newDuobao.Period
	}
	
	type LatestPeriod struct {
		Period  int64  `json:"period"`
	}	

	dataResp := LatestPeriod{Period: newPeriod,}
		
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = dataResp
	return formatJson(result)		
	
}


// 查询下一页夺宝参与记录
func (o *APIHandler) NextJoinedRecords(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("NextJoinedRecords() ...... ")
	
	pageToken := SafeParams(r, "next_page_token")
	if len(pageToken) == 0 {
		log4go.Error("NextJoinedRecords(): 'next_page_token' param is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	lastId, _ := ParsePageTokenByString(pageToken)
	if lastId == "" {
		log4go.Error("NextJoinedRecords(): 'next_page_token' param is invalid: %s", pageToken)
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )							
	}

	periodStr := SafeParams(r, "period")
	if len(periodStr) == 0 {
		log4go.Warn("NextJoinedRecords(): period param is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )			
	}
	period, err := strconv.ParseInt(periodStr, 10, 64)
	if err != nil {
		log4go.Warn("NextJoinedRecords(): period param is err! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
		
	// 一页夺宝信息	
	duobao, err := o.GetOnePageUserDuobaoRecords(period, lastId, DUOBAO_RECORD_PAGE_SIZE)
	if err != nil  {
		log4go.Warn("GetCalcResults(): GetDuobaoInfoByPeriodDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	

	retPageToken := ""
	if len(duobao) > 0 && len(duobao) == DUOBAO_RECORD_PAGE_SIZE {
		lastOrderNo := duobao[len(duobao) - 1].OrderNo
		retPageToken = GenPageTokenByString(lastOrderNo, true)
	}
	log4go.Debug("GetCalcResults() retPageToken:%s ", retPageToken)

	var retRecords []DuobaoRecord
	for _, record := range duobao {
		item := DuobaoRecord {
					Time: transUnixTime2MilDateString(record.CreatedAt), 
					Total: record.BuyTotal, 
					Owner: OwnerInfo { 
						UserId: record.UserId+DUOBAO_USER_ID_BASE, 
						Nickname: record.NickName,
						AvatarPath: record.AvatarPath, 
						LastIP: record.LastIp,
						City: record.City,
					},
				 }
		retRecords = append(retRecords, item)
	}

	return formatJson(ResponseInfo { Code: RET_OK, Msg: MSG_OK, Data: OnePageDuobaoRecords{ Items: retRecords, NextPageToken: retPageToken } })		
}

// 最新揭晓
func (o *APIHandler) GetNewlyPublish(r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {	
	log4go.Debug("GetNewlyPublish() ...... ")
	
	pageToken := SafeParams(r, "next_page_token")
	if len(pageToken) == 0 {
		log4go.Error("NextJoinedRecords(): 'next_page_token' param is empty!")
		//return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	lastTimeStr, _ := ParsePageTokenByString(pageToken)
	lastTime, _ := strconv.ParseInt(lastTimeStr, 10, 64)
	log4go.Debug("GetNewlyPublish() lastTimeStr: %s, lastTime:%d", lastTimeStr, lastTime)
	if lastTime == 0 {
		log4go.Error("NextJoinedRecords(): 'next_page_token' param is invalid: %s", pageToken)
		//return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )							
	}	
	
	// 揭晓夺宝列表
	duobaoList, err := o.GetOnePageNewlyPublishListDb(lastTime, DUOBAO_RECORD_PAGE_SIZE)
	if err != nil {
		log4go.Error("GetNewlyPublish() GetIndexDuobaoListDb query db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), err
	}	
	log4go.Debug("GetNewlyPublish() len(duobaoList): %d", len(duobaoList))
	
	retPageToken := ""
	if len(duobaoList) > 0 && len(duobaoList) == DUOBAO_RECORD_PAGE_SIZE {
		lastTimeStamp := duobaoList[len(duobaoList) - 1].PublishAt
		lastStamp := fmt.Sprintf("%d", lastTimeStamp)
		retPageToken = GenPageTokenByString(lastStamp, true)
	} 
	log4go.Debug("GetNewlyPublish() retPageToken: %s ", retPageToken)
	
	mapId2Goods := make(map[int64]GoodsInfoDb)
	mapId2User := make(map[int64]UserInfoDb)
	mapId2JoinInfo := make(map[int64]JoinedRecord)
	var periodIds []int64
	if len(duobaoList) > 0 {
		var ids []int64
		var Uids []int64
		for _, duobao := range duobaoList {
			// 商品id
			ids = append(ids, duobao.GoodsId)
			// 用户id
			if duobao.LuckyGuy > 0 {
				Uids = append(Uids, duobao.LuckyGuy)
			}
			// 期号ids
			periodIds = append(periodIds, duobao.Period)			
		}
		// 商品信息
		goodsList, _:= o.GetGoodsInfoByIdsDb(ids)
		for _, good := range goodsList {
			mapId2Goods[good.GoodsId] = good
		}
		// 用户信息
		userInfos, _ := o.GetUsrInfoByIdList(Uids)	
		if userInfos != nil {
			for _, user := range userInfos {
				mapId2User[user.UserId] = user
			}	
		}	
		// 中奖人信息
		luckys, _ := o.GetLuckyInfoByPeriodListDb(periodIds)
		for _, lucky := range luckys {
			mapId2JoinInfo[lucky.Period] = lucky
		}						
	}
	
	nowUnix := time.Now().Unix()
	var GoodsResp []GoodsSummaryResp
	for _, duobao := range duobaoList {
		counDownSec := int64(0)
		if duobao.Status == 2 { // 正在揭晓
			counDownSec = duobao.PublishAt-nowUnix
		} 
		item := GoodsSummaryResp{ 
								Status: duobao.Status,
								Period:	duobao.Period,
								PublishTime: transUnixTime2DateString(duobao.PublishAt),
								PubCountDown: counDownSec,
								GoodsId: duobao.GoodsId,
								GoodsName: duobao.Title,
								GoodsDesc: mapId2Goods[duobao.GoodsId].Description,
								BuyUnit: duobao.BuyUnit,
								TotalTimes: duobao.NeedTotal,
								RemainingTimes: duobao.RemainNum,
								LuckyCode: duobao.LuckyNo,
								LuckyUser: mapId2User[duobao.LuckyGuy].Nickname, 
								LuckyUid: duobao.LuckyGuy+DUOBAO_USER_ID_BASE,
								LuckyBuyTotal: mapId2JoinInfo[duobao.Period].BuyTotal,
								CoverImage: mapId2Goods[duobao.GoodsId].ImageUrl,
								ShowTag: duobao.ShowTag,
							} 
		if duobao.Status == 2 {
			nowUnix := time.Now().Unix()
			item.PubCountDown = duobao.PublishAt - nowUnix
		}						
		GoodsResp = append(GoodsResp, item)
	}	
	
	type NewlyPubInfo struct {
		PageToken string `json:"next_page_token"`
		List  []GoodsSummaryResp   `json:"list"`			
	}	
	
	retFinalData := NewlyPubInfo{ List: GoodsResp, PageToken: retPageToken,}
	 
	var result ResponseInfo

	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retFinalData
	return formatJson(result),nil
}

// 查看清单
func (o *APIHandler) GetCartList(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetCartList() ...... ")

	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("GetCartList(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}
	
	cartInfoList, err := o.GetCartListDb(meUid)
	if err != nil {
		log4go.Error("GetCartList() GetCartListDb query db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )		
	}

	var retCartInfo []CartListRespInfo
	for _, cartInfoDb := range cartInfoList {
		item := CartListRespInfo {
			Status: cartInfoDb.Status,
			Period: cartInfoDb.Period,
			PublishTime: int64(0), // 待填充
			GoodsId: cartInfoDb.GoodsId,
			GoodsName: cartInfoDb.Title,
			TotalTimes: cartInfoDb.NeedTotal,
			RemainingTimes: cartInfoDb.RemainNum,
			BuyUnit: cartInfoDb.BuyUnit,
			BuyTotal: cartInfoDb.BuyTotal,
			Thumbnails: cartInfoDb.ImageUrl,
			ShowTag: "", //待填充
		}	
		retCartInfo = append(retCartInfo, item)
	}
	
	type finalCartListInfo struct {
		TotalNum int   `json:"total_num"`
		List []CartListRespInfo  `json:"list"`			
	}
	
	finalRetData := finalCartListInfo {
		TotalNum: len(cartInfoList),
		List: retCartInfo,
	}
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = finalRetData
	return formatJson(result)
}

// 添加到清单
func (o *APIHandler) Add2Cart(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("Add2Cart() ...... ")

	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("Add2Cart(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}
		
	periodStr := SafeParamsFromPost(r, "period")
	if periodStr == "" {
		log4go.Error("Add2Cart(): 'period' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	periodId, _ := strconv.ParseInt(periodStr, 10, 64)
	if periodId <= 0 {
		log4go.Error("Add2Cart(): invalid 'periodId': [%s]", periodStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	
	BuyTotalStr := SafeParamsFromPost(r, "buy_total")
	if BuyTotalStr == "" {
		log4go.Error("Add2Cart(): 'buy_total' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	BuyTotal, _ := strconv.ParseInt(BuyTotalStr, 10, 64)
	if BuyTotal <= 0 {
		log4go.Error("Add2Cart(): invalid 'buy_total': [%s]", BuyTotalStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}		
	
	succ, err := o.InsertCartDb(meUid, periodId, BuyTotal)
	if err != nil {
		log4go.Error("Add2Cart() InsertCartDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )		
	}	
	if succ == 0 { // 已存在
		log4go.Error("Add2Cart() InsertCartDb db Exist!")
		return formatJson( ResponseInfo{ Code: RET_RECORD_EXISTS, Msg: MSG_RECORD_EXISTS } )		
	}	
	
	// 返回清单列表
	return o.GetCartList(r, headers, sequence)
}

// 从清单中删除
func (o *APIHandler) DelFromCart(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("DelFromCart() ...... ")

	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("DelFromCart(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}
		
	periodList := SafeParamsFromPost(r, "period_list")
	if periodList == "" {
		log4go.Error("DelFromCart(): 'periodList' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	
	_, err := o.DeleteFromCartDb(meUid, periodList)
	if err != nil {
		log4go.Error("DelFromCart() DeleteFromCartDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )		
	}	
	// 返回清单列表
	return o.GetCartList(r, headers, sequence)
}

// 某期下单分到的所有号码
func (o *APIHandler) GetAllBuyCodeFromPeroid(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetAllBuyCodeFromPeroid() ...... ")
	
	userIdStr := SafeParams(r, "user_id")
	if userIdStr == "" {
		log4go.Error("GetAllBuyCodeFromPeroid(): 'user_id' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	userId, _ := strconv.ParseInt(userIdStr, 10, 64)
	if userId <= 0 {
		log4go.Error("GetAllBuyCodeFromPeroid(): invalid 'userId': [%s]", userIdStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}	
	userId = userId - DUOBAO_USER_ID_BASE

	periodIdStr := SafeParams(r, "period")
	if periodIdStr == "" {
		log4go.Error("GetAllBuyCodeFromPeroid(): 'period' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	periodId, _ := strconv.ParseInt(periodIdStr, 10, 64)
	if periodId <= 0 {
		log4go.Error("GetAllBuyCodeFromPeroid(): invalid 'periodId': [%s]", periodIdStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	
	totalNum, codeList, err := o.GetAllBuyCodeFromPeroidDb(userId, periodId)
	if err != nil {
		log4go.Error("GetAllBuyCodeFromPeroid(): GetAllBuyCodeFromPeroidDb err:%s", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )					
	}	
	log4go.Debug("GetAllBuyCodeFromPeroid() totalNum: %d ", totalNum)
	
	// 此期夺宝信息	
	duobao, err := o.GetDuobaoInfoByPeriodDb(periodId)
	if err != nil || duobao == nil  {
		log4go.Warn("GetAllBuyCodeFromPeroid(): GetDuobaoInfoByPeriodDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	type JoinInfoSt struct {
		TotalNum int  			`json:"code_total"` 		// 本期共参与X人次
		LuckyCode string 		`json:"lucky_code"` 		// 幸运号码
		Codes 	[]OwnerAllCode  `json:"owner_all_code"`
	}	
	
	retJoinInfo := JoinInfoSt{TotalNum: totalNum, LuckyCode: duobao.LuckyNo, Codes: codeList,}
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retJoinInfo
	return formatJson(result)
}

func decodeOrderParams(r *http.Request) (*UploadOrderReq, error){
	bodyBytes, err := ioutil.ReadAll(r.Body)
	if err != nil {
		log4go.Error("decodeOrderParams(): read body error [ %s ]", err)
		return nil, err		
	}
	log4go.Debug("Order(): post body is '%s'.", string(bodyBytes))
	decoder := json.NewDecoder(bytes.NewReader(bodyBytes))

	var req UploadOrderReq
	err = decoder.Decode(&req)
	if err != nil {
		log4go.Error("decodeOrderParams() error [ %s ]", err)
		return nil, err
	}
	return &req, nil
}

func checkUploadOrderParams(req *UploadOrderReq, headers *CommonHeaders) string {
	if req == nil {
		return ""
	}
	
	if len(req.Channel) == 0 {
		log4go.Warn("checkUploadOrderParams(): 'charge_channel' is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )					
	}	

	if req.Channel == "wx_pub" && len(req.OpenId) == 0 {
		log4go.Warn("checkUploadOrderParams(): weixin charge requir 'open_id' param!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )					
	}

	if len(req.Signed) == 0 {
		log4go.Warn("checkUploadOrderParams(): 'Signed' is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )					
	}
	content := fmt.Sprintf("%d-%s-%s", req.AmountTotal, req.Channel, DUOBAO_SECRET_KEY)
	calcSig, matched := CheckSignature(content, headers.UserToken, req.Signed)
	if !matched {
		log4go.Error("UserGetPromoCode(): signature check failed, serverSig=[ %s ]， clientSig=[ %s ]", calcSig, req.Signed)
		return formatJson( ResponseInfo{ Code: RET_SIG_CHECK_FAILED, Msg: MSG_SIG_CHECK_FAILED } )
	}	
	return ""
}

// 结算
func (o *APIHandler) Settlement(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("Settlement() ...... ")
	
	// 检查上传信息
	reqs, err := decodeOrderParams(r);
	if err != nil {
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	retStr := checkUploadOrderParams(reqs, headers)
	if len(retStr) > 0 {
		//return retStr // 调试暂不验证
	}

	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("Settlement(): user not login!")
		//return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}	
	
	// 用户信息	 
	useInfo, err := o.GetUsrInfoById(meUid)
	if err != nil {
		log4go.Error("Settlement() GetUsrInfoById db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
		
	var periodIds []int64
	for _, ord := range reqs.List {
		periodIds = append(periodIds, ord.Period)
	}
	
	duobaos, err := o.GetDuobaoInfoByPeriodListDb(periodIds)
	if err != nil {
		log4go.Warn("Settlement(): GetDuobaoInfoByPeriodListDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	mapPeriod2Duobao := make(map[int64]DuobaoInfoDb, len(duobaos))
	for _, duobao := range duobaos {
		mapPeriod2Duobao[duobao.Period] = duobao
	}
	
	// 先看是下单的商品剩余人次否还够，不够返回结算失败
	retStr = o.CheckOrderValid(*reqs, mapPeriod2Duobao)
	if len(retStr) > 0 {
		log4go.Error("Order(): remaining times NOT enough!")
		return formatJson( ResponseInfo{ Code: RET_BUY_OVER_LIMIT, Msg: retStr+MSG_BUY_OVER_LIMIT } )
	}
	
	var retOrderInfos UploadOrderReq
	amountTotal := 0
	// 
	for _, order := range reqs.List {
		item := SingleOrder{
			Period: order.Period,
			GoodsId: mapPeriod2Duobao[order.Period].GoodsId,
			GoodsName: mapPeriod2Duobao[order.Period].Title,
			BuyUnit: mapPeriod2Duobao[order.Period].BuyUnit,
			BuyTotal: order.BuyTotal,
			SubTotal: order.BuyTotal,			 
		} 
		amountTotal = amountTotal + order.BuyTotal
		retOrderInfos.List = append(retOrderInfos.List, item)
	}
	retOrderInfos.AmountTotal = amountTotal
	
	deductGold := 0 // 需抵扣的金币
	userGold := int(useInfo.Gold / 100)
	if userGold > 0 {
		if amountTotal >= userGold {
			deductGold = userGold  	// 金币少于买入额，扣完
		} else {
			deductGold = amountTotal // 金币多于买入额，最多扣买入金额
		}
	}
	retOrderInfos.Gold = deductGold
	retOrderInfos.Amount = amountTotal - retOrderInfos.Gold  // 实付金额
	retOrderInfos.SumTotal = amountTotal // 总人次
			
	type RetOrderRespInfo struct {
		OrderInfo UploadOrderReq `json:"order_info"`
	}
	
	respInfo := RetOrderRespInfo{OrderInfo: retOrderInfos}
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = respInfo
	return formatJson(result)
}

// 点支付
func (o *APIHandler) Order(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("Order() ............................... ")
	
	// 检查上传信息
	reqs, err := decodeOrderParams(r);
	if err != nil {
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	retStr := checkUploadOrderParams(reqs, headers)
	if len(retStr) > 0 {
		return retStr // 调试暂不验证
	}

	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("Order(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}	

	var periodIds []int64
	for _, ord := range reqs.List {
		periodIds = append(periodIds, ord.Period)
	}
	
	duobaos, err := o.GetDuobaoInfoByPeriodListDb(periodIds)
	if err != nil {
		log4go.Warn("Order(): GetDuobaoInfoByPeriodListDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
		
	mapPeriod2Duobao := make(map[int64]DuobaoInfoDb, len(duobaos))
	for _, duobao := range duobaos {
		mapPeriod2Duobao[duobao.Period] = duobao
	}	
	
	// 先看是下单的商品剩余人次否还够，不够返回下单失败
	retStr = o.CheckOrderValid(*reqs, mapPeriod2Duobao)
	if len(retStr) > 0 {
		log4go.Error("Order(): remaining times NOT enough!")
		return formatJson( ResponseInfo{ Code: RET_BUY_OVER_LIMIT, Msg: retStr+MSG_BUY_OVER_LIMIT } )
	}	
	
	// 如果金币完全抵扣了金额,不走支付，直接购买成功
	if reqs.Amount==0 && reqs.Gold>0 {
		
		log4go.Warn("Order(): OrderCompleteWithoutPay ###############")
		mainOrderNo, err := o.OrderCompleteWithoutPay(*reqs, meUid, mapPeriod2Duobao)
		if err != nil {
			log4go.Error("Order() OrderCompleteWithoutPay ERROR! error:%s", err)
			return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
		}	
		log4go.Debug("Order(): OrderCompleteWithoutPay mainOrderNo:%s", mainOrderNo)
		respInfo := RetChargeRespInfo{IsNeedPay: 0, OrderNo: mainOrderNo, }	
		var result ResponseInfo
		result.Code = RET_OK
		result.Msg = MSG_OK
		result.Data = respInfo
		return formatJson(result)	
	}
	
	// 下单信息填入数据库	 
	resp, err := o.InsertOrderDb(*reqs, meUid)
	if err != nil || resp==nil {
		log4go.Error("Order() InsertOrderDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )	
	}	
	
	// 去支付	
	chargeInfo, err := o.Charges(meUid, resp.MainOrderNo, reqs, resp.mapSubOrder)
	if err != nil || chargeInfo == nil {
		log4go.Error("Order() Charges ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	respInfo := RetChargeRespInfo{IsNeedPay: 1, ChargeObj: chargeInfo}
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = respInfo
	return formatJson(result)
}

// auto buy
func (o *APIHandler) AutoOrder(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("AutoOrder() ...... ")

	UserIdStr := SafeParams(r, "user_id")
	if UserIdStr == "" {
		log4go.Error("AutoOrder(): 'user_id' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	userId, err := strconv.ParseInt(UserIdStr, 10, 64)
	if userId <= 0 {
		log4go.Error("AutoOrder(): invalid 'user_id': [%s]", UserIdStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}	
	
	periodIdStr := SafeParams(r, "period")
	if periodIdStr == "" {
		log4go.Error("AutoOrder(): 'period' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	periodId, _ := strconv.ParseInt(periodIdStr, 10, 64)
	if periodId <= 0 {
		log4go.Error("AutoOrder(): invalid 'period': [%s]", periodIdStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}

	buyTotalStr := SafeParams(r, "buy_total")
	if buyTotalStr == "" {
		log4go.Error("AutoOrder(): 'buy_total' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	buyTotal, _ := strconv.ParseInt(buyTotalStr, 10, 64)
	if buyTotal <= 0 {
		log4go.Error("AutoOrder(): invalid 'buy_total': [%s]", buyTotalStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	
	signature := SafeParams(r, "signature")
	if signature == "" {
		log4go.Error("AutoOrder(): 'signature' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	
	//calcSig, matched := CheckSignature(periodIdStr, headers.UserToken, signature)
	sourceStr := fmt.Sprintf("[%d:%d:%d:3a672de5]", userId, periodId, buyTotal)
	calcSignature := fmt.Sprintf("%x", md5.Sum([]byte(sourceStr)))
	log4go.Debug("CheckSignature() signature:%s, calcSignature=%s", signature, calcSignature)
	if signature != calcSignature {
		log4go.Error("AutoOrder(): signature check failed, serverSig=[ %s ]， clientSig=[ %s ]", calcSignature, signature)
		return formatJson( ResponseInfo{ Code: RET_SIG_CHECK_FAILED, Msg: MSG_SIG_CHECK_FAILED } )
	}	
	
	// 夺宝信息
	duobao, err := o.GetDuobaoInfoByPeriodDb(periodId)
	if err != nil {
		log4go.Warn("AutoOrder(): GetDuobaoInfoByPeriodListDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	
	// 先看是下单的商品剩余人次否还够，不够返回下单失败
	if buyTotal > int64(duobao.RemainNum)  {
		log4go.Error("AutoOrder(): remaining times NOT enough!")
		return formatJson( ResponseInfo{ Code: RET_BUY_OVER_LIMIT, Msg: MSG_BUY_OVER_LIMIT } )
	}
	
	subOrder := SingleOrder {
		Period: periodId, 
		GoodsId: duobao.GoodsId,
		GoodsName: duobao.Title,
		BuyUnit: duobao.BuyUnit,
		BuyTotal: int(buyTotal),
		SubTotal: int(buyTotal),	
	}
	var orderList []SingleOrder
	orderList = append(orderList, subOrder)
	
	req := UploadOrderReq{
		Amount: int(buyTotal),
		Gold: 0,
		List: orderList,		
	}
	
	// 下单信息填入数据库	 
	resp, err := o.InsertOrderDb(req, userId)
	if err != nil || resp==nil {
		log4go.Error("AutoOrder() InsertOrderDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )	
	}		
	
	// 设置订单支付状态
	err = o.SetOrderPayedDb(resp.MainOrderNo)
	if err != nil {
		log4go.Error("AutoOrder() SetOrderPayedDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )	
	}
	
	subOrderNo := resp.mapSubOrder[periodId]
	log4go.Debug("AutoOrder() subOrderNo: %s", subOrderNo)
	map2SubOrders := make(map[string]ChargeSubOrder) // key 是子订单号
	chargeSubOrder := ChargeSubOrder{
		UserId: userId,
		OrderNo: subOrderNo,
		Period: periodId,
		GoodsId: duobao.GoodsId, 
		BuyUnit: duobao.BuyUnit,
		BuyTotal: int(buyTotal),
		SubTotal: int(buyTotal),
	}
	map2SubOrders[subOrderNo] = chargeSubOrder
		
	bFinish, failOrderList, err := o.FillCode2OrderDetailDb(map2SubOrders)
	log4go.Debug("AutoOrder() bFinish: %d, len(fail):%d", bFinish, len(failOrderList))
	if err != nil {
		log4go.Debug("AutoOrder() FillCode2OrderDetailDb err:%s", err)
	}	

	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = chargeSubOrder
	return formatJson(result)
}

// 返回支付通知
func (o *APIHandler) NotifyPayment(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("NotifyPayment() ...... ")

	orderNo := SafeParams(r, "order_no")
	if orderNo == "" {
		log4go.Error("NotifyPayment(): 'order_no' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	
	nextTimeStr := SafeParams(r, "next_time")
	log4go.Debug("NotifyPayment() nextTime:%s ", nextTimeStr)		
	nextTime, err := strconv.ParseInt(nextTimeStr, 10, 32)
	if len(nextTimeStr)==0 || err != nil {
		nextTime = 0
	}

	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("NotifyPayment(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}
	
	mainOrder, err := o.GetMainOrderInfoDb(orderNo)
	if err != nil {
		log4go.Error("NotifyPayment() GetChargeRespSubOrderInfoDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )	
	}
	 
	// 还未支付成功 延迟nextTime秒后再来访问
	if mainOrder.Status == 0 {
		if nextTime == 0 {
			nextTime = 1000
		} else {
			nextTime = nextTime*2
			if nextTime >= 8000 { // 超过8秒，不重新访问了
				nextTime = 0
			}
		}	
	} else {
		nextTime = 0;
	}
	
	total, subOrders, err := o.GetChargeRespSubOrderInfoDb(orderNo)
	if err != nil {
		log4go.Error("NotifyPayment() GetChargeRespSubOrderInfoDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )	
	}
	goodsNum := len(subOrders)
	retInfo := ChargeSuccResp {
		UserId: meUid + DUOBAO_USER_ID_BASE,
		GoodNum: goodsNum,
		SumTotal: total,
		NextAccessTm: int(nextTime),
		SubList: subOrders,
	}
		
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retInfo
	
	log4go.Debug("NotifyPayment() ret = %s ", formatJson(result))
	return formatJson(result)
}

// 点支付测试
func (o *APIHandler) ChargesTest(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("ChargesTest() ...... ")
	
	// 去支付	
	chargeInfo, err := o.Charges(1, "", nil, nil)
	if err != nil {
		log4go.Error("Order() Charges ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	type RetChargeRespInfo struct {
		ChargeObj *ChargeInfo `json:"charge_obj"`
	}
	
	respInfo := RetChargeRespInfo{ChargeObj: chargeInfo}
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = respInfo
	return formatJson(result)
}

func (o *APIHandler) ChargesTestSuccessUrl(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("ChargesTestSuccessUrl() ...... ")

	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result)
}

func (o *APIHandler) ChargesTestCancelUrl(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("ChargesTestCancelUrl() ...... ")

	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result)
}

func (o *APIHandler) TestInitDuobaoCodePool(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("TestInitDuobaoCodePool() ...... ")

	periodIdStr := SafeParams(r, "period")
	if periodIdStr == "" {
		log4go.Error("TestInitDuobaoCodePool(): 'period' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	periodId, _ := strconv.ParseInt(periodIdStr, 10, 64)
	if periodId <= 0 {
		log4go.Error("TestInitDuobaoCodePool(): invalid 'periodId': [%s]", periodIdStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}

	needTotalStr := SafeParams(r, "need_total")
	if needTotalStr == "" {
		log4go.Error("TestInitDuobaoCodePool(): 'need_total' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	needTotal, _ := strconv.ParseInt(needTotalStr, 10, 64)
	if needTotal <= 0 {
		log4go.Error("TestInitDuobaoCodePool(): invalid 'need_total': [%s]", needTotalStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}

	o.InitOneDuobaoCodePoolDb(periodId, int(needTotal))
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result)
}


// 支付
func (o *APIHandler) Charges(userId int64, orderNo string, orderReq *UploadOrderReq, mapOrder map[int64]string) (*ChargeInfo, error) {	
	log4go.Debug("Charges() ...... ")

	mapMetaData := make(map[string]interface{})
	for _, order := range orderReq.List {
		subOrderNo := mapOrder[order.Period]
		item := ChargeSubOrder{
			UserId: userId,
			OrderNo: subOrderNo,
			Period: order.Period,
			GoodsId: order.GoodsId,
			BuyUnit: order.BuyUnit,
			BuyTotal: order.BuyTotal,
			SubTotal: order.SubTotal,	
		}
		mapMetaData[subOrderNo] = item // 订单号 -> 子订单信息
	}

	// 主要用于金币抵扣
	itemSum := ChargeSubOrder{
		UserId: userId,
		Gold: orderReq.Gold,	
	}
	mapMetaData["order_summary"]	= itemSum	
	log4go.Debug("Charges() len(mapMetaData) = %d ", len(mapMetaData))
	
	var param ChargeParams
	param.Amount = uint64(len(mapOrder))	// uint64(orderReq.Amount) * 100 // 以分为单位
	param.Channel = orderReq.Channel 		// "alipay_wap" | "wx_pub"
	param.Order_no = orderNo 
	param.Subject = "酷购吧夺宝订单"
	param.Body = fmt.Sprintf("参与%d个夺宝活动，总共%d人次", len(mapOrder), orderReq.Amount)
	param.Metadata = mapMetaData
	mapExtra := make(map[string]interface{})
	
	if param.Channel == "alipay_wap" {
		retURl := fmt.Sprintf("%s?t=order", DUOBAO_CHARGE_RET_PAGE)
		mapExtra["success_url"] = retURl
	} else if param.Channel == "wx_pub" {
		mapExtra["open_id"] = orderReq.OpenId
	}	
	param.Extra = mapExtra
		
	// 向ping++发送支付请求	
	charge, err := o.PostCharge(param)	
	if err != nil {
		log4go.Error("Charges() InsertOrderDb db ERROR!")
		return nil, err			
	}	
	
	// 往主订单表填入ping++的支付id
	if charge != nil {
		o.SetOrderPingOrderIdDb(orderNo, charge.ID)
	}	
	
	return charge, nil
}

// 全部参与(我的 夺宝记录 一页数据)
func (o *APIHandler) GetMyDuobaoRecords(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetMyDuobaoRecords() ...... ")
	
	userIdStr := SafeParams(r, "user_id")
	if userIdStr == "" {
		log4go.Error("GetMyDuobaoRecords(): 'user_id' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	userId, _ := strconv.ParseInt(userIdStr, 10, 64)
	if userId <= 0 {
		log4go.Error("GetMyDuobaoRecords(): invalid 'userId': [%s]", userIdStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}	
	userId = userId - DUOBAO_USER_ID_BASE
	
	lastId := int64(-1)
	pageToken := SafeParams(r, "next_page_token")
	log4go.Debug("GetMyDuobaoRecords() pageToken:%s ", pageToken)
	lastIdStr, _ := ParsePageTokenByString(pageToken)
	lastId, _ = strconv.ParseInt(lastIdStr, 10, 64)
	log4go.Debug("GetMyDuobaoRecords() lastIdStr:%s, lastId=%d ", lastIdStr, lastId)	
	
	// 参加记录	 
	joinedList, err := o.GetMyDuobaoRecordsDb(userId, lastId, DUOBAO_RECORD_PAGE_SIZE)
	if err != nil {
		log4go.Error("GetMyDuobaoRecords() GetMyDuobaoRecordsDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	
	retPageToken := ""
	if len(joinedList) > 0 && len(joinedList) == DUOBAO_RECORD_PAGE_SIZE {
		lastTimeStamp := joinedList[len(joinedList) - 1].CreatedAt
		lastStamp := fmt.Sprintf("%d", lastTimeStamp)
		retPageToken = GenPageTokenByString(lastStamp, true)	
	}		
	log4go.Debug("GetMyDuobaoRecords() retPageToken:%s ", retPageToken)
		
	var InfoList []MyJoinedResp
	isLucky := 0	
	for _, join := range joinedList {
		if userId==join.LuckyGuy{
			isLucky = 1
		}		
		
		var owner LuckyOwnerInfo
		luckJoined, _ := o.GetLuckyInfoByPeriodDb(join.Period)
		if luckJoined != nil {
			owner = LuckyOwnerInfo {
				UserId: luckJoined.UserId+DUOBAO_USER_ID_BASE,
				Nickname: luckJoined.NickName,
				BuyTotal: luckJoined.BuyTotal,
			}	
		}
		
		info :=  MyJoinedResp {
			Status: join.Status, 
			GoodsStatus: join.GoodsStatus,
			Period: join.Period, 	
			PublishTime: transUnixTime2DateString(join.PublishAt), 
			GoodsId: join.GoodsId, 
			GoodsName: join.Title, 
			TotalTimes: join.NeedTotal, 
			RemainingTimes: join.RemainNum, 
			BuyUnit: join.BuyUnit, 
			BuyTotal: join.BuyTotal,
			Thumbnails: join.ImageUrl, 
			ShowTag: join.ShowTag, 
			Time: transUnixTime2MilDateString(join.CreatedAt),
			IsBingo: isLucky, 
			LuckyOwner: 	owner,		
		}	
		InfoList = append(InfoList, info)			
	}
	
	type MyJoinedTotalResp struct {
		UserId   int64 `json:"uid"`
		Recordes []MyJoinedResp `json:"records"` 
		PageToken string `json:"next_page_token"` 
	}

	retRecrods := MyJoinedTotalResp { UserId: userId+DUOBAO_USER_ID_BASE, Recordes: InfoList, PageToken: retPageToken, }
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retRecrods
	return formatJson(result)
}

// 中奖记录(我的 一页数据)
func (o *APIHandler) GetMyLuckyRecords(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetMyLuckyRecords() ...... ")
	
	userIdStr := SafeParams(r, "user_id")
	if userIdStr == "" {
		log4go.Error("GetMyLuckyRecords(): 'user_id' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	userId, _ := strconv.ParseInt(userIdStr, 10, 64)
	if userId <= 0 {
		log4go.Error("GetMyLuckyRecords(): invalid 'userId': [%s]", userIdStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	userId = userId - DUOBAO_USER_ID_BASE	
	
	lastId := int64(-1)
	pageToken := SafeParams(r, "next_page_token")
	lastIdStr, _ := ParsePageTokenByString(pageToken)
	lastId, _ = strconv.ParseInt(lastIdStr, 10, 64)
	log4go.Debug("GetMyLuckyRecords() pageToken:%s, lastId=%d ", pageToken, lastId)	
	
	// 参加并中奖记录	 
	luckyList, err := o.GetMyAllLuckyRecordsDb(userId, lastId, DUOBAO_RECORD_PAGE_SIZE)
	if err != nil {
		log4go.Error("GetMyLuckyRecords() GetMyAllLuckyRecordsDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	
	retPageToken := ""
	if len(luckyList) > 0 && len(luckyList) == DUOBAO_RECORD_PAGE_SIZE {
		lastTimeStamp := luckyList[len(luckyList) - 1].CreatedAt
		lastStamp := fmt.Sprintf("%d", lastTimeStamp)
		retPageToken = GenPageTokenByString(lastStamp, true)
	}	
	log4go.Debug("GetMyLuckyRecords() retPageToken:%s ", retPageToken)
		
	var InfoList []MyJoinedResp	
	for _, join := range luckyList {
		info :=  MyJoinedResp {
			Status: join.Status,
			GoodsStatus: join.GoodsStatus, 
			Period: join.Period, 	
			LuckyCode: join.LuckyNo,
			PublishTime:  transUnixTime2DateString(join.PublishAt), 
			GoodsId: join.GoodsId, 
			GoodsName: join.Title, 
			TotalTimes: join.NeedTotal, 
			RemainingTimes: join.RemainNum, 
			BuyUnit: join.BuyUnit, 
			Thumbnails: join.ImageUrl, 
			ShowTag: join.ShowTag, 
			Time: transUnixTime2MilDateString(join.CreatedAt),
			BuyTotal: join.BuyTotal, 
		}	
		InfoList = append(InfoList, info)			
	}
	
	type MyJoinedTotalResp struct {
		Recordes []MyJoinedResp `json:"records"`
		PageToken string `json:"next_page_token"`  
	}

	retRecrods := MyJoinedTotalResp { Recordes: InfoList, PageToken: retPageToken, }
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retRecrods
	return formatJson(result)
}

// 个人资料查看(客态)
func (o *APIHandler) GetOtherUserProfile(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetOtherUserProfile() ...... ")
	
	userIdStr := SafeParams(r, "user_id")
	if userIdStr == "" {
		log4go.Error("GetOtherUserProfile(): 'user_id' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	userId, _ := strconv.ParseInt(userIdStr, 10, 64)
	if userId <= 0 {
		log4go.Error("GetOtherUserProfile(): invalid 'userId': [%s]", userIdStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
	userId = userId - DUOBAO_USER_ID_BASE	
	
	// 用户信息	 
	useInfo, err := o.GetUsrInfoById(userId)
	if err != nil {
		log4go.Error("GetUserProfile() GetUsrInfoById db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	
	// 夺宝记录
	lastId := int64(-1)
	joinedList, err := o.GetMyDuobaoRecordsDb(userId, lastId, DUOBAO_RECORD_PAGE_SIZE)
	if err != nil {
		log4go.Error("GetMyDuobaoRecords() GetMyDuobaoRecordsDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	
	retPageToken := ""
	if len(joinedList) > 0 && len(joinedList) == DUOBAO_RECORD_PAGE_SIZE {
		lastTimeStamp := joinedList[len(joinedList) - 1].CreatedAt
		lastStamp := fmt.Sprintf("%d", lastTimeStamp)
		retPageToken = GenPageTokenByString(lastStamp, true)
	}	
	log4go.Debug("GetMyDuobaoRecords() retPageToken:%s ", retPageToken)
		
	info := OwnerInfo {
		UserId: useInfo.UserId+DUOBAO_USER_ID_BASE, 
		Nickname: useInfo.Nickname,
		Gender: useInfo.Gender,
		AvatarPath: useInfo.Avatar,
		LastIP: useInfo.LastIP,
		AddrDefaultCode: useInfo.AddrDefaultCode,
		AddrDeliveryCode: useInfo.AddrDeliveryCode,
		PlatformName: useInfo.PlatformName,
	}	
	
	// 获奖者信息
	var periodList []int64
	for _, join := range joinedList {	
		periodList = append(periodList, join.Period)
	}
	
	mapPid2Info := make(map[int64]JoinedRecord)
	luckyInfosDb, _ := o.GetLuckyInfoByPeriodListDb(periodList)
	log4go.Debug("GetOtherUserProfile() len(luckyInfosDb)=%d", len(luckyInfosDb))
	for _, lucky := range luckyInfosDb {
		log4go.Debug("Period=%d, NickName=%s", lucky.Period, lucky.NickName)
		mapPid2Info[lucky.Period] = lucky
	}
		
	var InfoList []MyJoinedResp
	for _, join := range joinedList {	
	
		luckyInfoRet := LuckyOwnerInfo { 
								UserId:mapPid2Info[join.Period].UserId, 
								Nickname:mapPid2Info[join.Period].NickName, 
								BuyTotal:mapPid2Info[join.Period].BuyTotal, 
						}
							
		info :=  MyJoinedResp {
			Status: join.Status, 
			GoodsStatus: join.GoodsStatus,
			Period: join.Period, 
			PublishTime: transUnixTime2DateString(join.PublishAt), 
			GoodsId: join.GoodsId, 
			GoodsName: join.Title, 
			TotalTimes: join.NeedTotal, 
			RemainingTimes: join.RemainNum, 
			BuyUnit: join.BuyUnit, 
			Thumbnails: join.ImageUrl, 
			ShowTag: join.ShowTag, 
			Time: transUnixTime2MilDateString(join.CreatedAt), 
			BuyTotal: join.BuyTotal, 
			LuckyOwner: luckyInfoRet,
		}	
		InfoList = append(InfoList, info)			
	}	
	
	type UserInfoResp struct {
		Owner OwnerInfo `json:"owner"` 
		JoinedList []MyJoinedResp `json:"joined_records"`
		PageToken string `json:"next_page_token"`
	}

	retOwner := UserInfoResp { Owner: info, JoinedList: InfoList, PageToken: retPageToken, }
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retOwner
	return formatJson(result)
}


// 个人资料查看(主态)
func (o *APIHandler) GetUserProfile(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetUserProfile() ...... ")
	
	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("GetUserProfile(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}	
	
	// 用户信息	 
	useInfo, err := o.GetUsrInfoById(meUid)
	if err != nil {
		log4go.Error("GetUserProfile() GetUsrInfoById db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	// 是否有新消息
	bHasNewMsg := 0
	msgNum, err := o.GetUnReadedMessageNumDB(meUid)
	if msgNum > 0 {
		bHasNewMsg = 1
	}	
		
	info := OwnerInfo {
		UserId: useInfo.UserId+DUOBAO_USER_ID_BASE, 
		Nickname: useInfo.Nickname,
		Gender: useInfo.Gender,
		AvatarPath: useInfo.Avatar,
		LastIP: useInfo.LastIP,
		AddrDefaultCode: useInfo.AddrDefaultCode,
		AddrDeliveryCode: useInfo.AddrDeliveryCode,
		PlatformName: useInfo.PlatformName,
		HasNewMsg: bHasNewMsg,
	}	
	
	type UserInfoResp struct {
		Owner OwnerInfo `json:"owner"` 
	}

	retOwner := UserInfoResp { Owner: info, }
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retOwner
	return formatJson(result)
}


// 个人资料修改
func (o *APIHandler) ModifyUserProfile(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("ModifyUserProfile() ...... ")
	
	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("ModifyUserProfile(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}
	
	nickName := SafeParamsFromPost(r, "nick_name")
	if nickName == "" {
		log4go.Error("ModifyUserProfile(): 'nick_name' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	
	avatar := SafeParamsFromPost(r, "avatar") 
	if avatar == "" {
		log4go.Error("ModifyUserProfile(): 'avatar' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	
	signature := SafeParamsFromPost(r, "signature")
	if signature == "" {
		log4go.Error("ModifyUserProfile(): 'signature' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	
	calcSig, matched := CheckSignature(DUOBAO_SECRET_KEY, headers.UserToken, signature)
	if !matched {
		log4go.Error("ModifyUserProfile(): signature check failed, serverSig=[ %s ]， clientSig=[ %s ]", calcSig, signature)
		return formatJson( ResponseInfo{ Code: RET_SIG_CHECK_FAILED, Msg: MSG_SIG_CHECK_FAILED } )
	}			
	
	// 设置用户信息	 
	err := o.SetUsrInfoById(meUid, nickName, avatar)
	if err != nil {
		log4go.Error("ModifyUserProfile() SetUsrInfoById db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
		
	info := OwnerInfo {
		UserId: meUid, 
		Nickname: nickName,
		AvatarPath: avatar,
	}	
	
	type UserInfoResp struct {
		Owner OwnerInfo `json:"owner"` 
	}

	retOwner := UserInfoResp { Owner: info, }
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retOwner
	return formatJson(result)
}

// 收货地址查看
func (o *APIHandler) GetUserAddressList(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetUserAddressList() ...... ")
	
	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("ModifyUserProfile(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}
	
	// 用户信息	 
	addrInfos, err := o.GetUserAddrListDb(meUid)
	if err != nil {
		log4go.Error("GetUserAddressList() GetUserAddrListDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
		
	var infoList []UserAddrInfoResp	
	for _, addr := range addrInfos {
		info := UserAddrInfoResp {
			Code: addr.Code,
			Nickname: addr.Nickname, 
			Mobile: addr.Mobile,
			Address: addr.Address,
			IsDefault: addr.IsDefault,
		}
		infoList = append(infoList, info)			
	}
	
	type UserAddrListResp struct {
		List []UserAddrInfoResp `json:"list"` 
	}

	retInfo := UserAddrListResp { List: infoList, }
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retInfo
	return formatJson(result)
}

func decodeAddAddrParams(r *http.Request) (*UserAddrInfoResp, error){
	bodyBytes, err := ioutil.ReadAll(r.Body)
	if err != nil {
		log4go.Error("decodeAddAddrParams(): read body error [ %s ]", err)
		return nil, err		
	}
	log4go.Debug("decodeAddAddrParams(): post body is '%s'.", string(bodyBytes))
	decoder := json.NewDecoder(bytes.NewReader(bodyBytes))

	type UserAddAddrPost struct {
		AddrInfo UserAddrInfoResp `json:"addr_info"` 
	}

	var req UserAddAddrPost
	err = decoder.Decode(&req)
	if err != nil {
		log4go.Error("decodeAddAddrParams() error [ %s ]", err)
		return nil, err
	}
	return &req.AddrInfo, nil
}

// 新增收货地址
func (o *APIHandler) AddAddress(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("AddAddress() ...... ")
	
	// 检查上传信息
	req, err := decodeAddAddrParams(r);
	if err != nil {
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}

	if len(req.Signed) == 0 {
		log4go.Warn("AddAddress(): 'Signed' is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )					
	}
	calcSig, matched := CheckSignature(DUOBAO_SECRET_KEY, headers.UserToken, req.Signed)
	if !matched {
		log4go.Error("AddAddress(): signature check failed, serverSig=[ %s ]， clientSig=[ %s ]", calcSig, req.Signed)
		return formatJson( ResponseInfo{ Code: RET_SIG_CHECK_FAILED, Msg: MSG_SIG_CHECK_FAILED } )
	}

	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("AddAddress(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}	
	
	affeNum, err := o.InsertAddrDb(*req, meUid)
	if affeNum <= 0 || err != nil {
		log4go.Error("AddAddress() InsertAddrDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	
	return o.GetUserAddressList(r, headers, sequence)
}

// 删除收货地址
func (o *APIHandler) DelAddress(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("DelAddress() ...... ")
	
	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("DelAddress(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}
	
	addrCodeStr := SafeParamsFromPost(r, "code")
	if addrCodeStr == "" {
		log4go.Error("DelAddress(): 'code' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	
	addrCode, _ := strconv.ParseInt(addrCodeStr, 10, 64)
	if addrCode <= 0 {
		log4go.Error("DelAddress(): invalid 'addrCodeStr': [%s]", addrCodeStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}		
	
	signature := SafeParamsFromPost(r, "signature")
	if signature == "" {
		log4go.Error("DelAddress(): 'signature' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	
	calcSig, matched := CheckSignature(DUOBAO_SECRET_KEY, headers.UserToken, signature)
	if !matched {
		log4go.Error("DelAddress(): signature check failed, serverSig=[ %s ]， clientSig=[ %s ]", calcSig, signature)
		//return formatJson( ResponseInfo{ Code: RET_SIG_CHECK_FAILED, Msg: MSG_SIG_CHECK_FAILED } )
	}
	
	// 下单信息填入数据库	 
	err := o.DelAddrDb(addrCode, meUid)
	if err != nil {
		log4go.Error("DelAddress() DelAddrDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	
	return o.GetUserAddressList(r, headers, sequence)
}

// 修改收货地址
func (o *APIHandler) ModifyAddress(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("ModifyAddress() ...... ")
	
	// 检查上传信息
	req, err := decodeAddAddrParams(r);
	if err != nil {
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}

	if len(req.Signed) == 0 {
		log4go.Warn("ModifyAddress(): 'Signed' is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )					
	}
	calcSig, matched := CheckSignature(DUOBAO_SECRET_KEY, headers.UserToken, req.Signed)
	if !matched {
		log4go.Error("ModifyAddress(): signature check failed, serverSig=[ %s ]， clientSig=[ %s ]", calcSig, req.Signed)
		return formatJson( ResponseInfo{ Code: RET_SIG_CHECK_FAILED, Msg: MSG_SIG_CHECK_FAILED } )
	}

	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("ModifyAddress(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}	
	
	log4go.Debug("ModifyAddress() code=%d, user_id:%d, mobile:%s", req.Code, meUid, req.Mobile)
	
	err = o.ModifyAddrDb(*req, meUid)
	if err != nil {
		log4go.Error("ModifyAddress() ModifyAddrDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	
	return o.GetUserAddressList(r, headers, sequence)
}


func (o *APIHandler) GetUserGoldDetailRespInfo(goldRecords []GoldRecordDb) ([]GetGoldDetailResp, error) {
	
	log4go.Debug("GetUserGoldDetailRespInfo() ...... ")
	var slaveIds []int64
	for _, record := range goldRecords {
		if record.ParamId > 0 {
			slaveIds = append(slaveIds, record.ParamId)
		}
	}
	
	// 得到贡献者的信息
	slaveInfos, err := o.GetUsrInfoByIdList(slaveIds)
	if err != nil {
		log4go.Error("MyGoldDetail() GetUsrInfoByIdList db ERROR!")
		return nil, err		
	}	
	mapId2User := make(map[int64]UserInfoDb)
	for _, user := range slaveInfos {
		mapId2User[user.UserId] = user
	}	

	var detailList []GetGoldDetailResp
	var message string
	for _, record := range goldRecords {
		
		goldFloat := float32(record.Gold) / 100
		
		if record.OpType == "charge" {
			platformCn := ""
			platformName := mapId2User[record.ParamId].PlatformName
			if "qq" == platformName {
				platformCn = "QQ"
			} else if "wx" == platformName || "weixin" == platformName {
				platformCn = "微信"
			}
			message = fmt.Sprintf("恭喜您！%s用户%s通过您分享的链接成功参与了夺宝活动，奖励您%.2f夺宝币", 
				platformCn, mapId2User[record.ParamId].Nickname, goldFloat)
		} else {
			message = fmt.Sprintf("恭喜您！系统奖励您%.2f夺宝币", goldFloat)
		}
		
		detail := GetGoldDetailResp{
			Message: message,
			Time: transUnixTime2DateString(record.CreatedAt),
		}
		detailList = append(detailList, detail)
	}
	return detailList, err				
}

// 我的金币
func (o *APIHandler) MyGoldDetail(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("MyGoldDetail() ...... ")
	
	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("MyGoldDetail(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}	
	
	// 该用户信息
	userInfo, err := o.GetUsrInfoById(meUid)
	if err != nil {
		log4go.Error("MyGoldDetail() GetUsrInfoById db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}		
	
	// page token
	lastId := int64(-1)
	pageToken := SafeParams(r, "next_page_token")
	lastIdStr, _ := ParsePageTokenByString(pageToken)
	lastId, _ = strconv.ParseInt(lastIdStr, 10, 64)
	log4go.Debug("MyGoldDetail() pageToken:%s, lastId=%d ", pageToken, lastId)	
			
	// 该用户获取的金币记录		
	goldRecords, err := o.GetUserGetGoldDetailDB(meUid, lastId, DUOBAO_RECORD_PAGE_SIZE)
	if err != nil {
		log4go.Error("MyGoldDetail() ModifyAddrDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	retPageToken := ""
	if len(goldRecords) > 0 && len(goldRecords) == DUOBAO_RECORD_PAGE_SIZE {
		lastTimeStamp := goldRecords[len(goldRecords) - 1].CreatedAt
		lastStamp := fmt.Sprintf("%d", lastTimeStamp)
		retPageToken = GenPageTokenByString(lastStamp, true)
	}	
	log4go.Debug("MyGoldDetail() retPageToken:%s ", retPageToken)
	
	detailList, err := o.GetUserGoldDetailRespInfo(goldRecords)
	if err != nil {
		log4go.Error("MyGoldDetail() GetUserGoldDetailRespInfo db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
		
	var retMyGoldPage MyGoldResp
	retMyGoldPage.GoldNum = float32(userInfo.Gold) / 100
	retMyGoldPage.GetDetail = detailList
	retMyGoldPage.NextPageToken = retPageToken

	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retMyGoldPage
	return formatJson(result)
}

// 获取一页金币获得明细
func (o *APIHandler) GetOnePageGetGoldDetail(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetOnePageGetGoldDetail() ...... ")
	
	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("GetOnePageGetGoldDetail(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}	
	
	// 该用户信息
	userInfo, err := o.GetUsrInfoById(meUid)
	if err != nil {
		log4go.Error("GetOnePageGetGoldDetail() GetUsrInfoById db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}		
	
	// page token
	lastId := int64(-1)
	pageToken := SafeParams(r, "next_page_token")
	lastIdStr, _ := ParsePageTokenByString(pageToken)
	lastId, _ = strconv.ParseInt(lastIdStr, 10, 64)
	log4go.Debug("GetOnePageGetGoldDetail() pageToken:%s, lastId=%d ", pageToken, lastId)	
			
	// 该用户获取的金币记录		
	goldRecords, err := o.GetUserGetGoldDetailDB(meUid, lastId, DUOBAO_RECORD_PAGE_SIZE)
	if err != nil {
		log4go.Error("GetOnePageGetGoldDetail() ModifyAddrDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	retPageToken := ""
	if len(goldRecords) > 0 && len(goldRecords) == DUOBAO_RECORD_PAGE_SIZE {
		lastTimeStamp := goldRecords[len(goldRecords) - 1].CreatedAt
		lastStamp := fmt.Sprintf("%d", lastTimeStamp)
		retPageToken = GenPageTokenByString(lastStamp, true)
	}	
	log4go.Debug("GetOnePageGetGoldDetail() retPageToken:%s ", retPageToken)
	
	detailList, err := o.GetUserGoldDetailRespInfo(goldRecords)
	if err != nil {
		log4go.Error("GetOnePageGetGoldDetail() GetUserGoldDetailRespInfo db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
		
	var retMyGoldPage MyGoldResp
	retMyGoldPage.GoldNum = float32(userInfo.Gold) / 100
	retMyGoldPage.GetDetail = detailList
	retMyGoldPage.NextPageToken = retPageToken

	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retMyGoldPage
	return formatJson(result)
}

// 获取一页金币获得明细
func (o *APIHandler) GetOnePageUsedGoldDetail(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("GetOnePageUsedGoldDetail() ...... ")
	
	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("GetOnePageUsedGoldDetail(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}			
	
	// page token
	lastId := int64(-1)
	pageToken := SafeParams(r, "next_page_token")
	lastIdStr, _ := ParsePageTokenByString(pageToken)
	lastId, _ = strconv.ParseInt(lastIdStr, 10, 64)
	log4go.Debug("GetOnePageUsedGoldDetail() pageToken:%s, lastId=%d ", pageToken, lastId)	
			
	// 该用户主订单记录		
	Records, err := o.GetUserUsedGoldMainOrderDB(meUid, lastId, DUOBAO_RECORD_PAGE_SIZE)
	if err != nil {
		log4go.Error("GetOnePageUsedGoldDetail() ModifyAddrDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	retPageToken := ""
	if len(Records) > 0 && len(Records) == DUOBAO_RECORD_PAGE_SIZE {
		lastTimeStamp := Records[len(Records) - 1].CreatedAt
		lastStamp := fmt.Sprintf("%d", lastTimeStamp)
		retPageToken = GenPageTokenByString(lastStamp, true)
	}	
	log4go.Debug("GetOnePageUsedGoldDetail() retPageToken:%s ", retPageToken)
	
	var retUseGoldList []UseGoldDetailResp
	
	for _, record := range Records {
		// 根据主订单查询子单夺宝信息
		subInfos, err := o.GetSubOrderInfoByMainOrderDb(record.OrderNo)
		if err != nil {
			log4go.Error("GetOnePageUsedGoldDetail() GetSubOrderInfoByMainOrderDb db ERROR!")
			return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
		}	
		var retUseGold UseGoldDetailResp	
		var pgList []PeriodGoodsSt
		for _, info := range subInfos {
			stPG := PeriodGoodsSt{
				Period: info.Period,
				GoodsName: info.GoodsName,
			}	
			pgList = append(pgList, stPG) 		
		}
		retUseGold.PeriodGoods = pgList
		retUseGold.UsedGold = float32(record.Gold) / 100
		retUseGold.RestGold = float32(record.RestGold) / 100
		retUseGold.Time = transUnixTime2DateString(record.CreatedAt/1000)
		retUseGoldList = append(retUseGoldList, retUseGold)
	}
	
	type UseGoldResp struct {
		NextPageToken string `json:"next_page_token"`
		List []UseGoldDetailResp `json:"list"`
	}	
	
	var retUseGoldInfo UseGoldResp
	retUseGoldInfo.NextPageToken = retPageToken
	retUseGoldInfo.List = retUseGoldList

	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retUseGoldInfo
	return formatJson(result)
}

// 创建夺宝活动
func (o *APIHandler) CreateDuobao(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("CreateDuobao() ...... ")
	
	goodsIdStr :=  SafeParamsFromPost(r, "goods_id") 
	if goodsIdStr == "" {
		log4go.Error("CreateDuobao(): 'goods_id' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	goodsId, _ := strconv.ParseInt(goodsIdStr, 10, 64)
	if goodsId <= 0 {
		log4go.Error("CreateDuobao(): invalid 'goods_id': [%s]", goodsIdStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )		
	}
	
	needTotalStr := SafeParamsFromPost(r, "need_total") 
	if needTotalStr == "" {
		log4go.Error("CreateDuobao(): 'need_total' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	needTotal, _ := strconv.ParseInt(needTotalStr, 10, 64)
	if needTotal <= 0 {
		log4go.Error("CreateDuobao(): invalid 'need_total': [%s]", needTotalStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )		
	}	
	
	buyUnitStr := SafeParamsFromPost(r, "buy_unit")
	if buyUnitStr == "" {
		log4go.Error("CreateDuobao(): 'buy_unit' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}	
	buyUnit, _ := strconv.ParseInt(buyUnitStr, 10, 64)
	if buyUnit <= 0 {
		log4go.Error("CreateDuobao(): invalid 'buy_unit': [%s]", buyUnitStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )		
	}					
	
	period, err := o.CreateDuobaoDb(goodsId, int(needTotal), int(buyUnit))
	if err != nil {
		log4go.Error("ModifyAddress() ModifyAddrDb db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
	
	o.InitOneDuobaoCodePoolDb(period, int(needTotal))
	
	type CreateDuobaoResp struct {
		Period int64 `json:"period"`
	}
	
	duobaoInfo := CreateDuobaoResp { Period: period, }
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = duobaoInfo
	return formatJson(result)
}

// 启动夺宝活动
func (o *APIHandler) LauchDuobao(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("LauchDuobao() ...... ")
	
	periodStr := SafeParamsFromPost(r, "period") 
	if periodStr == "" {
		log4go.Error("LauchDuobao(): 'period' param missing!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )					
	}
	period, _ := strconv.ParseInt(periodStr, 10, 64)
	if period <= 0 {
		log4go.Error("LauchDuobao(): invalid 'period': [%s]", periodStr)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )		
	}
	
	signed := SafeParamsFromPost(r, "signature")
	if signed != "balabalaxiaomoxian" {
		log4go.Error("LauchDuobao(): invalid 'signature': [%s]", signed)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )		
	}					
	
	err := o.LauchOneDuobaoDb(period)
	if err != nil {
		log4go.Error("LauchDuobao() LauchOneDuobaoDb db ERROR: %s!", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}
		
	type LauchDuobaoResp struct {
		Period int64 `json:"period"`
	}
	
	duobaoInfo := LauchDuobaoResp { Period: period, }
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = duobaoInfo
	return formatJson(result)
}

// 测试
func (o *APIHandler) DevelopTest(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("DevelopTest() ...... ")
	
	o.SetLatestJoinedTimeValueDB()
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result)
}

/*################################################# 注册登录 start #######################################################*/

// 用户注册
func (o *APIHandler) RegisterUser(r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {
	mobile := SafeParams(r, "mobile")
	verify_code := SafeParams(r, "verify_code")	
	passwd := SafeParams(r, "passwd")
	log4go.Info("Register user request: mobile=%s, verify_code=%s, passwd=%s", mobile, verify_code, passwd)
	
	partPode := SafeParams(r, "part_code")
	recommandUid := SafeParams(r, "re_uid")
	log4go.Info("Register user request: part_code=%s, re_uid=%s", partPode, recommandUid)

	var result ResponseInfo
	if len(mobile) < 11 {
		result.Code = RET_PARAM_INVALID 
		result.Msg = MSG_PARAM_INVALID 
		log4go.Error("RegisterUser failed, invalid mobile number: %s", mobile)
		return formatJson(result), nil
	}

	// 检查验证码是否正确(从redis读取)
	cacheKey := fmt.Sprintf("smscode-%s", mobile)
	lastCode, _ := o.readCachedVerifyCodeByMobile(cacheKey)
	if 	lastCode != verify_code {
		result.Code = RET_SMSCODE_INCORRECT
		result.Msg = MSG_SMSCODE_INCORRECT
		log4go.Error("RegisterUser failed, request verify code is '%s', but cached sms code is '%s'", verify_code, lastCode) 
		return formatJson(result), nil
	}

	if o.mobileExistsInDB(mobile) {
		result.Code = RET_MOBILE_NUM_EXISTS 
		result.Msg = MSG_MOBILE_NUM_EXISTS 
		log4go.Error("RegisterUser: [mobile=%s] already exist in db.", mobile)
		return formatJson(result), nil
	}

	//不存在,则创建
	var user UserInfoDb
	user.PlatformName = "idb"
	user.Mobile = mobile
	user.Password = passwd
	user.Nickname = genInitNickname(mobile)
	user.LastIP = GetClientIpAddr(r)
	user.Gender = "U"
	user.PartCode = "idb"
	user.Avatar = DUOBAO_DEFAULT_AVATAR
	user.CreatedAt = time.Now().Unix()
	user.PartCode = partPode
	if len(recommandUid) > 0 {
		reUid, _ := strconv.ParseInt(recommandUid, 10, 64)
		if reUid > 0 {
			user.ReUid =reUid - DUOBAO_USER_ID_BASE
		} 		
	}	 	
	
	err := o.InsertUserToDB(user) // dbmap.Insert(&user)
	if err != nil {
		log4go.Error("RegisterUser insert user %s to db failed, err=%s", mobile, err.Error())
		result.Code = RET_INTERNAL_ERROR 
		result.Msg = MSG_INTERNAL_ERROR 
		return formatJson(result), err
	} else {
		result.Code = RET_OK
		result.Msg = MSG_OK
		log4go.Info("RegisterUser insert user %s to db success", mobile)
		return formatJson(result), nil
	}
}

// 用户登陆
func (o *APIHandler) Login(w http.ResponseWriter, r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {
	mobile := SafeParams(r, "mobile")	
	passwd := SafeParams(r, "passwd")
	
	log4go.Info("Login user request: mobile=%s, passwd=%s", mobile, passwd)

	var result ResponseInfo

	dbmap, tableName := o.GetUserDBMap()
	mobileQuery := fmt.Sprintf("select user_id, nick_name, gender, avatar, binding_mobile, part_code, recommend_uid from %s where mobile = ? and password = ?", tableName)

	//读取数据库,查询数据是否存在对应的mobile
	var userInfo UserInfoDb 
	err := dbmap.SelectOne(&userInfo, mobileQuery, mobile, passwd)
	if err != nil {
		result.Code = RET_USER_OR_PASSWD_WRONG 
		result.Msg = MSG_USER_OR_PASSWD_WRONG 
		log4go.Warn("Login: mobile or password incorrect, mobile=%s, error=[%s]", mobile, err)
		return formatJson(result), nil
	}
	
	//此是手机登录，如果绑定手机字段为空，修改该值为改用户手机
	if userInfo.BindMobile == "" {
		sqlCommand := fmt.Sprintf("UPDATE %s SET binding_mobile=? where user_id=?",tableName)
		log4go.Debug("Login(): try to exec SQL command: [ %s ] ...", sqlCommand)
		sqlRet, err := dbmap.Exec(sqlCommand, mobile, userInfo.UserId)
		if err != nil {
			log4go.Error("Update binding_mobile(%s) text failed:  %s", mobile, err)
			result.Code = RET_INTERNAL_ERROR
			result.Msg = MSG_INTERNAL_ERROR
			return formatJson(result), nil
		}
		if affected, _ := sqlRet.RowsAffected(); affected < 1 {
			log4go.Warn("Login: affectedRows is 0 after try to update binding_mobile(%s)!", mobile)
		}
		
		userInfo.BindMobile = mobile
	}

	newToken, err := o.updateUserToken(userInfo.UserId)
	if err != nil {
		result.Code = RET_INTERNAL_ERROR 
		result.Msg = MSG_INTERNAL_ERROR 
	} else {		
		// 清单 
		cartInfos, _ := o.GetCartListDb(userInfo.UserId)
		cartGoodsNum := 0
		if cartInfos != nil {
			cartGoodsNum = len(cartInfos)
		} 
		result.Code = RET_OK
		result.Msg = MSG_OK
		result.Data = LoginRetInfo { 
			UserId: userInfo.UserId + DUOBAO_USER_ID_BASE,
			Token: newToken,
			Nickname: userInfo.Nickname,
			Gender: userInfo.Gender,
			Avatar: userInfo.Avatar,
			PlatformName: userInfo.PlatformName, 
			BindingMobile: userInfo.BindMobile,
			CartGoodsNum: cartGoodsNum,
		}
	}	
	
	// ip地址
	ipClient := GetClientIpAddr(r)
	log4go.Debug("Login(): ipClient [ %s ] ...", ipClient)
	if userInfo.UserId > 0 && len(ipClient) > 0 {
		locationEntity := LocationQuryEntity{
			usrId: userInfo.UserId,
			ip:    ipClient,
		}
		sqlCommand := fmt.Sprintf("UPDATE %s SET user_ip=? where user_id=?",tableName)
		_, err = dbmap.Exec(sqlCommand, ipClient, userInfo.UserId)
		if err != nil {
			log4go.Error("Update user_ip(%s) failed:  %s", ipClient, err)
		}
		o.locationChannel <- locationEntity
	}
	
	//setLoginCookie(w, userInfo.UserId)
	return formatJson(result), nil
}

// 重置密码
func (o *APIHandler) ResetPasswdByCode(r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {
	mobile := SafeParams(r, "mobile")
	smsCode := SafeParams(r, "verify_code")	
	newPasswd := SafeParams(r, "new_passwd")

	var result ResponseInfo

	if mobile == "" || smsCode == "" {
		result.Code = RET_PARAM_INVALID 
		result.Msg = MSG_PARAM_INVALID 
		log4go.Warn("ResetPasswdByCode: mobile or verify_code is empty")
		return formatJson(result), nil		
	}

	log4go.Info("ResetPasswdByCode request: mobile=%s, verify_code=%s", mobile, smsCode)

	mobileKey := fmt.Sprintf("smscode-%s",mobile)
	serverCode, _ := o.readCachedVerifyCodeByMobile(mobileKey)  
	if serverCode != smsCode {
		result.Code = RET_SMSCODE_INCORRECT 
		result.Msg = MSG_SMSCODE_INCORRECT 
		log4go.Error("ResetPasswdByCode: SMS code for mobile '%s' not valid, request_code=%s, server_code=%s", mobile, smsCode, serverCode)
		return formatJson(result), Err_SmsCode_Not_Expire
	}

	dbmap, tableName := o.GetUserDBMap()
	sqlCommand := fmt.Sprintf("Update %s set password=? where mobile=? and plateform_reg='idb'", tableName)
	ret, err := dbmap.Exec(sqlCommand, newPasswd, mobile)
	if err != nil {
		log4go.Error("ResetPasswdByCode failed, error: %s", err)
		result.Code = RET_INTERNAL_ERROR
		result.Msg = MSG_INTERNAL_ERROR
		return formatJson(result), nil
	}
	if affected, _ := ret.RowsAffected(); affected < 1 {
		log4go.Error("ResetPasswdByCode(): can't find user by '%s'", mobile)
		result.Code = RET_USER_NOT_EXISTS
		result.Msg = MSG_USER_NOT_EXISTS
		return formatJson(result), nil
	}

	log4go.Info("ResetPasswdByCode succeeded, mobile=%s, new_passwd=%s", mobile, newPasswd)
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result), nil
}


// 第三方用户登陆
func (o *APIHandler) LoginFrom3rdParty(w http.ResponseWriter, r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {
	platformId := SafeParams(r, "platform_id")
	openId := SafeParams(r, "open_id")	
	accToken := SafeParams(r, "access_token")
	log4go.Info("3rd-party Login user request: platform=%s, open_id=%s, access_token=%s", platformId, openId, accToken)
	
	partPode := SafeParams(r, "part_code")
	recommandUid := SafeParams(r, "re_uid")
	log4go.Info("3rd-party Login user request: part_code=%s, re_uid=%s", partPode, recommandUid)

	if len(openId) == 0 {
		log4go.Warn("LoginFrom3rdParty(): 'open_id' is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID }), nil					
	}	

	var result ResponseInfo
	dbmap, tableName := o.GetUserDBMap()
	mobileQuery := fmt.Sprintf("select user_id, nick_name, gender, avatar from %s where plateform_reg = ? and openid = ?", tableName)

	userExists := true
	//读取数据库,查询数据是否存在对应的记录
	var userInfo UserInfoDb
	err := dbmap.SelectOne(&userInfo, mobileQuery, platformId, openId) 
	if err == sql.ErrNoRows {
		userExists = false
	}else if err != nil {
		log4go.Warn("LoginFrom3rdParty failed, error=[%s]",  err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), nil
	}
	
	// ip地址
	ipClient := GetClientIpAddr(r)
	log4go.Debug("LoginFrom3rdParty(): ipClient [ %s ] ...", ipClient)
	if userInfo.UserId > 0 && len(ipClient) > 0 {
		locationEntity := LocationQuryEntity{
			usrId: userInfo.UserId,
			ip:    ipClient,
		}
		o.locationChannel <- locationEntity
	}	

	var user_id int64
	var nickname, gender, avatarPath string
	if userExists  {
		// exists
		log4go.Info("LoginFrom3rdParty(): User [%s] from '%s' exists, user_id=%d", openId, platformId, userInfo.UserId)
		user_id = userInfo.UserId

		nickname = userInfo.Nickname
		gender = userInfo.Gender
		avatarPath = userInfo.Avatar
	} else {
		// not exists
		
		if len(accToken) == 0 {
			log4go.Warn("LoginFrom3rdParty(): 'access_token' is empty!")
			return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } ), nil					
		}		
		
		var user UserInfoDb
		user.Gender = "U"
		
		// 请求微信、QQ获取用户信息
		var wxUserInfo *WxUserInfoResp
		var qqUserInfo *QQUserInfoResp
		var err error
		if platformId == "qq" {
			qqUserInfo, err = o.GetQqUserInfo(accToken, openId)
			if err != nil {
				log4go.Error("LoginFrom3rdParty() GetQqUserInfo ERROR: %s!", err)
				return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), nil			
			}		
			user.Avatar = qqUserInfo.HeadImgUrl
			avatarPath = qqUserInfo.HeadImgUrl
			user.Nickname = qqUserInfo.NickName
			nickname = qqUserInfo.NickName
			user.City = qqUserInfo.City
			if qqUserInfo.Gender == "男" {
				user.Gender = "M"
			} else if qqUserInfo.Gender == "女" {
				user.Gender = "F"
			} 			
		} else {
			wxUserInfo, err = o.GetWxUserInfo(accToken, openId)
			if err != nil {
				log4go.Error("LoginFrom3rdParty() GetWxUserInfo ERROR: %s!", err)
				return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), nil			
			}			
			user.Avatar = wxUserInfo.HeadImgUrl
			avatarPath = wxUserInfo.HeadImgUrl
			user.Nickname = wxUserInfo.NickName
			user.City = wxUserInfo.City
			nickname = wxUserInfo.NickName
			if wxUserInfo.Sex == 1 {
				user.Gender = "M"
			} else if wxUserInfo.Sex == 2 {
				user.Gender = "F"
			} 		
		}
				
		user.PlatformName = platformId
		user.OpenId = openId			
		user.LastIP = ipClient
		
		user.CreatedAt = time.Now().Unix()			
		user.PartCode = partPode
		if len(recommandUid) > 0 {
			reUid, _ := strconv.ParseInt(recommandUid, 10, 64)
			if reUid > 0 {
				user.ReUid =reUid-DUOBAO_USER_ID_BASE
			} 	
		}		
		
		gender = user.Gender	
		log4go.Info("LoginFrom3rdParty(): try to insert new user [%s] to db...", user.Nickname)

		//if userExists == false  { // 用户不存在插入
			err = dbmap.Insert(&user)
			if err != nil {
				log4go.Error("LoginFrom3rdParty(): insert user %s to [%s] failed, err=%s", openId, tableName, err.Error())
				return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), nil
			} 
		//}
		user_id = user.UserId
		log4go.Info("LoginFrom3rdParty: new user(openId=%s) user_id is %d", openId, user_id)
	}

	newToken, err := o.updateUserToken(user_id)
	if err != nil {
		log4go.Error("LoginFrom3rdParty(): updateUserToken failed, err=%s", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), nil
	} 
	
	// 更新IP	
	sqlCommand := fmt.Sprintf("UPDATE %s SET user_ip=? where user_id=?",tableName)
	_, err = dbmap.Exec(sqlCommand, ipClient, user_id)
	if err != nil {
		log4go.Error("Update user_ip(%s) failed:  %s", ipClient, err)
	}		
	
	cartInfos, _ := o.GetCartListDb(user_id)
	cartGoodsNum := 0
	if cartInfos != nil {
		cartGoodsNum = len(cartInfos)
	} 	
	
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = LoginRetInfo { 
		UserId: user_id + DUOBAO_USER_ID_BASE,
		Token: newToken,
		Nickname: nickname,
		Gender: gender,
		Avatar: avatarPath,
		PlatformName: platformId,
		CartGoodsNum: cartGoodsNum, 
	}	
	
	return formatJson(result), nil
}

// 获取省(区)全称
func GetProvinceFullName(province string) string {

	mapProvince := map[string]string{
		"北京": "北京市", "上海": "上海市", "天津": "天津市", "重庆": "重庆市",
		"黑龙江": "黑龙江省", "辽宁": "辽宁省", "吉林": "吉林省", "河北": "河北省",
		"河南": "河南省", "湖北": "湖北省", "湖南": "湖南省", "山东": "山东省",
		"山西": "山西省", "陕西": "陕西省", "安徽": "安徽省", "浙江": "浙江省",
		"江苏": "江苏省", "福建": "福建省", "广东": "广东省", "海南": "海南省",
		"四川": "四川省", "云南": "云南省", "贵州": "贵州省", "青海": "青海省",
		"甘肃": "甘肃省", "江西": "江西省", "台湾": "台湾省",
		"内蒙古": "内蒙古自治区", "宁夏": "宁夏回族自治区",
		"新疆": "新疆维吾尔自治区", "西藏": "西藏自治区", "广西": "广西壮族自治区",
		"香港": "香港特别行政区", "澳门": "澳门特别行政区",
	}

	// 查找键值是否存在
	if v, ok := mapProvince[province]; ok {
		return v
	}

	return ""
}


func (o *APIHandler) setUserLocation(r *http.Request, headers *CommonHeaders, sequence uint64) (string,error) {
	var result ResponseInfo

	user_id, err := o.queryUserIdByToken(headers.UserToken)
	if err != nil || user_id == -1 {
		log4go.Error("setUserLocation(): User token(%s) invalid: error=%s", headers.UserToken, err)
		result.Code = RET_TOKEN_EXPIRED 
		result.Msg = MSG_TOKEN_EXPIRED 
		return formatJson(result),nil
	}
	
	location := SafeParams(r, "location")
	longitude := SafeParams(r, "longitude")
	latitude := SafeParams(r, "latitude")
	log4go.Debug("setUserLocation(): location=%s, longitude=%s, desc='%s'", location, longitude, latitude)
	
	//把location拆分成省，市，具体地址
	locationList := strings.Split(location, "|")
	if len(locationList) < 3 {
		log4go.Error("setUserLocation(): locationList's len less than 3")
		result.Code = RET_PARAM_INVALID 
		result.Msg = MSG_PARAM_INVALID
		return formatJson(result),nil
	}
	province := locationList[0]
	city := locationList[1]
	location = locationList[2]

	// 省名统一
	if len(province) > 0 {
		str := GetProvinceFullName(province)
		if str != "" {
			province = str
		}
	}

	//更新数据库
	dbmap, tableName := o.GetUserDBMap()
	sqlCommand := fmt.Sprintf("UPDATE %s SET `province`=?, city=?, location=? where user_id=?", tableName)
	log4go.Debug("setUserLocation(): try to exec SQL command: [ %s ] ...", sqlCommand)
	sqlRet, err := dbmap.Exec(sqlCommand, province, city, location, user_id)
	if err != nil {
		log4go.Error("Update user(%d) location failed:  %s", user_id, err)
		result.Code = RET_INTERNAL_ERROR
		result.Msg = MSG_INTERNAL_ERROR
		return formatJson(result), nil
	}
	if affected, _ := sqlRet.RowsAffected(); affected < 1 {
		log4go.Warn("setUserLocation(%d): affectedRows is 0 after try to update text!", user_id)
	}
	
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result), nil
}

func (o *APIHandler) bindMobile(r *http.Request, headers *CommonHeaders, sequence uint64) (string,error) {
	var result ResponseInfo

	user_id, err := o.queryUserIdByToken(headers.UserToken)
	if err != nil || user_id == -1 {
		log4go.Error("bindMobile(): User token(%s) invalid: error=%s", headers.UserToken, err)
		result.Code = RET_TOKEN_EXPIRED 
		result.Msg = MSG_TOKEN_EXPIRED 
		return formatJson(result),nil
	}
	
	mobile := SafeParams(r, "mobile")
	verify_code := SafeParams(r, "verify_code")
	log4go.Debug("bindMobile(): mobile=%s, verfy_code=%s", mobile, verify_code)
	
	//手机号码合法性
	if len(mobile) < 11 {
		log4go.Error("bindMobile failed, invalid mobile number: %s", mobile)
		result.Code = RET_PARAM_INVALID 
		result.Msg = MSG_PARAM_INVALID 
		return formatJson(result), nil
	}
	
	//验证码不能为空
	if verify_code == "" {
		log4go.Error("bindMobile failed, invalid verify_code is null")
		result.Code = RET_PARAM_INVALID 
		result.Msg = MSG_PARAM_INVALID 
		return formatJson(result), nil
	}
	
	//验证验证码是否有效
	cacheKey := fmt.Sprintf("smscode-%s", mobile)
	lastCode, _ := o.readCachedVerifyCodeByMobile(cacheKey)
	if 	lastCode != verify_code {
		result.Code = RET_SMSCODE_INCORRECT
		result.Msg = MSG_SMSCODE_INCORRECT
		log4go.Error("bindMobile failed, param verify code is '%s', but cached sms code is '%s'", verify_code, lastCode) 
		return formatJson(result), nil
	}
	
	//更新数据库 
	dbmap, tableName := o.GetUserDBMap()
	sqlCommand := fmt.Sprintf("UPDATE %s SET `binding_mobile`=? where user_id=?", tableName)
	log4go.Debug("bindMobile(): try to exec SQL command: [ %s ] ...", sqlCommand)
	sqlRet, err := dbmap.Exec(sqlCommand, mobile, user_id)
	if err != nil {
		log4go.Error("Update user(%d) bindMobile failed:  %s", user_id, err)
		result.Code = RET_INTERNAL_ERROR
		result.Msg = MSG_INTERNAL_ERROR
		return formatJson(result), nil
	}
	if affected, _ := sqlRet.RowsAffected(); affected < 1 {
		log4go.Warn("bindMobile(%d): affectedRows is 0 after try to update text!", user_id)
	}
	
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result), nil
}

// 获取appid
func (o *APIHandler) GetWxAppId(r *http.Request, headers *CommonHeaders, sequence uint64) (string,error) {
	var result ResponseInfo

	type WxAppId struct {
		AppId string `json:"app_id"` 
	}
	
	signature := SafeParams(r, "signature")
	log4go.Debug("GetWxAppId(): signature=%s", signature)		
	calcSig, matched := CheckSignature(DUOBAO_SECRET_KEY, "get_wx_appid", signature)
	if !matched {
		log4go.Error("GetWxAppId(): signature check failed, serverSig=[ %s ]， clientSig=[ %s ]", calcSig, signature)
		return formatJson( ResponseInfo{ Code: RET_SIG_CHECK_FAILED, Msg: MSG_SIG_CHECK_FAILED } ), nil
	}	
	
	
	retAppId := WxAppId{AppId:DUOBAO_WX_APPID,}
	result.Data = retAppId
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result), nil
}

// 获取微信token openid
func (o *APIHandler)GetWxTokenByCode(code string) (*WxAccTokenResp, error) {
	log4go.Info("GetWxTokenByCode() code: %s", code)
	
	AccTokenUrl := "https://api.weixin.qq.com/sns/oauth2/access_token"
	AccessUrl := fmt.Sprintf("%s?appid=%s&secret=%s&code=%s&grant_type=authorization_code", AccTokenUrl, DUOBAO_WX_APPID, DUOBAO_WX_SECRET, code)
	
	resp, _ := http.Get(AccessUrl)	
	defer resp.Body.Close()
	
	retData, _ := ioutil.ReadAll(resp.Body)		
	log4go.Info("retData: %s", string(retData))
	
	respInfo := &WxAccTokenResp{}
	err := json.Unmarshal(retData, respInfo) // JSON to Struct
	if err != nil {
		log4go.Error("GetWxTokenByCode JSON to Struct(): error [ %s ]", err)
		return nil, err
	}	
	return respInfo, nil
}

// 获取微信公众号开发 token
func (o *APIHandler)GetWxPubApiTokenImpl() (*WxAccTokenResp, error) {
	log4go.Info("GetWxPubApiTokenImpl()... ")
	
	// 获取api token
	AccTokenUrl := "https://api.weixin.qq.com/cgi-bin/token"
	AccessUrl := fmt.Sprintf("%s?grant_type=client_credential&appid=%s&secret=%s", AccTokenUrl, DUOBAO_WX_APPID, DUOBAO_WX_SECRET)
	
	resp, _ := http.Get(AccessUrl)	
	defer resp.Body.Close()
	
	retData, _ := ioutil.ReadAll(resp.Body)		
	log4go.Info("retData: %s", string(retData))	
	tokenInfo := &WxAccTokenResp{}
	err := json.Unmarshal(retData, tokenInfo)
	if err != nil {
		log4go.Error("GetWxPubApiTokenImpl JSON to Struct(): error [ %s ]", err)
		return nil, err
	}	
	
	SetWxApiToken(tokenInfo.AccToken)	
	return tokenInfo, nil
}

// 获取微信公众号开发 ticket
func (o *APIHandler)GetWxPubApiTicketImpl(token *WxAccTokenResp) (string, error) {
	log4go.Info("GetWxPubApiTicketImpl()... token=%s", token.AccToken)
	
	if token==nil || len(token.AccToken)<=0 {
		log4go.Info("GetWxPubApiTicketImpl() token invalid")
		return "", nil
	}

	type WxTicketResp struct {
		ErrCode 		int   	`json:"errcode"` 
		ErrMsg 		string   `json:"errmsg"`
		Ticket 		string   `json:"ticket"`
		ExpireIn 	int   `json:"expires_in"`
	}
	
	// 获取ticket
	AccTokenUrl := "https://api.weixin.qq.com/cgi-bin/ticket/getticket"
	AccessUrl := fmt.Sprintf("%s?access_token=%s&type=jsapi", AccTokenUrl, token.AccToken)
	
	resp, _ := http.Get(AccessUrl)	
	defer resp.Body.Close()
	
	retData, _ := ioutil.ReadAll(resp.Body)		
	log4go.Info("retData: %s", string(retData))	
	ticketInfo := &WxTicketResp{}
	err := json.Unmarshal(retData, ticketInfo)
	if err != nil {
		log4go.Error("GetWxPubApiTicketImpl JSON to Struct(): error [ %s ]", err)
		return "", err
	}	
	SetWxApiTicket(ticketInfo.Ticket)			
	return ticketInfo.Ticket, nil	
}

// 获取QQ token
func (o *APIHandler)GetQQTokenByCode(code string) (*WxAccTokenResp, error) {
    log4go.Info("GetQQTokenByCode() code: %s", code)
    var respInfo WxAccTokenResp
	
    AccTokenUrl := "https://graph.qq.com/oauth2.0/token"
    AccessUrl := fmt.Sprintf("%s?grant_type=authorization_code&client_id=%s&client_secret=%s&redirect_uri=%s&code=%s", 
        AccTokenUrl, DUOBAO_QQ_APPID, DUOBAO_QQ_SECRET, DUOBAO_QQ_REDIRCT_URI, code)
    
    resp, _ := http.Get(AccessUrl)  
    defer resp.Body.Close()
    
    retData, _ := ioutil.ReadAll(resp.Body)  
	dataString := string(retData)
    log4go.Info("retData: %s", dataString)
	
	if strings.Index(dataString, "error") >= 0 {
		return &respInfo, errors.New("can not found")
	}
	
	strArray := strings.Split(dataString, "&")
	
	tag := "access_token="
	var token string
	for _, item := range strArray {
		
		pos := strings.Index(item, tag)
		log4go.Info("item: %s, pos:%d", item, pos)
		if pos >= 0 {
			token = item[len(tag):]
			break
		} 
	}
    log4go.Info("token: %s", token)
	
	respInfo.AccToken = token

	if len(token) <=0 {
		log4go.Info("GetQQTokenByCode() len(token) <=0")
		return &respInfo, errors.New("can not found token")
	} 
  
	openId, _ := o.GetQqOpenIdByToken(respInfo.AccToken)
	log4go.Info("openId: %s", openId)
	if len(openId) > 0 {
		respInfo.OpenId = openId
	} 
    return &respInfo, nil
}

// 获取QQ openid
func (o *APIHandler)GetQqOpenIdByToken(token string) (string, error) {
    log4go.Info("GetQqOpenIdByTOken() token: %s", token)
    
    OpenIdUrl := "https://graph.qq.com/oauth2.0/me"
    AccessUrl := fmt.Sprintf("%s?access_token=%s", OpenIdUrl, token)
	log4go.Info("GetQqOpenIdByTOken() AccessUrl: %s", AccessUrl)
    
    resp, err := http.Get(AccessUrl)  
	if err != nil {
		log4go.Info("GetQqOpenIdByTOken() Request AccessUrl error:%s", err)
		return "", nil
	}
	
    defer resp.Body.Close()
    
    retData, err := ioutil.ReadAll(resp.Body)  
	retString := string(retData)  
    log4go.Info("retString: %s", retString)
   
    if err != nil {
        log4go.Error("GetQqOpenIdByTOken error [ %s ]", err)
        return "", err
    }   	
	
	tag := `"openid":`
	pos := strings.Index(retString, tag)
	openId := ""
	if pos >= 0 {
		source := retString[pos+len(tag):]
		log4go.Info("source: %s", source)
		pos1 := strings.LastIndex(source, `"`)
		log4go.Info("pos1: %d", pos1)
		if pos1 > 10 {
			openId = source[1:pos1]
		}
		log4go.Info("openId: %s", openId)
	}
    return openId, nil
}

// 获取openid和token
func (o *APIHandler) GetAccessTokenByCode(r *http.Request, headers *CommonHeaders, sequence uint64) (string,error) {
	
	code := SafeParams(r, "code")
	log4go.Debug("GetAccessTokenByCode(): code=%s", code)
	
	platform := SafeParams(r, "platform_id")
	log4go.Debug("GetAccessTokenByCode(): platform_id=%s", platform)	
	
	if len(code) == 0 {
		log4go.Error("GetAccessTokenByCode(): invalid param 'code'")
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } ), nil			
	}
	
	signature := SafeParams(r, "signature")
	log4go.Debug("GetAccessTokenByCode(): signature=%s", signature)		
	calcSig, matched := CheckSignature(DUOBAO_SECRET_KEY, code, signature)
	if !matched {
		log4go.Error("GetAccessTokenByCode(): signature check failed, serverSig=[ %s ]， clientSig=[ %s ]", calcSig, signature)
		return formatJson( ResponseInfo{ Code: RET_SIG_CHECK_FAILED, Msg: MSG_SIG_CHECK_FAILED } ), nil
	}	
	
	var err error
	var Token *WxAccTokenResp 
	if platform == "qq" {
		Token, err = o.GetQQTokenByCode(code)
	} else {
		Token, err = o.GetWxTokenByCode(code)
	}
		
	if err != nil {
		log4go.Error("GetAccessTokenByCode() GetWxTokenByCode ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), nil		
	}	
	
	var result ResponseInfo

	type WxToken struct {
		Token WxAccTokenResp `json:"wx_token"` 
	}
	retToken := WxToken{ Token: *Token,}
	result.Data = retToken
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result), nil
}


// 获取微信公众号api开发 配置信息
func (o *APIHandler) GetWxPubApiCfgInfo(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {
	
	//url := SafeParams(r, "url")
	url := r.FormValue("url")
	log4go.Debug("GetWxPubApiCfgInfo(): url=%s", url)
	if len(url) <= 0 {
		log4go.Error("GetWxPubApiCfgInfo() url parameter INVALID!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )		
	}
	
	signature := SafeParams(r, "signature")
	log4go.Debug("GetWxPubApiCfgInfo(): signature=%s", signature)	
	
	calcSig, matched := CheckSignature(DUOBAO_SECRET_KEY, url, signature)
	if !matched {
		log4go.Error("GetWxPubApiCfgInfo(): signature check failed, serverSig=[ %s ]， clientSig=[ %s ]", calcSig, signature)
		return formatJson( ResponseInfo{ Code: RET_SIG_CHECK_FAILED, Msg: MSG_SIG_CHECK_FAILED } )
	}

	// 获取api开发ticket
	ticket := GetWxApiTicket()
	// 随机字符串
	randStr := GetRandomString(16)
	// 当前时间
	nowUnix := time.Now().Unix()
	
	log4go.Debug("GetWxPubApiCfgInfo(): nowUnix=%d, randStr=%s, ticket=%s", nowUnix, randStr, ticket)	
	
	// 生成签名	
	SourceStr := fmt.Sprintf("jsapi_ticket=%s&noncestr=%s&timestamp=%d&url=%s", ticket, randStr, nowUnix, url)
	signWx := genSha1(SourceStr)
	log4go.Debug("GetWxPubApiCfgInfo(): signWx=%s", signWx)		
		
	var result ResponseInfo

	type WxConfig struct {
		Config WxPubDevCfgResp `json:"wx_config"` 
	}
	
	retConfig := WxPubDevCfgResp{
					Appid: DUOBAO_WX_APPID,
					TimeStamp: nowUnix,
					Noncestr: randStr,
					Signature: signWx,
				}
	retInfo := WxConfig{Config: retConfig,}			
	
	result.Data = retInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result)
}


// 根据微信access_token和open_id获取用户信息
func (o *APIHandler)GetWxUserInfo(accToken string, openId string) (*WxUserInfoResp, error) {
	log4go.Info("GetWxUserInfo() openId: %s", openId)
	
	UsrInfoUrl := "https://api.weixin.qq.com/sns/userinfo"
	AccessUrl := fmt.Sprintf("%s?access_token=%s&openid=%s&lang=zh_CN", UsrInfoUrl, accToken, openId)
	
	resp, _ := http.Get(AccessUrl)	
	defer resp.Body.Close()
	
	retData, _ := ioutil.ReadAll(resp.Body)		
	//log4go.Info("retData: %s", string(retData))
	
	respInfo := &WxUserInfoResp{}
	err := json.Unmarshal(retData, respInfo) // JSON to Struct
	if err != nil {
		log4go.Error("GetWxUserInfo JSON to Struct(): error [ %s ]", err)
		return nil, err
	}	
	return respInfo, nil
}

// 根据QQ access_token和open_id获取用户信息
func (o *APIHandler)GetQqUserInfo(accToken string, openId string) (*QQUserInfoResp, error) {
	log4go.Info("GetQqUserInfo() openId: %s", openId)
	
	UsrInfoUrl := "https://graph.qq.com/user/get_user_info"
	AccessUrl := fmt.Sprintf("%s?access_token=%s&oauth_consumer_key=%s&openid=%s", UsrInfoUrl, accToken, DUOBAO_QQ_APPID, openId)
	
	resp, _ := http.Get(AccessUrl)	
	defer resp.Body.Close()
	
	retData, _ := ioutil.ReadAll(resp.Body)		
	log4go.Info("retData: %s", string(retData))
	
	respInfo := &QQUserInfoResp{}
	err := json.Unmarshal(retData, respInfo) // JSON to Struct
	if err != nil {
		log4go.Error("GetWxUserInfo JSON to Struct(): error [ %s ]", err)
		return nil, err
	}	
	return respInfo, nil
}
/*################################################# 注册登录 end #######################################################*/


// 对某期夺宝活动改成正在揭晓状态
func (o *APIHandler) SetOneDuobaoCountdown(period int64) error {
	log4go.Debug("SetOneDuobaoCountdownDb() ...... period: %s", period)
	
	duobao, err := o.GetDuobaoInfoByPeriodDb(period)
	if err != nil {
		log4go.Error("GetDuobaoInfoByPeriodDb error: %s", err)
		return err
	}
	if duobao.Status != 1 { // 非夺宝状态
		log4go.Error("SetOneDuobaoCountdownDb error: %s", err)
		return errors.New("duobao's status Error!")		
	}		
	if duobao.NeedTotal != duobao.JoinedNum && duobao.NeedTotal > 0 { // 未买完
		log4go.Error("Not sold out!")
		return errors.New("Not sold out!")		
	}		
	
	err = o.SetOneDuobaoCountdownDb(period)
	if err != nil {
		log4go.Error("SetOneDuobaoCountdownDb error: %s", err)
		return err
	}	
	
	// 获取老时时彩最近一期开奖时间
	nowUnix := time.Now().Unix()
	_, periodNo, _, openAt := o.GetCqsscPeriod(nowUnix)
	log4go.Debug("SetOneDuobaoCountdownDb()  periodNo: %s, openAt:%d", periodNo, openAt)
	
	// 设置发布中奖时间 
	openAt = openAt + 240 // 加上4分钟时间
	o.SetOneDuobaoPubTimeDb(period, openAt, periodNo)
	
	return nil	
}


func (o *APIHandler)PublishDuobaoRoutine() (error) {
	sleepSeconds := 60   // 
	for {	
		time.Sleep(time.Duration(sleepSeconds) * time.Second)
		log4go.Info("PublishDuobaoRoutine routine will sleep %d seconds......", sleepSeconds)
		// 检测已经到了揭晓时间的夺宝活动，并揭晓
		o.PublishDuobao()
	}
}

// 揭晓夺宝
func (o *APIHandler)PublishDuobao() (error) {
	log4go.Info("PublishDuobao() ......")
	
	// 获取可以揭晓的夺宝活动
	periodNoList, err := o.GetCanPubDuobaoPeriodsDb()
	if err != nil {
		log4go.Error("GetCanPubDuobaoPeriodsDb ERROR: %s!", err)
		return err
	}
	
	err = o.PublishDuobaosDb(periodNoList)	
	return err	
}

// 揭晓夺宝
func (o *APIHandler) PublishDuobaoApi(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("PublishDuobao() ...... ")
	
	err := o.PublishDuobao()
	if err != nil {
		log4go.Error("PublishDuobao(): PublishDuobao ERROR:%s", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )		
	}
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result)
}

// 用户消息通知
func (o *APIHandler) UserMessageNotify(r *http.Request, headers *CommonHeaders, sequence uint64) (string) {	
	log4go.Debug("UserMessageNotify() ...... ")
	
	meUid, _ := o.queryUserIdByToken(headers.UserToken)
	if meUid <= 0 {
		log4go.Error("UserMessageNotify(): user not login!")
		return formatJson( ResponseInfo{ Code: RET_NOT_LOGIN, Msg: MSG_NOT_LOGIN } )
	}			
	
	// page token
	lastId := int64(-1)
	pageToken := SafeParams(r, "next_page_token")
	lastIdStr, _ := ParsePageTokenByString(pageToken)
	lastId, _ = strconv.ParseInt(lastIdStr, 10, 64)
	log4go.Debug("UserMessageNotify() pageToken:%s, lastId=%d ", pageToken, lastId)	
			
	// 该用户消息通知列表		
	messages, err := o.GetUserMessageListDB(meUid, "sys", lastId, 9/*DUOBAO_RECORD_PAGE_SIZE*/)
	if err != nil {
		log4go.Error("UserMessageNotify(): GetUserMessageListDB ERROR:%s", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )		
	}
	retPageToken := ""
	if len(messages) > 0 && len(messages) == 9/*DUOBAO_RECORD_PAGE_SIZE*/ {
		lastId = messages[len(messages) - 1].Id
		lastIdStr := fmt.Sprintf("%d", lastId)
		retPageToken = GenPageTokenByString(lastIdStr, true)
	}	
	log4go.Debug("UserMessageNotify() retPageToken:%s ", retPageToken)	
	
	type MessageResp struct {	
		Id	  	int64   `json:"id"`
		IsRead  int      `json:"is_read"`
		Time	  	string   `json:"time"`
		Message string `json:"message"`
	}	
	var retMsgList []MessageResp
	for _, message := range messages {
		retMgs := MessageResp {
			Id: message.Id,
			IsRead: message.Status, 
			Time: transUnixTime2DateString(message.CreatedAt),
			Message: message.Content, 
		}	
		retMsgList = append(retMsgList, retMgs)	
	}
	
	type MessageListResp struct {	
		NextPageToken string `json:"next_page_token"`
		List	  []MessageResp   `json:"list"`
	}	
	
	retData := MessageListResp{NextPageToken: retPageToken, List: retMsgList,}
	
	var result ResponseInfo
	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = retData
	return formatJson(result)
}