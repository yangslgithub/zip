package duobao

type ResponseInfo struct {
	Code	int  `json:"code"`
	Msg 	string `json:"msg"`
	Data	interface{} `json:"data"`
}

type CommonDataList struct {
	List interface{} `json:"list"`
	AdList interface{} `json:"adlist,omitempty"`
}

type LoginRetInfo struct {
	UserId int64 `json:"user_id"`
	Nickname string `json:"nickname"`
	Gender string `json:"gender"`
	Token  string `json:"token"`
	AvatarPath string `json:"avatarPath"`
	AvatarUrl string `json:"avatar_url"`
	IsVip int `json:"is_vip"`
	Location string `json:"location"`
	PlatformName string `json:"platform_name"`
	BindingMobile string `json:"binding_mobile"`
	DroneName string `json:"drone_name"`
	PubCount int64 `json:"pub_count"`
	ThreadCount int64 `json:"thread_count"`
	FollowedCount int64 `json:"followed_count"`
	FollowersCount int64 `json:"followers_count"`
	
	UserVerify string `json:"user_verify"`
}


type YunpianResp struct {
	Code int `json:"code"`
	Msg string `json:"msg"`
	Result interface {} `json:"result"`
}

// batchno
type XieheResp struct {
	Code int `json:"code"`
	Batchno string `json:"batchno"`
}


/*=============================================================================*/
type BannerResp struct {
	Id   int64 `json:"item_id"`
	Image  string `json:"image"`
	RefUrl string `json:"ref_url"`
}

type IndexLuckyResp struct {
	UserId    int64 `json:"uid"`
	GoodsName string `json:"gname"`
	RefUrl 	  string `json:"ref_url"`
}

type Thumbnail struct {
	SmallPic string `json:"small_pic"`
	BigPic   string `json:"big_pic"`
}

type GoodsImage struct {
	ImageUrl string `json:"imgurl"`
	Width int `json:"width"`
	Height int `json:"height"`
}

// 参与夺宝的时间和号码
type OwnerAllCode struct {
	Time string `json:"time"`
	Code string `json:"code"`
}

type GoodsDetail struct {
	GoodsImages []GoodsImage `json:"image_list"`
}

// 一次夺宝记录
type DuobaoRecord struct {
	Time  string    `json:"time"`  // 用户下单时间
	Code string     `json:"code"`  // 用户下单分配得到的号码
	Total string    `json:"total"` // 用户本次参与x人次
	Owner OwnerInfo `json:"owner"` // 用户信息
}

type DuobaoRecords struct {
	Items []DuobaoRecord `json:"items"`
}

type DuobaoLuckyInfo struct {
	LuckyCode string `json:"lucky_code"` 			// 幸运号码
	CodeTotal int `json:"code_total"`  				// 用户本次参与x人次
	Owner OwnerInfo `json:"owner"` 					// 用户信息
	AllCode OwnerAllCode `json:"owner_all_code"` 	// 用户下单信息
}

type MyJoinedInfo struct {
	CodeTotal int `json:"code_total"`  				// 用户本次参与x人次
	AllCode OwnerAllCode `json:"owner_all_code"` 	// 用户下单信息
}

// 往期(已揭晓)一次夺宝记录
type PreDuobaoRecord struct {
	Time  string    `json:"period"` 		// 用户下单时间
	Total string    `json:"total"` 			// 用户本次参与x人次
	Owner OwnerInfo `json:"owner"` 			// 用户本次参与x人次
	LuckyCode string `json:"lucky_code"`  	// 幸运号码
	PublishTime string `json:"publish_time"`  // 中奖揭晓时间
	JoinTime string `json:"join_time"`  	// 参与夺宝时间
}

type PreDuobaoRecords struct {
	Items []PreDuobaoRecord `json:"items"`
}

//定义DB用户数据表结构
type OwnerInfo struct {
	UserId        int64   `json:"uid"`
	Nickname      string  `json:"nick_name"`
	Gender        string  `json:"gender"`
	AvatarPath    string  `json:"avatars_url"`
	LastLoginIP   string  `json:"user_ip"`
	AddrDefaultCode int   `json:"addr_default_code"`
	AddrDeliveryCode int  `json:"addr_delivery_code"`
	PlatformName  string  `json:"plateform_reg"` 		
}

// 商品概要信息
type GoodsSummaryResp struct {
	Status int    `json:"status"` 					// 1-夺宝进行中; 2-揭晓倒计时中 ; 3-已揭晓
	Period int64  `json:"period"`
	PublishTime int64  `json:"publish_time"` 		// 中奖揭晓时间，揭晓倒计时用
	GoodId int64    	`json:"gid"`
	GoodsName string    `json:"gname"`
	GoodsDesc string    `json:"gdesc"`
	TotalTimes int64    `json:"total_times"`
	RemainingTimes int64 `json:"remaining_times"`
	BuyUnit int    		`json:"buy_unit"`
	coverImage string   `json:"cover_image"`    	// 封面图片 
	Thumbnails []Thumbnail `json:"thumbnail_list"` 	// 商品图片
	ShowTag string    	`json:"show_tag"`       	// 专区标识
}

// 首页数据
type IndexRespInfo struct {
	BannerList []BannerResp `json:"banner_list`
	LuckyList []IndexLuckyResp `json:"lucky_list`
	GoodsList []GoodsSummaryResp `json:"goodsList`
}

// 商品详情
type GoodsDetailRespInfo struct {
	Status int    `json:"status"`						// 1-夺宝进行中; 2-揭晓倒计时中 ; 3-已揭晓
	Period int64  `json:"period"`						// 期号
	Tips   string `json:"tips"`							// 夺宝提示(可不要?)
	StartTime int64 `json:"start_time"`				    // 开始时间
	PublishTime int64  `json:"publish_time"`			// 中奖揭晓时间，揭晓倒计时用
	Goods GoodsSummaryResp `json:"goods"` 				// 商品概要描述
	LuckyInfo DuobaoLuckyInfo `json:"lucky_info"`    	// 商品概要描述
	JoinedInfo MyJoinedInfo `json:"my_joined_info"`  	// 商品概要描述
	goodsDesc GoodsDetail `json:"goods_desc"` 		 	// 商品详细
	Records DuobaoRecords `json:"records"` 				// 商品详细
	PreRecords PreDuobaoRecords `json:"previous"` 		// 往期揭晓夺宝记录	
}