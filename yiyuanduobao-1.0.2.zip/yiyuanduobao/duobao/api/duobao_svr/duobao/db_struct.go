//mysql 表结构映射对应的结构体

package duobao

import (
	//"database/sql"
	//"encoding/json"
	//"time"
)


//定义DB用户数据表结构
type UserInfoDb struct {
	UserId        int64   `db:"user_id"`
	Password      string  `db:"password"`
	PartCode      string  `db:"part_code"`
	Nickname      string  `db:"nick_name"`
	Gender        string  `db:"gender"`
	AvatarPath    string  `db:"avatar"`
	MobileOrOpenId string `db:"mobile_or_openid"`
	RegDevice	  string   `db:"reg_device"`
	LastLoginIP   string   `db:"user_ip"`
	AddrDefaultCode int    `db:"addr_default_code"`
	AddrDeliveryCode int   `db:"addr_delivery_code"`
	PlatformName  string   `db:"plateform_reg"` 		
	UserType         int   `db:"user_type"`
	CreatedAt      int64   `db:"created_at"`
}

// 用户Token信息
type UserTokenInfo struct {
	UserId    int64 `db:"user_id"`
	CurToken  string `db:"cur_token"`
	TokenUpdatedAt int64 `db:"token_updated_at"`
	PreToken  string `db:"pre_token"`
	PreTokenExpired int64 `db:"pre_token_expired"`
}

// 合作方信息
type PartnerDb struct {
	PartCode    string 	`db:"part_code"`
	Name  		string 	`db:"name"`
	Proportion 	float32 `db:"proportion"` // 分成比例
	CreatedAt   int64  	`db:"created_at"`
}

// 商品概要信息
type GoodsInfoDb struct {
	GoodsId   	int64  `db:"goods_id"`
	Price    	int64  `db:"price"`
	CategoryId 	int    `db:"category_id"`
	BrandId    	int    `db:"brand_id"`
	CidList  	string `db:"cid_list"`
	Title  		string `db:"title"`
	SubTitle  	string `db:"sub_title"`
	Keywords  	string `db:"keywords"`
	ImageUrl    string `db:"image_url"`
	Description string `db:"description"`
	CreatedAt   int64  `db:"created_at"`
}

// 商品图文
type GoodsMediaDb struct {
	ContentId   int64  `db:"content_id"`
	GoodsId   	int64  `db:"goods_id"`
	MediaType  	string `db:"type"`
	Content  	string `db:"content"`
	CreatedAt   int64  `db:"created_at"`
}

// 汇总订单
type SumOrderDb struct {
	OrderNo   	 string `db:"order_no"`
	UserId    	 int64 	`db:"user_id"`
	SubOrderList string `db:"sub_order_list"`
	Amount   	 int64  `db:"amount"`
	Status   	 int  	`db:"status"`  // 订单状态(0未付款，1已付款)
	CreatedAt    int64  `db:"created_at"`
}

// 子订单
type SubOrderDb struct {
	OrderNo  	string 	`db:"order_no"`
	GoodsId  	int64  	`db:"goods_id"`
	UserId		int64 	`db:"user_id"`
	Period   	int64  	`db:"period"`
	BuyTotal   	int64  	`db:"buy_total"`
	Amount   	int64  	`db:"amount"`
	CreatedAt   int64  	`db:"created_at"`
}

// 子订单分配号码详细
type OrderDetailDb struct {
	OrderNo  	string 	`db:"order_no"`
	UserId		int64 	`db:"user_id"`
	AllCode   	int64  	`db:"all_code"`
}

// 一期夺宝活动
type DuobaoInfoDb struct {
	Period   	int64   `db:"period"`
	Status 		int    	`db:"active_status"` // 夺宝活动状态(1-买入中,2-正在揭晓,3-已揭晓)
	GoodsId   	int64  	`db:"goods_id"`
	Title  		string 	`db:"title"`
	Price    	int64  	`db:"price"`
	NeedTotal   int64  	`db:"need_total"`
	JoinedNum   int64  	`db:"joined_num"`
	RemainNum   int64  	`db:"remain_num"`
	BuyUnit   	int  	`db:"buy_unit"`
	LuckyNo   	string  `db:"lucky_no"`
	LuckyGuy   	int64  	`db:"lucky_guy"`
	ShowTag   	string  `db:"show_tag"`
	CreatedAt   int64  	`db:"created_at"`
	PublishAt   int64 	`db:"publish_at"`    // 揭晓时间
}

// 清单
type CartDb struct {
	UserId		int64 	`db:"user_id"`
	Period   	int64  	`db:"period"`
	CreatedAt   int64  	`db:"created_at"`
}

// 联系客服信息
type MessageDb struct {
	Id			int64 	`db:"id"`
	UserId		int64 	`db:"user_id"`
	Content		int64 	`db:"content"`
	Status   	int  	`db:"status"`  // 信息状态(-1发送失败;0成功)
	Sent_at     int64  	`db:"sent_at"`
}

// 用户地址信息
type AddrListDb struct {
	UserId		int64 	`db:"user_id"`
	Code		int 	`db:"code"`
	address   	string  `db:"address"`  
}

// banner
type BannerConfDb struct {
	Id		  int64   `db:"id"`
	ImageUrl  string  `db:"image_url"`  
	RefUrl    string  `db:"ref_url"`
}
