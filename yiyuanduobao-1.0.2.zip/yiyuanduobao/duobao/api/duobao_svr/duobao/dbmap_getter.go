package duobao

import (
	"github.com/coopernurse/gorp"		
	//"github.com/alecthomas/log4go"
)

/*
 * 获取user表的db操作对象
 */
func (o *APIHandler) GetUserDBMap() (*gorp.DbMap, string) {
	tableName := "idb_users" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(UserInfoDb{}, tableName).SetKeys(true, "user_id")
	return dbmap, tableName
}

/*
 * 获取商品表的db操作对象
 */
func (o *APIHandler) GetGoodsDBMap() (*gorp.DbMap, string) {
	tableName := "idb_goods" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(GoodsInfoDb{}, tableName).SetKeys(true, "goods_id")
	return dbmap, tableName
}

/*
 * 获取商品数据表操作对象
 */
func (o *APIHandler) GetGoodsDataDBMap() (*gorp.DbMap, string) {
	tableName := "idb_goods_data" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(GoodsMediaDb{}, tableName).SetKeys(true, "content_id")
	return dbmap, tableName
}

/*
 * 获取一期夺宝活动表的db操作对象
 */
func (o *APIHandler) GetDuobaoDBMap() (*gorp.DbMap, string) {
	tableName := "idb_duobao" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(DuobaoInfoDb{}, tableName).SetKeys(true, "period")
	return dbmap, tableName
}

/*
 * 获取banner db操作对象
 */
func (o *APIHandler) GetBannerDBMap() (*gorp.DbMap, string) {
	tableName := "idb_banner_config" 
	dbmap := &gorp.DbMap{Db: o.duobaoDB, Dialect: gorp.MySQLDialect{"InnoDB", "UTF8"}}
	dbmap.AddTableWithName(BannerConfDb{}, tableName).SetKeys(true, "id")
	return dbmap, tableName
}
