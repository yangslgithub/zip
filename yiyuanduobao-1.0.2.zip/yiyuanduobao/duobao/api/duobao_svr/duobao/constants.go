package duobao

const (
	//错误码定义
	RET_OK                     = 0
	RET_TOKEN_INVALID		= 101
	RET_TOKEN_EXPIRED		= 102
	RET_PARAM_INVALID		= 103
	RET_PARAM_MISSING 		= 104
	RET_NOT_LOGIN			= 105
	RET_REQUEST_TOO_FREQUENT   = 106
	RET_MOBILE_NUM_EXISTS		= 107
	RET_USER_OR_PASSWD_WRONG 	= 108
	RET_USER_NOT_EXISTS		= 109
	RET_SIG_CHECK_FAILED	= 110
	RET_THREAD_NOT_EXISTS	= 111
	RET_SPAWN_TEXT			= 120
	RET_ROUTE_NOT_FOUND 	= 404
	RET_INTERNAL_ERROR		= 500

	RET_CUSTOM_MSG = 199 // App直接显示Msg字段对应的错误描述

	RET_SMSCODE_INCORRECT = 9
	RET_FOLLOW_FAILED = 2
	RET_UNFOLLOW_FAILED = 2 
	RET_AUDIT_FAILED = 2  // 作品审核不通过
	RET_PUB_DELETED = 3  // 作品被作者删除
	RET_GENERAL_FAILED = 2

	RET_HAVE_DONE = 2
	

	MSG_OK = "OK"
	MSG_TOKEN_INVALID = "Token Invalid"
	MSG_TOKEN_EXPIRED = "Token Expired"
	MSG_PARAM_INVALID = "Parameters Invalid"
	MSG_PARAM_MISSING = "Parameters missing"
	MSG_NOT_LOGIN = "Not Login"
	MSG_REQ_TOO_FREQUENT = "Request too frequently"
	MSG_MOBILE_NUM_EXISTS = "Mobile number exists"
	MSG_USER_OR_PASSWD_WRONG = "Mobile or password incorrect"
	MSG_USER_NOT_EXISTS = "User not exists"
	MSG_SIG_CHECK_FAILED = "Signature check failed"
	MSG_THREAD_NOT_EXISTS = "Thread not exists"
	MSG_SPAWN_TEXT = "It is spawn message"

	MSG_ROUTE_NOT_FOUND = "Request URL route not found"
	MSG_INTERNAL_ERROR = "Internal Error"

	MSG_SMSCODE_INCORRECT = "Incorrect Verification Code"
	MSG_FOLLOW_FAILED = "Follow failed"
	MSG_UNFOLLOW_FAILED = "Unfollow failed"
	MSG_AUDIT_FAILED = "Audit failed"
	MSG_PUB_DELETED = "Pub Deleted"
	MSG_GENERAL_FAILED = "Failed"
	MSG_HAS_DONE = "You have done this operation"
	MSG_USER_HAS_BEEN_MUZZLED = "您已被禁言！"

	MSG_TYPE_FOLLOW_SOMEONE = 4


	SMS_CODE_EXPIRE_IN_SECONDS = 600
	SEND_SMS_CODE_INTERVAL_MIN = 60  // min interval (in seconds) to send sms code to same mobile phone again

	//错误提示
	TIME_FORMAT      = "2006-01-02 15:04:05"

	// Token有效期
	USER_TOKEN_VALID_DURATION = 300   // in seconds


	//存储redis数据的前缀
	//TOKEN_KEY_FLAG  = "token_"
	//COOKIE_KEY_FLAG = "cookie_"

	HAVED_TURN = 1
	TURE       = "1"

	//appid定义
	APPID_SDK           = "sdk"
	APPID_SKYPIXEL      = "skypixel"
	APPID_DIRECT_CREATE = "direct_create"
	APPID_NOWEB_CREATE  = "noweb_create"


	SMS_TMPL_1011 = "尊敬的%s, 系统已为您推荐了飞手%s, 快去看看吧 %s"
	SMS_TMPL_1012 = "尊敬的%s, 飞手%s已接受了订单,赶紧去勾搭飞手吧！ ~%s"
	SMS_TMPL_1013 = "尊敬的%s, 飞手已经接受航拍订单%s中的定金，您放心，一切妥妥哒! ~%s"
	SMS_TMPL_1014 = "尊敬的%s, 飞手已经确认完成了航拍内容，请您到App中确认交付完成，方便系统将尾款打给飞手。%s"
	SMS_TMPL_1015 = "尊敬的%s, 航拍订单%s超过了12小时。%s"
	SMS_TMPL_1016 = "亲, 系统给您分配了航拍订单%s, 生意上门了，快去看看吧! ~%s"
	SMS_TMPL_1017 = "亲, 航拍订单%s订金已支付, 快去看看吧! ~%s"
	SMS_TMPL_1018 = "亲, 系统给您分配的航拍订单%s一直处于未接单状态。 超过12小时未接单，买家可能取消订单！快去接单 %s"
	SMS_TMPL_1019 = "亲，%s月快来了，请更新可接单日期，让%s月的订单来得更猛吧! %s"		
	SMS_TMPL_1020 = "亲，航拍订单%s尾款已经打入您的帐户，金额到位后去给买家打个评价呗~%s"


	PUBLIST_LATEST_MAX_CACHE_NUM = 200
	PUBLIST_CACHE_TIME_DEFAULT = 1800
	PUBLIST_CACHE_TIME_LONGER = 2700

	//缓存键值
	CACHE_KEY_PUB_LATEST_HIS_PREFIX = "pub_latest_ver_"
	CACHE_KEY_PUB_LATEST_CUR_KEY = "pub_latest_cur_key"
	CACHE_KEY_PUBLIST_DB_LAST_MODIFIED = "publist_db_last_modified"
	CACHE_KEY_PUB_LATEST_CACHE_UPDATED = "pub_latest_cache_updated"
	CACHE_KEY_DEVICE_HIS_KEY_PREFIX = "cache_by_"

	REDIS_PUSH_MSG_KEY = "push_message"
	REDIS_NEW_PUSH_MSGQ = "push_msgq_v13"	


	//周期内是否已经发送过告警邮件
	HAVE_SEND_EMAIL = 1
	
	// 用户用积分兑换优惠码操作
	OP_EXCHANGE_PROMO_CODE = "op_exchange_promo_code"
	QBOX_ACCESS_KEY = "9q0XfvLm7AGuN7S-Ngeg-nemCv5mpSTgwpsFEXi4"
	QBOX_SECRET_KEY = "Ttvi__Ny80onP9L6NaBXmL5iYT3ZVPzipepL-Dch"
)
