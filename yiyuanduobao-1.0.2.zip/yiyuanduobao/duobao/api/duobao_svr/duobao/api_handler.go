package duobao

import (
	"github.com/garyburd/redigo/redis"
	//"bytes"
	"database/sql"
	//"encoding/json"
	//"io/ioutil"
	//"errors"
	"fmt"
	"github.com/alecthomas/log4go"
	"github.com/coopernurse/gorp"
	_ "github.com/go-sql-driver/mysql"
	"crypto/md5"
	"log"
	"net/http"
	//"net/url"
	"math/rand"
	"strconv"
	"strings"
	"sync"
	"time"
)


//
type APIHandler struct {
	sc           *ServerConfig
	duobaoDB    *sql.DB
	AccountDBMap *gorp.DbMap
	RedisPool    *redis.Pool
	//report       *itil.RequestCounter
	WaringMap    map[string]int
	lock         sync.Mutex
}

//创建一个新的Handler
func NewApiHandler(sc *ServerConfig) (*APIHandler, error) {
	duobaoDB, err := sql.Open("mysql", sc.DBServer)
	if err != nil {
		log4go.Error("open db %s failed, err=%s", sc.DBServer, err.Error())
		log.Fatalf("open db %s failed, err=%s", sc.DBServer, err.Error())
	}

	//设置最大连接数
	duobaoDB.SetMaxIdleConns(sc.MySqlPoolCnt)

	h := new(APIHandler)
	if len(sc.Redis) > 0 {
		//只使用第一个redis
 		h.RedisPool = redis.NewPool(func() (redis.Conn, error) {
			c, err := redis.Dial("tcp", fmt.Sprintf("%s:%d", sc.Redis[0].Ip, sc.Redis[0].Port))
			if err != nil {
				errMsg := fmt.Sprintf("connect redis server [%s:%d] failed, errMsg: %s\n", sc.Redis[0].Ip, sc.Redis[0].Port, err)
				log4go.Error(errMsg)
				return nil, err
			}

			return c, err
		}, sc.RedisPoolcnt)

		log4go.Info("Connect redis-server [%s:%d] success.\n", sc.Redis[0].Ip, sc.Redis[0].Port)
	}

	h.sc = sc
	h.duobaoDB = duobaoDB
	h.WaringMap = make(map[string]int, 10)

	h.InitTable()

	rand.Seed(time.Now().UnixNano())

	go h.ResetWaringMap()

	return h, nil
}

//关闭连接
func (o *APIHandler) Close() {
	if o.duobaoDB != nil {
		o.duobaoDB.Close()
	}
}

//初始化数据库表
func (o *APIHandler) InitTable() {
	//o.GetUserProductDBMap().CreateTablesIfNotExists()
}


//用于避免发送告警邮件,周期内同样的错误只发送一次
func (o *APIHandler) ResetWaringMap() {
	for {
		select {
		case <-time.After(time.Minute * o.sc.SendEmailInterval):
			o.lock.Lock()
			o.WaringMap = map[string]int{}
			o.lock.Unlock()
		}
	}
}

//兼容API的路由
func (o *APIHandler) Handle(w http.ResponseWriter, r *http.Request, sequence uint64) string {
	//TODO: 同一用户,同一IP的频率请求限制
	log4go.Info("Api_handler handle request [route:%s][remoteip:%s]", r.URL.Path, GetClientIpAddr(r))

	w.Header().Set("Content-Type", "application/json")

	w.Header().Set("Access-Control-Allow-Headers", "User-Token,Os,App-Ver,Device-Id,Os-Ver,Screen,Content-Type,Network")
	w.Header().Set("Access-Control-Allow-Origin", o.sc.WebPubUrl)
	w.Header().Set("Access-Control-Allow-Credentials", "true")

	header := new(ReqHeader)
	respStr := parseCommonHeaders(header, r)
	if respStr != "" {
		return respStr
	}
	
	//增加cookie登录判断，有cookie就在报头记录user_token
	if header.Header.Os == "web" {
		//o.verityCookieLogin(header, r)
	}

	var result string
	st := time.Now()
	switch r.URL.Path {
	case "/api/accounts/find_sms_code":
		// 取回验证码
		//result, _ = o.SendSMSCode(r, &header.Header, sequence)
		log4go.Debug("handle route [%s] request ", r.URL.Path)
	case "/api/accounts/send_sms_text":
		// 取回验证码
		//result, _ = o.SendSMSText(r, &header.Header, sequence)
	case "/api/accounts/check_sms_code":
		// 检查验证码
		//result, _ = o.CheckSmsCode(r, &header.Header, sequence)	
	case "/api/get_user_by_id":
		result, _ = o.GetUsrInfo(r, &header.Header, sequence)
	case "/api/index": // 首页
		result, _ = o.GetIndexInfo(r, &header.Header, sequence)	
	case "/api/goods_detail":
		result, _ = o.GetIndexInfo(r, &header.Header, sequence)				
		
	default:
		var notfound  ResponseInfo 
		notfound.Code =  RET_ROUTE_NOT_FOUND 
		notfound.Msg = MSG_ROUTE_NOT_FOUND 
		result = formatJson(notfound)
		log4go.Error("Request route '%s' not found!", r.URL.Path)
	}
	et := time.Now()
	consuming := (et.UnixNano() - st.UnixNano()) / (1000 * 1000)
	log4go.Trace("handle route [%s] request , timeConsumed= %d ms", r.URL.Path, consuming)

	//根据耗时阀值判断是否需要发送邮件进行告警
	if consuming >= (o.sc.WaringHighwater * 1000) {
		_, exist := o.WaringMap[r.URL.Path]
		if !exist {
			o.WaringMap[r.URL.Path] = HAVE_SEND_EMAIL
			log4go.Warn("DoSendWaringEmail %s consuming time %d ms", r.URL.Path, consuming)
			//go DoSendWaringEmail(r.URL.Path, o.sc.Env, consuming, o.sc.WaringEmailList)
		}
	}
	return result
}


func parseCommonHeaders(header *ReqHeader, r *http.Request) (string) {
	header.Header.UserToken = r.Header.Get("User-Token")
	header.Header.DeviceId = r.Header.Get("Device-Id")
	header.Header.AppVer = r.Header.Get("App-Ver")
	header.Header.Os = r.Header.Get("Os")
	header.Header.OsVersion = r.Header.Get("OsVersion")
	header.Header.Screen = r.Header.Get("Screen")
	header.Header.Network = r.Header.Get("Network")

	// 修正, 有的版本传入的是"1920*1080"这样的屏幕尺寸
	header.Header.Screen = strings.Replace(header.Header.Screen, "*", "x", 1)


	log4go.Info("Request [%s] header info: User-Token=%s, Device-Id=%s, App-Ver=%s, Os=%s, OsVersion=%s, Screen=%s, Network=%s", 
		r.URL.Path, header.Header.UserToken, header.Header.DeviceId, header.Header.AppVer, header.Header.Os, 
		header.Header.OsVersion, header.Header.Screen, header.Header.Network)	

	if header.Header.DeviceId == "" || header.Header.AppVer == "" {
		log4go.Warn("Device-Id or App-Ver not found in http headers!") 
		var resp ResponseInfo
		resp.Code = RET_PARAM_MISSING
		resp.Msg = MSG_PARAM_MISSING
		//return formatJson(resp)				
	}	
	if versionCompare(header.Header.AppVer, "1.4") >= 0 && header.Header.Network == "" {
		log4go.Warn("'Network' not found in http headers!") 		
	}

	return ""
} 

//进行请求次数上报
func (o *APIHandler) RequestReport(key string, state int) {
/*
	stamp := time.Now().Unix()
	info := o.report.AddCount(key, 1, stamp, (state == RET_OK))
	// 周期内错误数超过阀值,发送邮件告警
	if info.Failed >= o.sc.ErrorHighwater {
		_, exist := o.WaringMap[key]
		if !exist {
			o.WaringMap[key] = HAVE_SEND_EMAIL
			errmsg := fmt.Sprintf("function [%s] occur %d times error at %s. ",
				key, info.Failed, time.Now().Format(TIME_FORMAT))
			log4go.Error("DoSendErrorEmail %s", errmsg)
			go DoSendErrorEmail(key, o.sc.Env, errmsg, o.sc.WaringEmailList)
		}
	}
*/
}


func (o *APIHandler) readCachedVerifyCodeByMobile(mobile string) (string, int64) {
	redisConn := o.RedisPool.Get()
	defer redisConn.Close()
	codeAndGetTime, err := redis.String(redisConn.Do("GET", mobile))
	if err != nil {
		log4go.Error("readCachedVerifyCodeByMobile() read redis '%s' error [ %s ]", mobile, err)
		return "", 0
	}	
	//codeAndGetTime, _ := o.RedisClient.Get(mobile)
	if len(codeAndGetTime) == 0 {
		return "", 0
	}

	subFields := strings.Split(codeAndGetTime, "-")
	if len(subFields) < 2 {
		return "", 0
	}

	getTime := subFields[1]
	unxTime, err := strconv.Atoi(getTime)
	if err != nil {
		return "", 0
	}

	return subFields[0], int64(unxTime)
}

// 检查用户验证码是否正确
func (o *APIHandler) CheckSmsCode(r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {
	mobile := SafeParams(r, "mobile")
	verify_code := SafeParams(r, "verify_code")	
	log4go.Info("CheckSmsCode(): mobile=%s, verify_code=%s", mobile, verify_code)

	var result ResponseInfo
	if len(mobile) < 11 {
		result.Code = RET_PARAM_INVALID 
		result.Msg = MSG_PARAM_INVALID 
		log4go.Error("CheckSmsCode failed, invalid mobile number: %s", mobile)
		return formatJson(result), nil
	}

	// 检查验证码是否正确(从redis读取)
	mobileKey := fmt.Sprintf("smscode-%s",mobile)
	lastCode, _ := o.readCachedVerifyCodeByMobile(mobileKey)
	if 	lastCode != verify_code {
		result.Code = RET_SMSCODE_INCORRECT
		result.Msg = MSG_SMSCODE_INCORRECT
		log4go.Error("CheckSmsCode failed, request verify code is '%s', but cached sms code is '%s'", verify_code, lastCode) 
		return formatJson(result), nil
	}

	result.Code = RET_OK
	result.Msg = MSG_OK
	log4go.Info("CheckSmsCode() OK, mobile=%s", mobile)
	return formatJson(result),nil
}


// 用户注册

func genInitNickname(mobile string) string{
	nlen := len(mobile)

	return mobile[0:nlen-8] + "****" + mobile[nlen-4:]
}

type tokenPair struct {
	token string `db:"cur_token"`
	updatedAt time.Time `db:"token_updated_at"`
}


func setLoginCookie(w http.ResponseWriter, user_id int64) string {
	if user_id < 0 {
		log4go.Error("setLoginCookie failed.user_id err.")
		return ""
	}

	//存入保持登录的cookie
	expire := time.Now().Add(6 * time.Hour)
	time_unix := expire.Unix()
	secret_key := "ihangpai!@#"
	user_id_str := fmt.Sprintf("%d", user_id)
	time_unix_str := fmt.Sprintf("%d", time_unix)
	//加密
	salt := user_id_str + time_unix_str + secret_key
	salt = calcDescMd5(salt)
	user_verify := user_id_str + "-" + time_unix_str + "-" + salt;
	//user_verify_cookie := http.Cookie{Name: "user_verify", Value: user_verify, Domain: ".52hangpai.cn", Path: "/", Expires: expire, MaxAge: 86400}
	user_verify_cookie := http.Cookie{Name: "user_verify", Value: user_verify, Domain: ".52hangpai.cn", Path: "/"}
	http.SetCookie(w, &user_verify_cookie)
	
	return user_verify
}

func genUserToken(user_id int64) string {
	srcStr := fmt.Sprintf("[%d-%d][ihp-token]", user_id, time.Now().UnixNano())
	return fmt.Sprintf("%x", md5.Sum([]byte(srcStr)))
}


func calcDescMd5(descText string) string {
	return fmt.Sprintf("%x", md5.Sum([]byte(descText)))
}