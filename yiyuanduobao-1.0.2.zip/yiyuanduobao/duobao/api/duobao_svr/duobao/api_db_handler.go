package duobao

import (
	"errors"
	//"strings"
	"database/sql"
	//"errors"
	"fmt"
	"github.com/alecthomas/log4go"
	//"github.com/coopernurse/gorp"
	_ "github.com/go-sql-driver/mysql"
	//"crypto/md5"
	//"log"
	//"net/http"
	//"net/url"
	//"math/rand"
	//"strconv"
	//"strings"
	//"sync"
	//"time"
)

// 通过id获取用户信息
func (o *APIHandler) GetUsrInfoById(userID int64) (*UserInfoDb, error) {
	dbMap, tableName := o.GetUserDBMap()
	log4go.Debug("GetUsrInfoById() called userID:%d", userID)

	sqlQuery := fmt.Sprintf(`SELECT part_code, nick_name, gender, avatar, mobile_or_openid, reg_device, user_ip, addr_default_code, 
		addr_delivery_code, plateform_reg, user_type, created_at FROM %s WHERE user_id = ? limit 1`, tableName)
	var UserInfo UserInfoDb
	err := dbMap.SelectOne(&UserInfo, sqlQuery, userID)		
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Warn("GetUsrInfoById(): can't find user info of userID [ %d ]", userID)
			return nil, err			
		}else{
			log4go.Error("GetUsrInfoById(%d): query db error [ %s ]", userID, err)
			return nil, err			
		}
	}
	return &UserInfo, nil		
}

// 获取单个商品信息
func (o *APIHandler) GetGoodsInfoByIdDb(goodsId int64) (*GoodsInfoDb, error) {
	dbMap, tableName := o.GetGoodsDBMap()
	log4go.Debug("GetGoodsInfoByIdDb() ...... goodsId:%d", goodsId)

	sqlQuery := fmt.Sprintf(`SELECT goods_id, price, category_id, brand_id, cid_list, title, sub_title,
		keywords, image_url, description, created_at FROM %s WHERE goods_id=?`, tableName)
	var goods GoodsInfoDb
	err := dbMap.SelectOne(&goods, sqlQuery, goodsId)
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Warn("GetGoodsInfoByIdDb(): can't find goods by goodsId [%d]", goodsId)
			return nil, nil
		}else {
			log4go.Error("GetGoodsInfoByIdDb(): query db error [ %s ]", err)
			return nil, err
		}
	}	
	return &goods, nil		
}

// 获取商品详细信息
func (o *APIHandler) GetGoodsDataByIdDb(goodsId int64) ([]GoodsMediaDb, error) {
	dbMap, tableName := o.GetGoodsDataDBMap()	
	log4go.Debug("GetGoodsDataByIdDb() goodsId = %d", goodsId)

	sqlQuery := fmt.Sprintf(`SELECT content_id, goods_id, type, content, created_at FROM %s WHERE goods_id = %d `, tableName, goodsId)
	var goodsData []GoodsMediaDb
	_, err := dbMap.Select(&goodsData, sqlQuery)
	if err != nil {
		log4go.Error("GetGoodsDataByIdDb() error:  %s", err)
		return nil, err
	}
	return goodsData, nil		
}

// 获取商品信息(通过id批量)
func (o *APIHandler) GetGoodsInfoByIdsDb(goodsIds []int64) ([]GoodsInfoDb, error) {
	dbMap, tableName := o.GetGoodsDBMap()
	log4go.Debug("GetGoodsInfoByIdsDb() ......")
	
	inSQL := Int64List2InSQL(goodsIds)
	log4go.Debug("GetGoodsInfoByIdsDb() goodsIds = [%s]", inSQL)

	sqlQuery := fmt.Sprintf(`SELECT goods_id, price, category_id, brand_id, cid_list, title, sub_title,
		keywords, image_url, description, created_at FROM %s WHERE goods_id in (%s)`, tableName, inSQL)
	var goodsList []GoodsInfoDb
	_, err := dbMap.Select(&goodsList, sqlQuery)
	if err != nil {
		log4go.Error("GetGoodsInfoByIdsDb() error:  %s", err)
		return nil, err
	}
	return goodsList, nil		
}

// 获取首页banner信息
func (o *APIHandler) GetBannerListDb() ([]BannerConfDb, error) {
	dbMap, tableName := o.GetBannerDBMap()
	log4go.Debug("GetBannerList() ......")

	sqlQuery := fmt.Sprintf(`SELECT id, image_url, ref_url FROM %s `, tableName)
	var bannerList []BannerConfDb
	_, err := dbMap.Select(&bannerList, sqlQuery)
	if err != nil {
		log4go.Error("GetBannerList() error:  %s", err)
		return nil, err
	}
	return bannerList, nil		
}

// 获取首页商品夺宝信息
func (o *APIHandler) GetIndexDuobaoListDb() ([]DuobaoInfoDb, error) {
	dbMap, tableName := o.GetDuobaoDBMap()
	log4go.Debug("GetIndexDuobaoListDb() ......")

	// 选择正在进行中的夺宝活动
	sqlQuery := fmt.Sprintf(`SELECT period, active_status, goods_id, title, price, need_total, joined_num, 
		remain_num, buy_unit, show_tag, created_at FROM %s WHERE active_status=1`, tableName)
	var duobaoList []DuobaoInfoDb
	_, err := dbMap.Select(&duobaoList, sqlQuery)
	if err != nil {
		log4go.Error("GetIndexDuobaoListDb() error:  %s", err)
		return nil, err
	}
	
	return duobaoList, nil		
}

// 获取首页中奖通知列表
func (o *APIHandler) GetIndexLuckyListDb() ([]DuobaoInfoDb, error) {
	dbMap, tableName := o.GetDuobaoDBMap()
	log4go.Debug("GetIndexLuckyListDb() ......")

	// 选择已经揭晓的夺宝，并按最新揭晓时间排序
	sqlQuery := fmt.Sprintf(`SELECT period, goods_id, title, lucky_no, lucky_guy FROM %s 
		WHERE active_status=3  ORDER BY publish_at DESC LIMIT 20`, tableName)
	var duobaoList []DuobaoInfoDb
	_, err := dbMap.Select(&duobaoList, sqlQuery)
	if err != nil {
		log4go.Error("GetIndexDuobaoListDb() error:  %s", err)
		return nil, err
	}	
	return duobaoList, nil		
}

// 根据id获取商品夺宝信息
func (o *APIHandler) GetDuobaoInfoByPeriodDb(period int64) (*DuobaoInfoDb, error) {
	log4go.Debug("GetDuobaoInfoByPeriodDb() ......")
	if period <= 0 {
		return nil, errors.New(fmt.Sprintf("parameter period is error!"))
	}
	
	dbMap, tableName := o.GetDuobaoDBMap()	
	// 选择正在进行中的夺宝活动
	sqlQuery := fmt.Sprintf(`SELECT period, active_status, goods_id, title, price, need_total, joined_num, 
		remain_num, buy_unit, show_tag, created_at FROM %s WHERE period=?`, tableName)
	var duobao DuobaoInfoDb
	err := dbMap.SelectOne(&duobao, sqlQuery, period)
	if err != nil {
		if err == sql.ErrNoRows {
			log4go.Warn("GetDuobaoInfoByPeriodDb(): can't find duobao by period [%d]", period)
			return nil, nil
		}else {
			log4go.Error("GetDuobaoInfoByPeriodDb(): query db error [ %s ]", err)
			return nil, err
		}
	}
	return &duobao, nil		
}


// 根据商品id获取商品夺宝信息
func (o *APIHandler) GetDuobaoListByGoodsIdDb(goodsId int64) ([]DuobaoInfoDb, error) {
	log4go.Debug("GetDuobaoListByGoodsIdDb() ......")
	if goodsId <= 0 {
		return nil, errors.New(fmt.Sprintf("parameter goodsId is error!"))
	}
	
	dbMap, tableName := o.GetDuobaoDBMap()	
	// 选择正在进行中的夺宝活动
	sqlQuery := fmt.Sprintf(`SELECT period, active_status, goods_id, title, price, need_total, joined_num, 
		remain_num, buy_unit, show_tag, created_at FROM %s WHERE goods_id=?`, tableName)
	var duobaoList []DuobaoInfoDb
	_, err := dbMap.Select(&duobaoList, sqlQuery, goodsId)
	if err != nil {
		log4go.Error("GetDuobaoListByGoodsIdDb() error:  %s", err)
		return nil, err
	}	
	return duobaoList, nil		
}