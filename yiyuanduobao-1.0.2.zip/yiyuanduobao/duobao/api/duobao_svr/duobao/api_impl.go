package duobao

import (
	"strconv"
	//"strings"
	//"errors"
	//"fmt"
	"github.com/alecthomas/log4go"
	//"github.com/coopernurse/gorp"
	//"log"
	"net/http"
	//"net/url"
	//"math/rand"
	//"strconv"
	//"strings"
	//"sync"
	//"time"
)


func (o *APIHandler) GetUsrInfo(r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {
	userInfo, err := o.GetUsrInfoById(1)
	if err != nil {
		log4go.Debug("GetUsrInfo() query db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), err
	}	
	log4go.Debug("GetUsrInfo() Nickname:%s", userInfo.Nickname)	

	var result ResponseInfo

	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = userInfo
	return formatJson(result),nil
}


func (o *APIHandler) GetIndexInfo(r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {	
	log4go.Debug("GetIndexInfo() ...... ")
	
	// banner 列表
	bannerList, err := o.GetBannerListDb()
	if err != nil {
		log4go.Error("GetIndexInfo() GetBannerListDb query db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), err
	}	
	
	var bannerResp []BannerResp
	for _, banner := range bannerList {
		item := BannerResp{ Id: banner.Id, Image:banner.ImageUrl, RefUrl:banner.RefUrl, } 
		bannerResp = append(bannerResp, item)
	}	
	
	// 夺宝商品列表
	duobaoList, err := o.GetIndexDuobaoListDb()
	if err != nil {
		log4go.Error("GetIndexInfo() GetIndexDuobaoListDb query db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), err
	}	
	log4go.Debug("GetIndexInfo() len(duobaoList): %d", len(duobaoList))
	
	mapId2Goods := make(map[int64]GoodsInfoDb)
	if len(duobaoList) > 0 {
		var ids []int64
		for _, duobao := range duobaoList {
			ids = append(ids, duobao.GoodsId)
		}
		goodsList, _:= o.GetGoodsInfoByIdsDb(ids)
		for _, good := range goodsList {
			mapId2Goods[good.GoodsId] = good
		}			
	}

	var GoodsResp []GoodsSummaryResp
	for _, duobao := range duobaoList {
		item := GoodsSummaryResp{ 
								Status: duobao.Status,
								Period:	duobao.Period,
								PublishTime: duobao.PublishAt,
								GoodId: duobao.GoodsId,
								GoodsName: duobao.Title,
								GoodsDesc: mapId2Goods[duobao.GoodsId].Description,
								BuyUnit: duobao.BuyUnit,
								TotalTimes: duobao.NeedTotal,
								RemainingTimes: duobao.RemainNum,
								coverImage: mapId2Goods[duobao.GoodsId].ImageUrl,
								ShowTag: duobao.ShowTag,
							} 
		GoodsResp = append(GoodsResp, item)
	}
		
	// 中奖消息列表
	luckyList, err := o.GetIndexLuckyListDb()
	if err != nil {
		log4go.Error("GetIndexInfo() GetIndexLuckyListDb query db ERROR!")
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } ), err
	}	
	var LuckyResp []IndexLuckyResp
	for _, lucky := range luckyList {
		item := IndexLuckyResp{UserId: lucky.LuckyGuy, GoodsName: lucky.Title, RefUrl: "",}
		LuckyResp = append(LuckyResp, item)
	}
	 
	var result ResponseInfo

	result.Code = RET_OK
	result.Msg = MSG_OK
	result.Data = IndexRespInfo{BannerList:bannerResp, LuckyList: LuckyResp, GoodsList: GoodsResp,}
	return formatJson(result),nil
}

func (o *APIHandler) GetGoodsDetail(r *http.Request, headers *CommonHeaders, sequence uint64) (string, error) {	
	log4go.Debug("GetGoodsDetail() ...... ")
	
	periodStr := r.FormValue("period")
	if len(periodStr) == 0 {
		log4go.Warn("GetGoodsDetail(): period param is empty!")
		return formatJson( ResponseInfo{ Code: RET_PARAM_MISSING, Msg: MSG_PARAM_MISSING } )			
	}
	
	period, err := strconv.ParseInt(periodStr, 10, 64)
	if err != nil {
		log4go.Warn("GetGoodsDetail(): period param is err! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_PARAM_INVALID, Msg: MSG_PARAM_INVALID } )			
	}
		
	// 此期夺宝信息	
	duobao, err := o.GetDuobaoInfoByPeriodDb(period)
	if err != nil {
		log4go.Warn("GetGoodsDetail(): GetDuobaoInfoByPeriodDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	// 商品信息
	goods, err := o.GetGoodsInfoByIdDb(duobao.GoodsId)
	if err != nil {
		log4go.Warn("GetGoodsDetail(): GetGoodsInfoByIdDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	// 商品图文详细
	goodsMedia, err := o.GetGoodsDataByIdDb(duobao.GoodsId)
	if err != nil {
		log4go.Warn("GetGoodsDetail(): GetGoodsDataByIdDb error! [errors: %s]", err)
		return formatJson( ResponseInfo{ Code: RET_INTERNAL_ERROR, Msg: MSG_INTERNAL_ERROR } )			
	}	
	
	// 夺宝参与记录
	
	// 往期揭晓夺宝
	oldDuobaoList, err := o.GetDuobaoListByGoodsIdDb(duobao.GoodsId)
	
	
	// 幸运用户信息(已揭晓状态)
	
	
	// 我参与夺宝信息(此期我参与过)
	
	
	//GoodsDetailRespInfo
	 
	var result ResponseInfo

	result.Code = RET_OK
	result.Msg = MSG_OK
	return formatJson(result),nil
}