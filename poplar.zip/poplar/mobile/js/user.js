(function($){
    var arg = request("arg"),addr = getCookie("addr_info");
    if (addr != null && addr != "null" && arg == "edit") {
        addr = JSON.parse(addr);
        $(".title_word").text("编辑地址");
        $("input[name=name]").val(addr.name);
        $("input[name=mobile]").val(addr.mobile);
        $(".city").addClass("hidden");
        $("textarea[name=address]").val(addr.address);
        if (addr.is_default == 1) {
            $("input[name=default]").attr("checked","checked");
        } else {
            $("input[name=default]").removeAttr("checked");
        }
    }
    $(".m-savebtn").bind(touchStart,function(){
        var user = getUser();
        if (user != "") {
            var is_default = $("input[name=default]").is(":checked") ? 1 : 0;
            var name = $("input[name=name]").val();
            var mobile = $("input[name=mobile]").val();
            var province = $("select[name=province]").find("option:selected").text();
            var city = $("select[name=city]").find("option:selected").text();
            var district = $("select[name=district]").find("option:selected").text();
            var pcd = province + city + district;
            var address = arg != "edit" ? (pcd + $("textarea[name=address]").val()) : "" + $("textarea[name=address]").val();
            var params = {
                addr_info : {
                    code : 0,
                    nick_name : name,
                    mobile: mobile,
                    address: address,
                    is_default : is_default,
                    signature : "add.addr"
                },
                heads : {
                    'Content-Type': 'application/json',
                    'User-Token' : user.token
                },
                url : "api/add_address"
            }
            if (arg == "edit") {
                params.url = "api/modify_address";
                params.addr_info.code = parseInt(addr.code);
                params.addr_info.signature = "edit.addr";
            }
            $.rigorAjax({url:params.url,data:params,heads:params.heads},function(data){
                if (data.code == 0) {
                    if (arg == "edit") {
                        delCookie("addr_info");
                    }
                    location.href = "../website/address.man.html";
                } else if (data.code == 105) {
                    location.href = "../website/login.html";
                    return;
                } else {
                    alert(data.msg);
                }
            });
        }
    });
    $(".sup_login_out").bind(touchStart,function(){
        window.delCookie("c_user");
        location.href = "../website/index.html";
    });
})($)