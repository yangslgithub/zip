(function($,win,doc){
    //console.log(doc.cookie);
    // pay radio
    $(".p-way").bind(touchStart,function(){
        $(".c-radio").removeClass("r-on");
        $(this).find(".c-radio").addClass("r-on");
    });
    var purchase = win.getCookie("purchase");
    if (purchase != null && typeof purchase != "undefined") {
        var c_user = win.getUser();
        if (c_user != "") {
            var r = {
                _setText : function(cls,val) {
                    $("."+cls).text(val);
                },
                heads : {
                    'Content-Type': 'application/json',
                    'User-Token' : c_user.token
                }
            }
            $.rigorAjax({
                url: 'api/settlement',
                data: JSON.parse(purchase),
                heads: r.heads
            }, function (data) {
                if (data.code != 0) {
                    alert(data.msg);
                    return;
                }
                r.order = data.data.order_info;
                r.count = 0;
                r.g_html = "";
                for (var i = 0; i < r.order.list.length; i++) {
                    var v = r.order.list[i];
                    r.g_html += '<p>' + v.gname + '<span class="txt-black ml15"><span class="pale-red">' + v.buy_total + '</span>人次</span></p>';
                    r.count++;
                }
                r._setText("count", r.count);
                r._setText("sup_amount", parseFloat(r.order.amount).toFixed(2));
                r._setText("sup_total", (parseFloat(r.order.sum_total).toFixed(2) + "元"));
                $(".g-item").html(r.g_html);
                if (global._iswx()) {
                    $(".pay_wx").removeClass("hidden");
                } else {
                    $(".pay_alipay").removeClass("hidden");
                    $(".c-radio").eq(1).trigger(touchStart);
                }
                var pay = function() {
                    var o = {
                        charge: {},
                        params: {
                            signature: 'confirm.pay',
                            amount: r.order.amount,
                            open_id: "",
                            charge_channel: "alipay_wap",
                            list: r.order.list
                        }
                    }
                    o.params.charge_channel = $(".r-on").attr("data-pro");
                    if(global._iswx()) {o.params.open_id = c_user.openid; }
                    var $this = $(this);
                    $this.unbind(touchStart).text('正在支付...');
                    $.rigorAjax({url: "api/order", data: o.params, heads: r.heads}, function (json) {
                        if (json.code == 0) {
                            o.charge = json.data.charge_obj;
                            pingpp.createPayment(o.charge, function (result, err) {
                                // 处理错误信息
                                if (result == "success") {
                                    location.href = "../website/order.details.html";
                                    win.delCookie("purchase");
                                } else {
                                    $this.bind(touchStart,pay).text('支付确认');
                                }
                            });
                        }
                    });
                }
                $("#p-submit").bind(touchStart, pay);
            });
        } else {
            location.href = '../website/login.html';
        }
    }
})($,window,document)