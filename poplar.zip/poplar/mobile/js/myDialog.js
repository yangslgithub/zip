(function(win){
    function tip(str,delay,callback) {
        var that = this;
        that.htmls = '<div data-role="widget-dialog" class="tip_dialog" id="tip_dialog" ontouchmove="return false;">'
            + '<div class="widget_mask"></div><div class="widget_info"><div class="widget_body">'+str+'</div></div></div>';
        that.widget = ".tip_dialog";
        $("body").append(that.htmls);
        win.setTimeout(function(){
            $(that.widget).remove();
            if (callback) callback();
        },delay);
        return that;
    }
    win._tip = function(str,delay,callback) { return tip(str,delay,callback) }
})(window);