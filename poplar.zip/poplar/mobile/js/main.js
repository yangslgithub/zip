/**
 *  @Author Poplar.Young
 * main.js common
 */
// jquery extend method
$.extend($.fn,{
    /*timeCountDown : function(d){
     this.each(function(){
     var $this = $(this);
     var o = {
     hm: $this.find(".hm"),
     sec: $this.find(".sec"),
     mini: $this.find(".mini"),
     hour: $this.find(".hour"),
     day: $this.find(".day"),
     month:$this.find(".month"),
     year: $this.find(".year")
     };
     var f = {
     haomiao: function(n){
     if(n < 10)return "00" + n.toString();
     if(n < 100)return "0" + n.toString();
     return n.toString();
     },
     zero: function(n){
     var _n = parseInt(n, 10);//解析字符串,返回整数
     if(_n > 0){
     if(_n <= 9){
     _n = "0" + _n
     }
     return String(_n);
     }else{
     return "00";
     }
     },
     dv: function(){
     //d = d || Date.UTC(2050, 0, 1); //如果未定义时间，则我们设定倒计时日期是2050年1月1日
     var _d = $this.data("end") || d;
     var now = new Date(),
     endDate = new Date(_d);
     //现在将来秒差值
     //alert(future.getTimezoneOffset());
     var dur = (endDate - now.getTime()) / 1000 , mss = endDate - now.getTime() ,pms = {
     hm:"00",
     sec: "00",
     mini: "00",
     hour: "00",
     day: "00",
     month: "00",
     year: "0"
     };
     if(mss > 0){
     pms.hm = f.haomiao(mss % 1000).toString().substring(0,2);
     pms.sec = f.zero(dur % 60);
     pms.mini = Math.floor((dur / 60)) > 0? f.zero(Math.floor((dur / 60)) % 60) : "00";
     pms.hour = Math.floor((dur / 3600)) > 0? f.zero(Math.floor((dur / 3600)) % 24) : "00";
     pms.day = Math.floor((dur / 86400)) > 0? f.zero(Math.floor((dur / 86400)) % 30) : "00";
     //月份，以实际平均每月秒数计算
     pms.month = Math.floor((dur / 2629744)) > 0? f.zero(Math.floor((dur / 2629744)) % 12) : "00";
     //年份，按按回归年365天5时48分46秒算
     pms.year = Math.floor((dur / 31556926)) > 0? Math.floor((dur / 31556926)) : "0";
     }else{
     pms.year=pms.month=pms.day=pms.hour=pms.mini=pms.sec="00";
     pms.hm = "00";
     return;
     }
     return pms;
     },
     ui: function(){
     if(o.hm){
     o.hm.html(f.dv().hm);
     }
     if(o.sec){
     o.sec.html(f.dv().sec);
     }
     if(o.mini){
     o.mini.html(f.dv().mini);
     }
     if(o.hour){
     o.hour.html(f.dv().hour);
     }
     if(o.day){
     o.day.html(f.dv().day);
     }
     if(o.month){
     o.month.html(f.dv().month);
     }
     if(o.year){
     o.year.html(f.dv().year);
     }
     setTimeout(f.ui, 1);
     }
     };
     if (!f.dv()) {
     $this.find("dd").html("中奖者是...")
     } else {
     f.ui();
     }
     });
     },*/
    countTimer : function() {
        var sec = $(this).attr("data-end"),sets = $(this);
        if (sec == "" || typeof sec == "undefined") return;
        setInterval(function(){
            if (sec < 0)
                $.postAjax({url:'api/publish_duobao'},function(){
                    setTimeout(function(){window.refresh();},1000);
                })
            else
                countTimer();
        },1000);
        var countTimer = function() {
            function zero(n) {
                var _n = parseInt(n, 10);
                if(_n > 0){
                    if(_n <= 9){
                        _n = "0" + _n
                    }
                    return String(_n);
                }else{
                    return "00";
                }
            }
            var _sec = zero(sec % 60), _mini = zero(sec / 60 % 60);
            sets.find(".mini").text(_mini);
            sets.find(".sec").text(_sec);
            sec = sec - 1;
            if (sec >= 0) {
                var _num = 0;
                var milli_timer = setInterval(function () {
                    _num = _num + 1;
                    if (_num >= 100) {
                        _num = 0;
                    }
                    sets.find(".hm").text(zero(_num));
                }, 10);
                setTimeout(function () { clearInterval(milli_timer); }, 1000);
            } else {
                sets.find(".hm").text("00");
            }
        }
    }
});
$.extend($,{
    swiperIndex : function() {
        var swiper = new Swiper('.swiper-container', {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            autoplay: 3000,
            autoplayDisableOnInteraction:false,
            spaceBetween: 0,// 图片间距
            height: 280,
            loop: true
        });
        window.addEventListener('orientationchange', function(event){
            if (window.orientation == 180 || window.orientation==0 || window.orientation == 90 || window.orientation==-90 ) {
                swiper.reInit();
            }
        });
    },
    swiperDetails : function() {
        var swiper = new Swiper('.swiper-container', {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            autoplay: 3000,
            autoplayDisableOnInteraction:false,
            spaceBetween: 0,// 图片间距
            height: 280,
            loop: true,
            bulletClass: "swiper-pagination-switch", //自定义
            bulletActiveClass: "swiper-pagination-active"
        });
        window.addEventListener('orientationchange', function(event){
            if (window.orientation == 180 || window.orientation==0 || window.orientation == 90 || window.orientation==-90 ) {
                swiper.reInit();
            }
        });
    },
    noticeTopic : function(obj) {
        var textUl = document.getElementById(obj);
        var textList = textUl.getElementsByTagName("li");
        if(textList.length > 2){
            var textDat = textUl.innerHTML;
            /*var br = textDat.toLowerCase().indexOf("<br",textDat.toLowerCase().indexOf("<br")+3);
             //var textUp2 = textDat.substr(0,br);
             textDiv.innerHTML = textDat+textDat+textDat.substr(0,br);*/
            textUl.style.cssText = "position:relative; top:0";
            var textDatH = textUl.offsetHeight;MaxRoll();
        }
        var minTime,maxTime,divTop,newTop=0;
        function MinRoll(){
            newTop++;
            if(newTop<=divTop+40){
                textUl.style.top = "-" + newTop + "px";
            }else{
                clearInterval(minTime);
                maxTime = setTimeout(MaxRoll,3000);
            }
        }
        function MaxRoll(){
            divTop = Math.abs(parseInt(textUl.style.top));
            if(divTop>=0 && divTop<textDatH-40){
                if (divTop == 0) {
                    setTimeout(function(){
                        minTime = setInterval(MinRoll,1);
                    },3000);
                } else {
                    minTime = setInterval(MinRoll,1);
                }
            }else{
                textUl.style.top = 0;divTop = 0;newTop=0;MaxRoll();
            }
        }
    },
    backTop : function(acceleration, time) {
        acceleration = acceleration || 0.1;
        time = time || 16;
        var x1 = 0,y1 = 0,x2 = 0,y2 = 0,x3 = 0,y3 = 0;
        if (document.documentElement) {
            x1 = document.documentElement.scrollLeft || 0;
            y1 = document.documentElement.scrollTop || 0;
        }
        if (document.body) {
            x2 = document.body.scrollLeft || 0;
            y2 = document.body.scrollTop || 0;
        }
        var x3 = window.scrollX || 0;
        var y3 = window.scrollY || 0;
        // 滚动条到页面顶部的水平距离
        var x = Math.max(x1, Math.max(x2, x3));
        // 滚动条到页面顶部的垂直距离
        var y = Math.max(y1, Math.max(y2, y3));
        // 滚动距离 = 目前距离 / 速度, 因为距离原来越小, 速度是大于 1 的数, 所以滚动距离会越来越小
        var speed = 1 + acceleration;
        window.scrollTo(Math.floor(x / speed), Math.floor(y / speed));
        // 如果距离不为零, 继续调用迭代本函数
        if (x > 0 || y > 0) {
            var invokeFunction = "$.backTop(" + acceleration + ", " + time + ")";
            window.setTimeout(invokeFunction, time);
        }
    },
    postAjax : function(opts,callback,headers){
        var defaults = {
            url : "",
            data : {}
        }
        // add user token
        if (typeof headers == "undefined") {
            var c_user = window.getUser();
            if (c_user != "") {
                headers = { 'User-Token': c_user.token }
            } else {
                headers = {}
            }
        }
        var settings = $.extend(defaults,opts);
        $.ajax({
            url: global._url + settings.url,
            cache: false,
            dataType: 'json',
            data: settings.data,
            type: "post",
            headers : headers,
            success: function (msgObj) {
                if ("object" != typeof msgObj) {
                    msgObj = JSON.parse(msgObj);
                }
                callback(msgObj);
            },
            error: function (requestObj, error_msg, exception) {
                console.error('post request An unknown error has occurred');
            }
        });
    },
    rigorAjax : function(opts,callback){
        var defaults = {
            url : "",
            data : {},
            heads : {}
        }
        var settings = $.extend(defaults,opts);
        $.ajax({
            url: global._url + settings.url,
            cache: false,
            dataType: 'json',
            type: 'post',
            data :  JSON.stringify(settings.data),
            headers : settings.heads,
            success: function (msgObj) {
                if ("object" != typeof msgObj) {
                    msgObj = JSON.parse(msgObj);
                }
                callback(msgObj);
            },
            error: function (requestObj, error_msg, exception) {
                alert('post请求出现未知错误。');
            }
        });
    }
});

var global = {
    _url : "http://tduobao.52hangpai.cn/",
    _title : "酷购一元夺宝",
    _iswx : function() {
        var ua = navigator.userAgent.toLowerCase();
        if(ua.match(/MicroMessenger/i)) {
            return true;
        } else {
            return false;
        }
    },
    _invalid : (((60 * 60) * 24) * 15)
}
var hasTouch = document.hasOwnProperty("ontouchstart"),
    touchStart = hasTouch ? 'touchstart' : 'mousedown',
    touchMove = hasTouch ? 'touchmove' : 'mousemove',
    touchEnd = hasTouch ? 'touchend' : 'mouseup';
(function($,win,doc){
    // login
    $("#login_in").bind(touchStart,function(){
        //validate()
        var u = {
            phone : $("input[name=phone]").val(),
            pass : $("input[name=password]").val(),
            encryPass : ""
        }
        u.encryPass = win.hex_md5(u.pass);
        $.postAjax({
            url : "api/accounts/login",
            data : {
                mobile : u.phone,
                passwd : u.encryPass
            }
        },function(res){
            console.dir(res);
            if (res.code == 0) {
                var info = { openid : "",token : res.data.token,num: res.data.cart_goods_num };
                win.setCookie("c_user",JSON.stringify(info));
                var p = confirm("login success！");
                if (p) {
                    var skip_url = getCookie("skip_url");
                    if (skip_url != "")
                        location.href = skip_url;
                    else
                        location.href = "../website/index.html";
                    delCookie("skip_url");
                }
            } else {
                alert(res.msg);
            }
        });
    });
    $("#login-wx").bind(touchStart,function(){
        var code = request("code");
        if (code == "" || !global._iswx()) {
            alert("请在微信浏览器里面操作");
        }
    });
    $("#login-qq").bind(touchStart,function(){
        location.href = "../website/login.transfer.html?part=qq";
    });
    var verifyCode = function(phone,ob){
        $.postAjax({ url : "api/accounts/get_sms_code?mobile="+phone },function(res){
            if (res.code == 0) {
                ob.unbind(touchStart).css('background-color','#cbd5e1');
                var t_count = 10,t_zero;
                var timer = win.setInterval(function() {
                    if (t_count == 0) {
                        win.clearInterval(timer);
                        ob.css('background-color','#556e98').text('短信验证').bind(touchStart,handle);
                    } else {
                        ob.text(function() {
                            --t_count;
                            t_zero = t_count < 10 ? '0' : '';
                            return '重新发送('+ (t_zero + t_count) + 's)';
                        });
                    }
                }, 1000);
            } else {
                alert(res.msg);
            }
        });
    },handle = function(){
        //validate()
        var phone = $("input[name=phone]").val(),ob = $(".sms-btn");
        verifyCode(phone,ob);
    }
    // register verify code
    $(".sms-btn").bind(touchStart,handle);
    // register
    $("#register").bind(touchStart,function(){
        //validate()
        var u = {
            phone : $("input[name=phone]").val(),
            pass : $("input[name=password]").val(),
            verifyCode : $("input[name=code]").val(),
            encryPass : ""
        }
        u.encryPass = win.hex_md5(u.pass);
        var pr = win.getCookie("channel"),partCode="",reUid="";
        if (pr != null) {
            pr = JSON.parse(pr);
            partCode = pr.part_code;
            reUid = pr.re_uid;
        }
        $.postAjax({
            url : "api/accounts/register",
            data : {
                mobile : u.phone,
                passwd : u.encryPass,
                verify_code : u.verifyCode,
                part_code : partCode,
                re_uid : reUid
            }
        },function(res){
            if (res.code == 0) {
                location.href = "../website/login.html";
            } else {
                alert(res.msg);
            }
        });
    });
    // retrieve
    $("#retrieve").bind(touchStart,function(){
        //validate()
        var u = {
            phone : $("input[name=phone]").val(),
            pass : $("input[name=password]").val(),
            verifyCode : $("input[name=code]").val(),
            encryPass : ""
        }
        u.encryPass = win.hex_md5(u.pass);
        $.postAjax({
            url : "api/accounts/reset_passwd",
            data : {
                mobile : u.phone,
                new_passwd : u.encryPass,
                verify_code : u.verifyCode
            }
        },function(res){
            if (res.code == 0) {
                location.href = "../website/login.html";
            } else {
                alert(res.msg);
            }
        });
    });
    /**
     * get user info
     * */
    win.getUser = function() {
        var c_user = getCookie("c_user");
        if (c_user != "" && c_user != "null" && c_user != null && typeof c_user != "undefined")
            return JSON.parse(c_user);
         else
            return "";
    }
    /**
     * get url params
     * strName - key
     * */
    win.request = function (strName) {
        var strHref = window.location.href;
        var intPos = strHref.indexOf("?");
        var strRight = strHref.substr(intPos + 1);
        var arrTmp = strRight.split("&");
        for(var i = 0; i < arrTmp.length; i++) {
            var arrTemp = arrTmp[i].split("=");
            if(arrTemp[0].toUpperCase() == strName.toUpperCase()) return arrTemp[1];
        }
        return "";
    }
    /**
     * 返回
     * */
    win.back = function() {
        window.history.go(-1);
    }
    /**
     * 刷新
     * */
    win.refresh = function() {
        window.location.reload();
    }
    /**
     * c_name - key
     * value - val
     * expires - sec秒
     * */
    win.setCookie = function(c_name, value, expires){
        var exdate=new Date();
        expires = expires * 1000;
        exdate.setTime(exdate.getTime() + expires);
        doc.cookie=c_name +"="+ value + ((expires==null) ? "" : ";expires="+exdate.toGMTString());
    }
    /**
     * get cookie
     * name - key
     * */
    win.getCookie = function(name){
        var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
        if(arr=doc.cookie.match(reg))
            return (arr[2]);
        else
            return null;
    }
    /**
     * delete cookie
     * name - key
     * */
    win.delCookie = function(name){
        var exp = new Date();
        exp.setTime(exp.getTime() - 1);
        var cval=getCookie(name);
        if(cval!=null)
            doc.cookie= name + "="+cval+";expires="+exp.toGMTString();
    }
    var channel = {
        part_code : request("part_code"),
        re_uid : request("re_uid")
    }
    if (channel.part_code != "" || channel.re_uid != "") {
        win.setCookie("channel",JSON.stringify(channel),(60 * 60 * 24));
    }
    $("title").text(global._title);
    $("#mine").bind(touchStart,function(){ if (getUser() != "") location.href = "../website/user.html"; else login_jump(); });
    $("#invent").bind(touchStart,function(){ if (getUser() != "") location.href = "../website/inventory.html"; else login_jump(); });
})($,window,document)

// last loading
window.onload = function(){
    if ($("#backToTop").size() > 0) {
        window.addEventListener("scroll",function(){
            var top = !('pageYOffset' in window) ? (document.compatMode === "BackCompat")
                ? document.body.scrollTop : document.documentElement.scrollTop
                : window.pageYOffset;
            if (top > 400) {
                $("#backToTop").removeClass("hidden");
            } else {
                $("#backToTop").addClass("hidden");
            }
        },false);
        var backTop = document.getElementById("backToTop");
        backTop.addEventListener(touchStart,function(){
            $.backTop();
        },false);
    }
    // navigation status
    if ($(".index_btm a").size() > 0) {
        var n = {
            index : $("#index").val(),
            changeOn : function(before,after) {
                $(".index_btm ."+before).removeClass(before).addClass(after);
            }
        }
        switch (n.index) {
            case "1" :
                n.changeOn("ico-home","ico-on-home");
                break;
            case "2" :
                n.changeOn("ico-publish","ico-on-publish");
                break;
            case "3" :
                n.changeOn("ico-car","ico-on-car");
                break;
            case "4" :
                n.changeOn("ico-mine","ico-on-mine");
                break;
            default :
                break;
        }
        $(".index_btm a").eq(n.index-1).addClass("on").siblings().removeClass("on");
    }
    if ($(".m-detail-login").size() > 0) {
        if (window.getUser() != "") location.href = "../website/user.html";
    }
    // shop car sum
    if ($("[data-pro=invent]").size() > 0) {
        var c_user = window.getUser();
        if (c_user != "") {
            var c_num = parseInt(c_user.num);
            if (c_num > 0) {
                $("[data-pro=invent]").html('<small class="car-num">' + c_num + '</small>');
            }
        }
    }
    if ($("[data-number=true]").size() > 0) {
        $("[data-number=true]").each(function(){
            $(this).bind("keyup",function(){
                var value = $(this).val();
                $(this).val(value.replace(/[^\d]/g,''));
            });
        });
    }
    $('script[type="text/javascript"]').each(function(){
        var timestamp=new Date().getTime();
        $(this).attr("src",$(this).attr("src")+"?v="+timestamp);
    });
}