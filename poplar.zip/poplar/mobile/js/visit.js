function login_jump() {
    if (window.getUser()=="") {
        window.setCookie("skip_url",location.href)
        if (global._iswx()) {
            location.href = "../website/login.transfer.html?part=wx";
            return;
        } else {
            location.href = "../website/login.html";
            return;
        }
    }
}
function _flushcar(u,n) {
    if (n <= 0) {
        $("[data-pro=invent]").html('');
    } else {
        $("[data-pro=invent]").html('<small class="car-num">'+n+'</small>');
    }
    u.num = n;
    window.setCookie("c_user",JSON.stringify(u));
}
function _zero(n) {
    var _n = parseInt(n, 10);
    if(_n > 0){
        if(_n <= 9){
            _n = "0" + _n
        }
        return String(_n);
    }else{
        return "00";
    }
}
(function($){
    // check login
    if (typeof c != "undefined") {
        if (c.hasOwnProperty('active') && typeof c.verify != "undefined") {
            login_jump();
        }
    }
    window.pageToken = "";
    var Visit = function() {},_type = c.type,_url = c.path;
    if (_url != "" && typeof _url != "undefined") {
        $.postAjax({url : _url},function(data){
            var res = new Visit();
            if (data.code == 0) {
                if (_type == "index") {
                    res._index(data);
                } else if (_type == "detail") {
                    res._details(data);
                } else if (_type == "detail.photo") {
                    res._detailPhoto(data);
                } else if (_type == "detail.before") {
                    res._detailBefore(data);
                } else if (_type == "detail.number") {
                    res._detailNumber(data);
                } else if (_type == "detail.calc") {
                    res._detailCalc(data);
                } else if (_type == "detail.member") {
                    res._detailMember(data);
                } else if (_type == "newest") {
                    res._newest(data);
                } else if (_type == "user.inventory") {
                    res._inventory(data);
                } else if (_type == "user.index") {
                    res._userIndex(data);
                } else if (_type == "user.records") {
                    res._userRecords(data);
                } else if (_type == "user.luckys") {
                    res._userLucks(data);
                } else if (_type == "user.address") {
                    res._addressMgr(data);
                }
            } else if (data.code == 105) {
                login_jump();
            } else {
                console.error(data.msg);
            }
        });
    }
    Visit.prototype = {
        _setText : function(cls,val) {
            $("."+cls).text(val);
        },
        _block : function(cls) {
            $("."+cls).removeClass("hidden");
        },
        _none : function(cls) {
            $("."+cls).addClass("hidden");
        },
        _pageModal : function(url,callback) {
            $(window).scroll(function(){
                console.log(window.pageToken);
                if (window.pageToken == "") {
                    $("[data-pro=none_more]").removeClass("hidden");
                    $("[data-pro=loading]").addClass("hidden");
                    return;
                } else {
                    $("[data-pro=loading]").removeClass("hidden");
                    $("[data-pro=none_more]").addClass("hidden");
                }
                var scrollTop = $(this).scrollTop();
                var scrollHeight = $(document).height();
                var windowHeight = $(this).height();
                if (scrollTop + windowHeight == scrollHeight) {
                    $.postAjax({url : url,data:{next_page_token:window.pageToken}},function(data){
                        callback(data);
                    });
                }
            });
        },
        _details : function(json) {
            // result object
            var r = {
                status : json.data.status,              // 商品状态
                goods : json.data.goods,                // 商品object
                images : json.data.goods.thumbnail_list,// 商品图片
                lucky : json.data.lucky_info,           // 幸运记录
                users : json.data.my_joined_info,       // 我的夺宝记录
                records : json.data.latest_records,      // 参与记录
                period : json.data.period
            }
            var p_unit = r.goods.buy_unit,surplus = r.goods.remaining_times;
            // setup text content
            this._setText("sup_gname",r.goods.gname);
            this._setText("gdesc",r.goods.gdesc);
            this._setText("sup_period", r.period);
            this._setText("sup_start_time",json.data.start_time);
            this._setText("sup_total_time",r.goods.total_times);
            this._setText("sup_remain_time",surplus);
            var percent = parseFloat(((r.goods.total_times-surplus)/r.goods.total_times) * 100).toFixed(2);
            $(".sup_bar").css("width",percent+"%"); // process bar
            $(".sup_photo").attr("href","details.photo.html?gid="+ r.goods.gid);
            $(".sup_before").attr("href","announce.before.html?period="+ r.period);
            $(".sup_calc_detail").attr("href","details.calculate.html?period="+ r.period);
            $(".sup_join_detail").attr("href","details.number.html?period="+ r.period+"&uid="+ r.lucky.owner.uid);
            $(".btn_third").attr("href","details.html?period="+json.data.next_period);
            if (r.images.length > 0) {
                var i_html = "";
                for (var i = 0;i < r.images.length;i++) {
                    i_html += '<div class="swiper-slide"><img src="'+ r.images[i].big_pic+'"></div>';
                }
                $(".swiper-wrapper").html(i_html);
                $.swiperDetails();  // banner
            }
            var pub_time = json.data.publish_time;
            if (r.status == 2) {   // 揭晓倒计时
                this._none("m-detail-onlyOne");
                var pub_sec = parseInt(json.data.pub_countdown);
                var _sec = _zero(pub_sec % 60), _mini = _zero(pub_sec / 60 % 60);
                $(".m-count-down").find('.mini').text(_mini);
                $(".m-count-down").find('.sec').text(_sec);
                $(".m-count-down").attr("data-end",pub_sec).countTimer();
                this._block("finish_btm");
                this._none("proceed_btm");
                this._block("m-detail-process");
            } else if (r.status == 3) {   // 揭晓后
                this._none("m-detail-onlyOne");
                var l = r.lucky;
                this._setText("sup_luck_code", l.lucky_code);
                this._setText("sup_buy_time", l.code_total);
                this._setText("p1-title", l.owner.nick_name);
                this._setText("p1-address", l.owner.city);
                this._setText("sup_pub_time",pub_time);
                $(".user_head").attr("src",l.owner.avatars_url);
                $(".sup_user_link").attr("href","details.member.html?uid="+ l.owner.uid);
                this._none("proceed_btm");
                this._block("finish_btm");
                this._block("m-detail-result");
            }
            $(".btn_first").bind(touchStart,function(e){
                e.preventDefault();
                var c_user = window.getUser();
                if (c_user != "") $(".buy_dialog").removeClass("hidden"); else login_jump();
            });
            $(".btn_second").bind(touchStart,function(e){
                e.preventDefault();
                var c_user = window.getUser();
                if (c_user != "") {
                    var period = r.period,buyTotal = p_unit;
                    if (period != "" && typeof period != "undefined") {
                        if (buyTotal == "" || typeof buyTotal == "undefined"){
                            buyTotal = 10;  // 异常情况 default 10
                        }
                        $.postAjax({url: 'api/add_2_cart', data: {period:period,buy_total:buyTotal}}, function (j) {
                            if (j.code == 0) _flushcar(c_user,j.data.total_num);
                        });
                    }
                } else {
                    login_jump();
                }
            });
            $(".inp_content").val(p_unit);
            this._setText("n-total",p_unit);
            $(".btn_plus").bind(touchStart,function(){
                var inpTime = $(".inp_content"),tVal = $(".inp_content").val();
                if (tVal >= 1) {
                    $(".btn_subtract").removeClass("disabled");
                }
                if (tVal >= parseInt(surplus)) {
                    $(this).addClass("disabled");
                } else {
                    tVal = parseInt(tVal) + 1;
                }
                inpTime.val(tVal);
                $(".n-total").text(tVal);
            });
            $(".btn_subtract").bind(touchStart,function(){
                var inpTime = $(".inp_content"),tVal = $(".inp_content").val();
                if (tVal <= parseInt(surplus)) {
                    $(".btn_plus").removeClass("disabled");
                }
                if (tVal > p_unit) {
                    tVal = parseInt(tVal) - 1;
                    inpTime.val(tVal);
                } else {
                    $(this).addClass("disabled");
                }
                $(".n-total").text(tVal);
            });
            $(".time-num-item").find("span").bind(touchStart,function(){
                var inpTime = $(".inp_content"),tVal = $(this).text();
                inpTime.val(parseInt(tVal));
                $(".n-total").text(tVal);
            });
            $(".inp_content").bind("blur",function(){
                var val = parseInt($(this).val());
                if (/^[\d]+$/.test(val)) {
                    if (val > surplus) {
                        $(this).val(surplus);
                        $(".n-total").text(surplus);
                    } else if (val < p_unit) {
                        $(this).val(p_unit);
                        $(".n-total").text(p_unit);
                    } else {
                        $(".n-total").text(val);
                    }
                } else {
                    $(this).val(p_unit);$(".n-total").text(p_unit);
                }
            });
            // 立即夺宝
            $(".sup_dialog_buy").bind(touchStart,function(){
                var purchase = '{"signature":"sure.pay","list":[{"period":'+r.period+',"buy_total":'+$(".inp_content").val()+'}]}';
                window.setCookie("purchase",purchase);
                location.href = '../website/pay.confirm.html';
            });
            // 我参与的记录
            var c_user = getUser();
            if (c_user != "") {
                var p_time = r.users.code_total;
                if (p_time > 0 && typeof p_time != "undefined") {
                    this._setText("sup_my_buy_time", p_time);
                    this._setText("sup_my_number", r.users.code_list);
                    $(".sup_join_more").attr("href","details.number.html?period="+ r.period+"&uid="+ r.users.uid);
                    this._block("my-record");
                    this._none("m-detail-userCodes");
                }
            } else {
                $(".m-detail-userCodes-blank").html('<a href="javascript:login_jump();" class="txt-blue">登录</a>以查看您的夺宝号码~');
                this._block("m-detail-userCodes");
            }
            if (r.records.items != null && typeof r.records.items != "undefined") {
                var dataProcess = function(json) {
                    window.pageToken = json.next_page_token;
                    var r_html = "";
                    for (var i = 0;i < json.items.length;i++) {
                        var v = json.items[i],link = "details.member.html?uid="+v.owner.uid;
                        r_html += '<li id="pro-view-'+(2+i)+'"><div class="avatar"><a href="'+link+'"><img src="'+v.owner.avatars_url+'"></a></div>'+
                        '<div class="text"><p class="f-breakword"><a href="'+link+'" class="txt-blue">'+v.owner.nick_name+'</a>'+
                        '<span class="address">('+(typeof v.owner.city != "undefined"?v.owner.city:'未知')+' IP：'+v.owner.user_ip+')</span></p>'+
                        '<p><span class="num">参与了<span class="txt-red">'+v.total+'</span>人次</span> '+v.join_time+'</p></div></li>';
                    }
                    $(".m-detail-record-list").append(r_html);
                }
                dataProcess(r.records);
                this._pageModal('api/next_joined_records?period='+ r.period,function(json){
                    if (json.code == 0) dataProcess(json.data);
                });
            } else {
                $(".w-more div[data-pro=loading]").addClass("hidden");

                $(".w-more div[data-pro=none]").removeClass("hidden");
            }
            $(".dialog_close").bind(touchStart,function(e){
                e.preventDefault();
                $(".buy_dialog").addClass("hidden");
                //var touch = event.targetTouches[0];  touch.pageX  touch.pageY
            });
            $(".share_dialog").find('.widget_mask').bind(touchStart,function(e) {
                e.preventDefault();
                $(this).parent().addClass("hidden");
            });
            $(".icon-share").bind(touchStart,function(){
                $(".share_dialog").removeClass("hidden");
            });
            $(".icon-car").bind(touchStart,function(){
                var c_user = window.getUser();
                if (c_user != "") location.href = "../website/inventory.html"; else login_jump();
            });
        },
        _detailMember : function(json) {
            var p = {
                user : json.data.owner,
                records : function(r_list) {
                    var r_html = "";
                    for (var i = 0; i < r_list.length; i++) {
                        var t = r_list[i], status = t.active_status, _before = "", _after = "", link = "details.html?period=" + t.period;
                        _before = '<div class="m-detail-goods mb20"><div class="m-detail-con"><div class="fl-l m-detail-pic">' +
                        '<a href="' + link + '"><img alt="' + t.gname + '" src="' + t.thumbnail + '"></a></div><p class="m-title"><a href="' + link + '">' + t.gname + '</a></p><p class="m-period">参与期号：' + t.period + '</p>' +
                        '<p class="m-this-period">本期参与：<span class="txt-red">' + t.buy_total + '</span>人次<span class="detail_btn"><a href="details.number.html?period=' + t.period + '&uid=' + p.user.uid + '" class="fon-arial txt-blue">参与详情</a></span>' +
                        '</p>' + (t.is_bingo == 1 ? '<div class="lucky-pic"><img src="../images/icon/lucky-cup.png"></div>' : '') + '</div>';
                        if (status == 1) {         // 进行中
                            var percent = parseFloat(((t.total_times - t.remaining_times) / t.total_times) * 100).toFixed(2);
                            _after = '<div class="w-progressBar"><ul class="txt"><li class="txt-l"><p>总需' + t.total_times + '</p></li><li class="txt-r"><p>剩余<b class="txt-blue">' + t.remaining_times + '</b></p></li></ul>' +
                            '<p class="wrap mt5"><span class="bar" style="width:' + percent + '%"><i class="color"></i></span></p></div><a href="#" class="btn follow_buy">跟买</a>';
                        } else if (status == 3) { // 揭晓后
                            _after = '<div class="m-detail-btm">获奖者：<span class="fon-arial txt-blue">' + t.lucky_owner.nick_name + '</span>&nbsp;&nbsp;<span class="txt-red">' + t.lucky_owner.buy_total + '</span>人次<a href="#buyAgain" class="btn again_buy">再次购买</a></div>';
                        } else {
                            _after = '<div class="m-detail-btm">正在揭晓中<a href="#buyAgain" class="btn again_buy">再次购买</a></div>';
                        }
                        r_html += (_before + _after + '</div>');
                    }
                    $(".m-detail-buy").append(r_html);
                },
                luckys : function(r_list) {
                    var r_html = "";
                    if (r_list != null) {
                        for(var i = 0;i < r_list.length;i++){
                            var t = r_list[i];
                            r_html += '<li class="m-lucy-item"><div class="m-luck-box"><div class="m-detail-pic fl-l mt20"><a href="#"><img src="'+ t.thumbnail+'" alt="'+ t.gname+'"></a>'+
                            '</div><div class="m-luck-info"><p class="m-title"><a href="#">'+ t.gname+'</a></p><p class="mt5 mb5">总需：'+ t.total_times+'人次</p>'+
                            '<p>参与期号：'+ t.period+'</p><p>幸运号码：<b class="fon-arial txt-red">'+ t.lucky_code+'</b></p><p>本期参与：'+ t.buy_total+'人次</p><p>揭晓时间：'+ t.publish_time+'</p></div></div></li>';
                        }
                        $(".m-detail-lucy ul").append(r_html);
                    } else {
                        $(".m-detail-lucy").addClass("hidden");
                    }
                }
            }
            this._setText("sup_nickname", p.user.nick_name);
            this._setText("sup_uid", p.user.uid);
            $(".sup_head").attr("src", p.user.avatars_url)
            //$(".member-detail-nav a").attr("data-id",);
            p.records(json.data.joined_records);
            var _uid = request("uid");
            $(".member-detail-nav a").bind(touchStart,function(){
                var $this = $(this),_sign = $this.attr("data-sign");
                var buy_record = $(".m-detail-buy"),luck_record = $(".m-detail-lucy");
                if (_sign == 1) {
                    if ($(".m-detail-buy .m-detail-goods").size() <= 0) {
                        $.postAjax({url:"api/other_user_profile?user_id="+_uid},function(j){
                            if(j.code == 0) p.records(j.data.joined_records);
                        });
                    }
                    buy_record.removeClass("hidden");
                    luck_record.addClass("hidden");
                } else {
                    if ($(".m-detail-lucy .m-lucy-item").size() <= 0) {
                        $.postAjax({url: "api/my_lucky_records?user_id=" + _uid}, function (j) {
                            if (j.code == 0) p.luckys(j.data.records);
                        });
                    }
                    buy_record.addClass("hidden");
                    luck_record.removeClass("hidden");
                }

                $this.addClass("on").parent().siblings().find("a").removeClass("on");
            });

        },
        _detailPhoto : function(json) {
            var d_html = "";
            for(var i = 0;i < json.data.desc_list.length;i++) {
                var d = json.data.desc_list[i];
                d_html += '<img width="100%" src="'+ d.imgurl+'">';
            }
            $(".g-wrap .images").html(d_html.trim());
        },
        _detailBefore : function(json) {
            var goods = json.data.items;
            if (goods != null) {
                var g_html = "";
                for(var i = 0;i < goods.length;i++) {
                    var v = goods[i];
                    g_html += '<li class="m-winRecord-revealed"><div class="w-record-title"><a href="details.html?period='+ v.period+'" class="light-white">'+
                    '期号：'+ v.period+' (揭晓时间：'+ v.publish_time+')</a></div><div class="w-record-cnt clear">'+
                    '<div class="w-record-avatar fl-l mt5"><a href="javascript:;"><img src="'+ v.owner.avatars_url+'"></a>'+
                    '</div><div class="w-record-detail"><p class="ellipsis">获得者：<a href="javascript:;" class="txt-blue">'+ v.owner.nick_name+'</a></p>'+
                    '<p class="ellipsis"><span class="txt-green">( '+ v.owner.city+' IP：'+ v.owner.user_ip+' )</span></p><p>用户ID：'+ v.owner.uid+' (唯一不变标识)</p>'+
                    '<p>幸运号码：<span class="txt-red">'+ v.lucky_code +'</span></p><p>本期参与：<span class="txt-red">'+ v.total+'</span>人次</p></div></div></li>';
                }
                $(".m-before-item").html(g_html);
            } else {
                this._none("m-before");
                this._block("m-nothing");
            }
        },
        _detailNumber : function(json) {
            this._setText("sup_t_time",json.data.code_total);
            var all_code = json.data.owner_all_code;
            var t_html = "";
            for(var i = 0;i < all_code.length;i++) {
                var v = {ac : all_code[i],c_str : all_code[i].code_list,c_list : [],c_html : "<ul>"}
                v.c_list = v.c_str.toString().split(',');
                for(var k = 0;k < v.c_list.length;k++) {
                    v.c_html += '<li>'+ v.c_list[k] +'</li>';
                    if (k == (v.c_list.length - 1)) {
                        v.c_html += '</ul></div></div>';
                    }
                }
                t_html += '<div class="n-title-item"><ul class="txt-c ml-ten">'+
                '<li class="w-forty-five sup_n_date">'+ v.ac.join_time+'</li>'+
                '<li class="w-twenty pale-red sup_n_time">'+v.ac.join_total+'</li>'+
                '<li class="w-twenty"><a href="javascript:;" class="txt-blue check-look" data-sign="0">查看</a></li>'+
                '</ul><div class="n-details hidden">'+ v.c_html;
            }
            $(".n-title-up").append(t_html);
            $(".check-look").bind(touchStart,function(){
                var n_details = $(this).parents(".n-title-item").find(".n-details");
                var _this = $(this);
                if (_this.attr("data-sign") == 0) {
                    _this.text("收起");
                    _this.attr("data-sign","1");
                    n_details.removeClass("hidden");
                    if ($(this).parents(".n-title-item").next()) {
                    }
                } else {
                    _this.text("查看");
                    _this.attr("data-sign","0");
                    n_details.addClass("hidden");
                }
            });
        },
        _detailCalc : function(json) {
            var calc = json.data.calc_result;
            var c_html = "";
            for(var i = 0;i < calc.joined_list.length;i++) {
                var v = calc.joined_list[i];
                c_html += '<tr class="calcRow"><td class="time">'+ v.time+' <i class="ico ico-arrow-transfer"></i> <b class="txt-red">'+
                v.time_value+'</b></td><td class="user"><div class="f-breakword">'+
                '<a class="goUserPage" data-uid="'+ v.uid+'" title="'+v.nick_name+'" href="javascript:void(0)">'+ v.nick_name+'</a></div></td></tr>';
            }
            $(".m-calc-list tbody").html(c_html);
            this._setText("sup_val_a",calc.value_a);
            this._setText("sup_val_b",calc.value_b);
            this._setText("sup_ssc_period",calc.ssc_period);
            var luck_code = $(".m-calc-result-code");
            if (calc.status == "3") {
                $(".m-calc-B .stay").addClass("hidden");
                $(".m-calc-B .then").removeClass("hidden");
                luck_code.html('幸运号码：<b class="txt-red">'+calc.lucky_code+'</b>');
            } else {
                luck_code.html('幸运号码：<span class="txt-orange">等待揭晓...</span>');
            }
            $(".m-calc-A").find(".btn").bind(touchStart,function(){
                var o_list = $(".m-calc-list");
                var i_this = this.childNodes[1];
                if (i_this.className.indexOf("ico-arrow-down") != -1) {
                    o_list.css("height","auto");
                    this.innerHTML = "收起<i class='ico-arrow ico-arrow-up'></i>";
                } else {
                    o_list.css("height","0");
                    this.innerHTML = "展开<i class='ico-arrow ico-arrow-down'></i>";
                }
            });
        },
        _index : function(json) {
            var r = {
                banners : json.data.BannerList,htmls_a : "",
                lucks : json.data.LuckyList,htmls_b : "",
                goods : json.data.GoodsList,htmls_c : "",
                cartNum : json.data.cart_goods_num
            }
            for(var i = 0;i < r.banners.length;i++) {
                var t = r.banners[i];
                r.htmls_a += '<div class="swiper-slide"><img src="'+ t.image+'"></div>';
            }
            $(".swiper-wrapper").html(r.htmls_a);
            $.swiperIndex();
            for(var i = 0;i < r.lucks.length;i++) {
                var t = r.lucks[i];
                r.htmls_b += (' <li><a href="details.html?period='+t.period+'"><div class="ellipsis" style="width: 92%;"><span class="little_bugle"></span>'
                + '恭喜<span class="light-blue">'+t.nick_name+'</span>获得<span class="bold-black">'+t.gname+'</span>'
                + '<span class="right_arrows"></span></div></a></li>');
            }
            $("#notice-topic").html(r.htmls_b);
            $.noticeTopic("notice-topic");
            for(var i = 0;i < r.goods.length;i++) {
                var t = r.goods[i],percent = parseFloat(((t.total_times-t.remaining_times)/t.total_times) * 100).toFixed(2);
                var link = "details.html?period="+t.period;
                r.htmls_c += ('<li><a href="'+link+'"><div class="content"><div class="img_wrap"><img src="'+t.cover_image+'" /></div><p class="goods_name">'
                + '<a href="'+link+'" class="bold-black">'+t.gname+'</a></p><div class="btm-info"><div class="content-left">'
                + '<div class="progress-bar"><div class="progress_wrap" style="width: '+percent+'%;"></div></div><div class="progress-left">'
                + '<p class="title_money">'+t.total_times+'</p><p>总需</p></div><div class="progress-right">'
                + '<p style="color: #d4001e;" class="title_money">'+t.remaining_times+'</p><p>剩余</p></div></div>'
                + '<div class="content-right"><div class="wrap"><a href="javascript:;" data-unit="'+ t.buy_unit+'" data-id="'+ t.period+'" class="join sup_add_card">清单</a></div></div></div></div></a></li>');
            }
            $(".goods-item ul").html(r.htmls_c);
            if (window.getUser() != "") { _flushcar(window.getUser(), r.cartNum); }
            $(".sup_add_card").bind(touchStart,function(e){     // add car
                e.preventDefault();
                var c_user = window.getUser(),that = $(this);
                if (c_user != "") {
                    var period = that.attr("data-id"),buyTotal = that.attr("data-unit");
                    if (period != "" && typeof period != "undefined") {
                        if (buyTotal == "" || typeof buyTotal == "undefined"){
                            buyTotal = 10;  // 异常情况 default 10
                        }
                        $.postAjax({url: 'api/add_2_cart', data: {period:period,buy_total:buyTotal}}, function (j) {
                            if (j.code == 0) {
                                _tip("商品已添加至清单",1500,function(){
                                    _flushcar(c_user,j.data.total_num);
                                });
                            }
                        });
                    }
                } else {
                    login_jump();
                }
            });
        },
        _newest : function(json) {
            var dataProcess = function(json) {
                window.pageToken = json.data.next_page_token;
                if (window.pageToken == "") {
                    $("[data-pro=loading]").addClass("hidden");
                    $("[data-pro=none_more]").removeClass("hidden");
                }
                var n = {goods : json.data.list,_html : ""},timer = 0;
                if (n.goods != null && typeof n.goods != "undefined") {
                    for (var k = 0; k < n.goods.length; k++) {
                        var t = n.goods[k], link = "details.html?period=" + t.period;
                        var _before = '<li class="m-goods-item"><div class="m-goods-info"><div class="txt-c"><div class="goods-img"><a href="' + link + '"><img src="' + t.cover_image + '"></a></div></div>',
                            _middle = "",
                            _after = '</div></li>';
                        if (t.status == 2) {
                            var pub_sec = parseInt(t.pub_countdown);
                            var _sec = _zero(pub_sec % 60), _mini = _zero(pub_sec / 60 % 60);
                            _middle = '<div class="ml10"><p class="goods-title px16 ellipsis"><a href="' + link + '">' + t.gname + '</a></p>' +
                            '<p class="goods-period px14 mt5 txt-gray">期号：<span class="p-num">' + t.period + '</span></p>' +
                            '<div class="goods-count-down pale-red mt15" data-end="' + t.pub_countdown + '"><dl><dt class="px14">即将揭晓</dt>' +
                            '<dd class="mt5 fon-arial m-time"><span class="mini">' + _mini + '</span>:<span class="sec">' + _sec + '</span>:<span class="hm">00</span></dd>' +
                            '</dl></div></div>';
                            timer++;
                        } else {
                            _middle = '<div class="ml5 context"><p class="goods-title ellipsis"><a href="' + link + '">' + t.gname + '</a></p>' +
                            '<p class="goods-period ellipsis mt5">期<span class="p_spacing"></span>号：<span class="p-num">' + t.period + '</span></p>' +
                            '<p class="ellipsis">获<span class="w-spacing"></span>奖<span class="w-spacing"></span>者：<span class="txt-blue">' + t.lucky_guy + '</span></p>' +
                            '<p>参与人次：<span class="p-num">' + t.lucky_buy_total + '</span></p><p class="ellipsis">幸运号码：<span class="pale-red">' + t.lucky_code + '</span></p>' +
                            '<p class="ellipsis">揭晓时间：<span class="p-num">' + t.publish_time + '</span></p></div>';
                        }
                        n._html += _before + _middle + _after;
                    }
                    if (n.goods.length % 2 != 0) {
                        n._html = n._html+'<li style="height: 291px;"></li>';
                    }
                    $(".m-newest ul").append(n._html);
                    if (timer != 0) {
                        $(".goods-count-down").countTimer();
                    }
                }
            }
            dataProcess(json);
            this._pageModal('api/newly_publish',function(json){
                dataProcess(json);
            });
        },
        _inventory : function(json) {
            var i = {
                data : json.data,
                i_html : "",
                checkBox : function(sta,that){
                    if (sta == "this") {
                        if (!that.hasClass("on")) that.addClass("on"); else that.removeClass("on");
                    } else {
                        if (!that.hasClass("on")) $(".checkbox").addClass("on"); else $(".checkbox").removeClass("on");
                    }
                    $(".sup_num").text($(".check-only.on").size());
                }
            }
            if (i.data.list == null || i.data.list == "undefined") {
                $(".m-nothing").removeClass("hidden");
                $(".edit-finish").parent().remove();
            } else {
                $(".calc-box").removeClass("hidden");
                this._block("edit-finish");
                var totalNum=i.data.list.length,totalMoney = 0;
                for(var s = 0;s < totalNum;s++) {
                    var t = i.data.list[s];
                    i.i_html += '<div class="m-inv-item"><div><span class="checkbox check-only fl-l hidden" data-id="'+ t.period+'"></span><div class="m-inv-pic fl-l">'+
                    '<a><img src="'+ t.thumbnail+'" ></a></div></div><div class="m-inv-label ml5"><p class="p-title mt5"><a href="details.html?period='+ t.period+'">'+ t.gname+'</a></p>'+
                    '<p class="p-time mt10">总需<span class="t-num">'+ t.total_times+'</span>人次，剩余<span class="txt-blue">'+ t.remaining_times+'</span>人次</p><div class="mt5"><span>参与人次</span>'+
                    '<div class="w-number"><input class="input px14 inp-content" data-number="true" data-unit="'+ t.buy_unit+'" data-surplus="'+ t.remaining_times+'" value="'+ t.buy_total+'" data-number="true"><a class="btn btn-plus" href="javascript:;"><i class="i-plus"></i></a>'+
                    '<a class="btn btn-minus" href="javascript:;"><i class="i-minus"></i></a></div></div></div></div>';
                    totalMoney += parseInt(t.buy_total);
                }
                this._setText("sup_total_num",totalNum);
                this._setText("sup_total_money",totalMoney);
                $(".m-inv-list").append(i.i_html);
                $(".btn-plus").bind(touchStart,function(){
                    var inpTime = $(this).parent().find("input"),
                        tVal = inpTime.val(),
                        btnSub = $(".btn-minus"),
                        surplus = inpTime.attr("data-surplus");
                    if (tVal >= 1) {
                        btnSub.removeClass("disabled");
                    }
                    if (tVal >= parseInt(surplus)) {
                        $(this).addClass("disabled");
                    } else {
                        tVal = parseInt(tVal) + 1;
                    }
                    inpTime.val(tVal);
                });
                $(".btn-minus").bind(touchStart,function(){
                    var inpTime = $(this).parent().find("input"),
                        tVal = inpTime.val(),
                        btnPlus = $(".btn-plus"),
                        surplus = inpTime.attr("data-surplus"),
                        unit = inpTime.attr("data-unit");
                    if (tVal <= parseInt(surplus)) { btnPlus.removeClass("disabled"); }
                    if (tVal > parseInt(unit)) {
                        tVal = parseInt(tVal) - 1;
                        inpTime.val(tVal);
                    } else {
                        $(this).addClass("disabled");
                    }
                });
                $(".inp-content").bind("blur",function(){
                    var $this = $(this),total = $(".sup_total_money"),val = parseInt($this.val());
                    var surplus = parseInt($this.attr("data-surplus")),p_unit = parseInt($this.attr("data-unit"));
                    if (/^[\d]+$/.test(val)) {
                        if (val > surplus) {
                            $this.val(surplus);
                            total.text(surplus);
                        } else if (val < p_unit) {
                            $this.val(p_unit);
                            total.text(p_unit);
                        } else {
                            total.text(val);
                        }
                    } else {
                        $(this).val(p_unit);total.text(p_unit);
                    }
                });
                $(".check-only").bind(touchStart,function(){
                    i.checkBox("this",$(this));
                });
                $(".btn-calc").bind(touchStart,function(){  // 结算
                    var goods = { signature : "inv.buy",list : []},purchase = "";
                    $(".m-inv-item").each(function(i,e){
                        var val = $(e).find(".inp-content").val(),
                            period = $(e).find(".check-only").attr("data-id");
                        if (period == "" || typeof period == "undefined") {
                            console.log("period not found.");
                            return false;
                        }
                        goods.list[i] = { period : parseInt(period),buy_total : parseInt(val) }
                    });
                    if (goods.list.length != 0) {
                        purchase = JSON.stringify(goods);
                        window.setCookie("purchase",purchase);
                        location.href = '../website/pay.confirm.html';
                    }
                });
                $(".edit-finish").bind(touchStart,function(){
                    var op = {
                        sign : $(this).attr("data-sign"),
                        checks : $(".m-inv-item .checkbox"),
                        delItem : $(".del-box"),
                        opera : $(".m-inv-operate"),
                        btmSpac : ""
                    }
                    if (op.sign == 0) {
                        op.checks.removeClass("hidden");
                        op.opera.addClass("hidden");
                        op.delItem.removeClass("hidden");
                        $(this).text("完成");
                        $(this).attr("data-sign",1);
                        op.btmSpac = "118px";
                    } else {
                        op.checks.addClass("hidden");
                        op.opera.removeClass("hidden");
                        op.delItem.addClass("hidden");
                        $(this).text("编辑");
                        $(this).attr("data-sign",0);
                        op.btmSpac = "120px";
                    }
                    $("section[data-role=main]").css("margin-bottom",op.btmSpac);
                });
                $(".check-all").bind(touchStart,function(){
                    i.checkBox("all",$(this));
                });
                $(".btn-del").bind(touchStart,function(){
                    var c_user = window.getUser();
                    if (c_user != "") {
                        var pa = {periods : "",checkOn : $(".check-only.on")}
                        if (pa.checkOn.length <= 0) {
                            alert('请选择需要删除的商品清单');
                            return;
                        }
                        var count = 0;
                        pa.checkOn.each(function(index,element){
                            if ($(element).hasClass("on")) {
                                pa.periods += $(element).attr("data-id") + ",";
                                count++;
                            }
                        });
                        pa.periods = pa.periods.substring(0,pa.periods.length-1);
                        $.postAjax({url: 'api/delete_from_cart', data: {period_list:pa.periods}}, function (j) {
                            if (j.code == 0) {
                                count = c_user.num - count;
                                _flushcar(c_user,count);
                                refresh();
                            }
                        });
                    }
                });
            }
        },
        _userIndex : function(json){
            var member = json.data.owner;
            if (member != "" && typeof member != "undefined") {
                $(".user-avatar img").attr("src",member.avatars_url);
                this._setText("sup_name",member.nick_name);
                this._setText("sup_uid",member.uid);
                $("#records").attr("href","user.records.html?uid="+member.uid);
                $("#luckys").attr("href","user.luckys.html?uid="+member.uid);
            }
        },
        _userRecords : function(json) {
            var dataProcess = function(json) {
                window.pageToken = json.next_page_token;
                var _html = "";
                for(var i = 0;i < json.records.length;i++){
                    var t = json.records[i],link = "details.html?period="+ t.period;
                    var status = t.active_status,_before = "",_after = "";
                    _before = '<div class="m-detail-goods mb20"><div class="m-detail-con"><div class="m-detail-pic fl-l">'+
                    '<a href="'+link+'"><img src="'+ t.thumbnail+'"></a></div><p class="m-title"><a href="'+link+'">'+ t.gname+'</a></p><p class="m-period">参与期号：'+ t.period+'</p>'+
                    '<p class="m-this-period">本期参与：<span class="txt-red">'+ t.buy_total+'</span>人次<span class="detail_btn"><a href="details.number.html?period='+t.period+'&uid='+ r.uid+'" class="fon-arial txt-blue">参与详情</a></span>'+
                    '</p>'+(t.is_bingo == 1 ? '<div class="lucky-pic"><img src="../images/icon/lucky-cup.png"></div>':'')+'</div>';
                    if (status == 1) {         // 进行中
                        var percent = parseFloat(((t.total_times-t.remaining_times)/t.total_times) * 100).toFixed(2);
                        _after = '<div class="w-progressBar"><ul class="txt"><li class="txt-l"><p>总需'+ t.total_times+'</p></li><li class="txt-r"><p>剩余<b class="txt-blue">'+ t.remaining_times+'</b></p></li></ul>'+
                        '<p class="wrap mt5"><span class="bar" style="width:'+percent+'%"><i class="color"></i></span></p></div><a href="#" class="btn follow_buy">跟买</a>';
                    } else if (status == 3) { // 揭晓后
                        _after = '<div class="m-detail-btm">获奖者：<span class="fon-arial txt-blue">'+ t.lucky_owner.nick_name+'</span>&nbsp;&nbsp;<span class="txt-red">'+t.lucky_owner.buy_total+'</span>人次<a href="#buyAgain" class="btn again_buy">再次购买</a></div>';
                    } else {
                        _after = '<div class="m-detail-btm">正在揭晓中<a href="#buyAgain" class="btn again_buy">再次购买</a></div>';
                    }
                    _html += (_before + _after + '</div>');
                }
                $(".m-detail-buy").append(_html);
            }
            var r = {data : json.data,uid:json.data.uid}
            if (r.data.records != null) {
                dataProcess(r.data);
                this._pageModal('api/my_duobao_records?user_id='+ r.uid,function(json){
                    if (json.code == 0) dataProcess(json.data);
                });
            } else {
                $(".m-nothing").removeClass("hidden");
            }
        },
        _userLucks : function(json) {
            var dataProcess = function(json) {
                window.pageToken = json.next_page_token;
                var _html = "";
                for(var i = 0;i < json.records.length;i++){
                    var t = json.records[i],link = "details.html?period="+ t.period;
                    _html += '<li class="m-lucy-item"><div class="m-luck-box"><div class="m-detail-pic fl-l mt20"><a href="'+link+'"><img src="'+ t.thumbnail+'" alt="'+ t.gname+'"></a>'+
                    '</div><div class="m-luck-info"><p class="m-title"><a href="'+link+'">'+ t.gname+'</a></p><p class="mt5 mb5">总需：'+ t.total_times+'人次</p>'+
                    '<p>参与期号：'+ t.period+'</p><p>幸运号码：<b class="fon-arial txt-red">'+ t.lucky_code+'</b></p><p>本期参与：'+ t.buy_total+'人次</p><p>揭晓时间：'+ t.publish_time+'</p></div></div></li>';
                }
                $(".m-detail-lucy ul").append(_html);
            }
            var r = {data : json.data,uid:json.data.uid}
            if (r.data.records != null) {
                dataProcess(r.data);
                this._pageModal('api/my_lucky_records?user_id='+ r.uid,function(json){
                    if (json.code == 0) dataProcess(json.data);
                });
            } else {
                $(".m-nothing").removeClass("hidden");
            }
        },
        _addressMgr : function(json) {
            var addrs = json.data.list,a_html = "";
            if (addrs != null) {
                for(var i = 0;i < addrs.length;i++) {
                    var a = addrs[i];
                    a_html += '<li class="addritm"><div class="f-cb user"><div class="name f-toe">'+ a.nick_name+'</div><div class="mobile">'+ a.mobile+'</div></div>'+
                    '<div class="detail"><span class="address">'+ a.address+'</span></div><div class="operate f-cb"><div class="f-fl u-radiobox">'+
                    '<input type="radio" name="default" value="'+ a.is_default+'" '+(a.is_default==1?'checked="checked"':'')+' style="-webkit-appearance: none; border: none;"><span class="ml5">默认地址</span>'+
                    '</div><div class="f-fr"><span class="button edit" data-code="'+ a.code+'" data-role="edit">编辑</span><span class="button ml10 delete" data-role="del" data-code="'+ a.code+'">删除</span></div></div></li>';
                }
                $(".addressiptbox").append(a_html);
                $(".addritm .button").bind(touchStart,function(){
                    var that = $(this),parents = $(this).parents("li");
                    var role = that.attr("data-role");
                    if (role == "edit") {
                        var address = {
                            code : that.attr("data-code"),
                            name : parents.find(".name").text().trim(),
                            mobile : parents.find(".mobile").text().trim(),
                            address : parents.find(".address").text().trim(),
                            is_default : parents.find("input[name=default]").val()
                        }
                        setCookie("addr_info",JSON.stringify(address));
                        location.href = "../website/address.add.html?arg=edit";
                    } else {
                        var sure = confirm("确认要删除该地址吗？");
                        if (sure) {
                            var code = that.attr("data-code");
                            $.postAjax({url:"api/del_address",data:{code:code,signature:"del_address"}},function(data){
                                if (data.code == 0) refresh(); else alert(data.msg);
                            })
                        }
                    }
                });
            } else {
                $(".m-nothing").removeClass("hidden");
            }
        }
    }
})($);